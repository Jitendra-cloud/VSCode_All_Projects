class ZCL_JS_DEMO_CUSTOM_COMPANY_QRY definition
  public
  final
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_JS_DEMO_CUSTOM_COMPANY_QRY IMPLEMENTATION.
ENDCLASS.
