CLASS zcl_ui5_load_test_data DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.

    INTERFACES if_oo_adt_classrun.

ENDCLASS.


CLASS zcl_ui5_load_test_data IMPLEMENTATION.

  METHOD if_oo_adt_classrun~main.

    DELETE FROM zui5_customer.
    DELETE FROM zui5_booking.

    DATA lt_customers TYPE STANDARD TABLE OF zui5_customer.
    DATA lt_bookings  TYPE STANDARD TABLE OF zui5_booking.

    "------------------------------------------------------------
    " Customers
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' form = 'Firma' customer_name = 'SAP SE' street = 'Dietmar-Hopp-Allee 16' post_code = '69190' city = 'Walldorf' country = 'DE'
                    email = 'info@sap.de' telephone = '06227-34-0' discount = '10.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000002' form = 'Herr' customer_name = 'Andreas Klotz' street = 'Pimpinellenweg 9' post_code = '69190' city = 'Walldorf' country = 'DE'
                    email = 'Andreas.Klotz@sap.com' telephone = '05344-676792' discount = '20.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' form = 'Herr' customer_name = 'Hans Bullinger' street = 'Veilchenstraße 12' post_code = '69119' city = 'Heidelberg' country = 'DE'
                    email = 'Hansi@Bulli.de' telephone = '02099-44591' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' form = 'Frau' customer_name = 'Staerck' street = 'Kaiserstr. 55' post_code = '69115' city = 'Heidelberg' country = 'DE'
                    email = 'Farbenblind@gmx.de' telephone = '07508-66-7886' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' form = 'Mister' customer_name = 'Martin' street = '44 Harolds Road' post_code = 'L07 1AZ' city = 'Liverpool' country = 'GB'
                    email = 'Steve.Martin@hool.uk' telephone = '3457-345-2472' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' form = 'Miss' customer_name = 'Starr' street = '74 Kings Road' post_code = 'L07 3BC' city = 'Liverpool' country = 'GB'
                    email = 'FCStar@unio.uk' telephone = '5454-46-4674' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' form = 'Mister' customer_name = 'King' street = '7 Abbey Road' post_code = 'M21 7AB' city = 'London' country = 'GB'
                    email = 'Burger@King.com' telephone = '6548-78-9876' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000008' form = 'Company' customer_name = 'Moore' street = '14 Carnaby Street' post_code = 'SW3 4DE' city = 'London' country = 'GB'
                    email = 'Moore@abc.net' telephone = '3790-34-4384' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000009' form = '' customer_name = 'Everton FC' street = 'Sir Wellington Road' post_code = 'L08 5RZ' city = 'Liverpool' country = 'GB'
                    email = 'Football.Liverpool@sports.com' telephone = '332-5678-0' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000010' form = 'Herr' customer_name = 'Raupp' street = 'Glockenblumenweg 5' post_code = '8002' city = 'Zuerich' country = 'CH'
                    email = 'HelmutDanielaRaupp@swiss.ch' telephone = '+41 44 269 99 99' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' form = 'Herr' customer_name = 'Ballmann' street = 'Ballmanns Leiden 7' post_code = '69115' city = 'Heidelberg' country = 'DE'
                    email = 'Ball@mann.net' telephone = '+49 6221 6784534' discount = '0.00' ) TO lt_customers.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' form = 'Frau' customer_name = 'Radetzky' street = 'Mozartstr. 102' post_code = '1000' city = 'Wien' country = 'AT'
                    email = 'Radetzky@Marsch.at' telephone = '01 533 99 22' discount = '0.00' ) TO lt_customers.


    "------------------------------------------------------------
    " Bookings - Customer 1
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' booking_number = '0000002061' airline_id = 'AZ' connection_number = '0788' flight_date = '20240227'
                    booking_date = '20240217' class = 'Y' foreign_currency_payment = '927.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' booking_number = '0000007080' airline_id = 'AZ' connection_number = '0789' flight_date = '20240228'
                    booking_date = '20240218' class = 'C' foreign_currency_payment = '927.00' foreign_currency = 'EUR' agency_number = '00100' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' booking_number = '0000011297' airline_id = 'AZ' connection_number = '0790' flight_date = '20240127'
                    booking_date = '20240117' class = 'Y' foreign_currency_payment = '912.60' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' booking_number = '0000013481' airline_id = 'AZ' connection_number = '0790' flight_date = '20240706'
                    booking_date = '20240626' class = 'F' foreign_currency_payment = '837.25' foreign_currency = 'USD' agency_number = '00297' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' booking_number = '0000008494' airline_id = 'DL' connection_number = '1984' flight_date = '20240602'
                    booking_date = '20240523' class = 'C' foreign_currency_payment = '380.65' foreign_currency = 'USD' agency_number = '00000' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' booking_number = '0000005624' airline_id = 'JL' connection_number = '0408' flight_date = '20240404'
                    booking_date = '20240324' class = 'F' foreign_currency_payment = '793.00' foreign_currency = 'USD' agency_number = '00111' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000001' booking_number = '0000000085' airline_id = 'JL' connection_number = '0407' flight_date = '20240129'
                    booking_date = '20240119' class = 'F' foreign_currency_payment = '864.00' foreign_currency = 'EUR' agency_number = '00119' is_cancelled = 'X' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 2
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000002' booking_number = '0000001516' airline_id = 'AA' connection_number = '0017' flight_date = '20240503'
                    booking_date = '20240421' class = 'Y' foreign_currency_payment = '610.30' foreign_currency = 'SGD' agency_number = '00103' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000002' booking_number = '0000005383' airline_id = 'AA' connection_number = '0064' flight_date = '20240606'
                    booking_date = '20240525' class = 'Y' foreign_currency_payment = '368.80' foreign_currency = 'EUR' agency_number = '00087' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000002' booking_number = '0000005528' airline_id = 'AA' connection_number = '0064' flight_date = '20240606'
                    booking_date = '20240525' class = 'Y' foreign_currency_payment = '368.80' foreign_currency = 'EUR' agency_number = '00087' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000002' booking_number = '0000004017' airline_id = 'AZ' connection_number = '0788' flight_date = '20240705'
                    booking_date = '20240624' class = 'F' foreign_currency_payment = '824.00' foreign_currency = 'EUR' agency_number = '00114' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000002' booking_number = '0000006496' airline_id = 'AZ' connection_number = '0789' flight_date = '20240127'
                    booking_date = '20240115' class = 'C' foreign_currency_payment = '511.17' foreign_currency = 'GBP' agency_number = '00107' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000002' booking_number = '0000010634' airline_id = 'AZ' connection_number = '0789' flight_date = '20241010'
                    booking_date = '20240704' class = 'Y' foreign_currency_payment = '755.96' foreign_currency = 'USD' agency_number = '00320' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 3
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000006890' airline_id = 'AA' connection_number = '0064' flight_date = '20241012'
                    booking_date = '20240702' class = 'F' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00101' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000006454' airline_id = 'AZ' connection_number = '0789' flight_date = '20240127'
                    booking_date = '20240115' class = 'C' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00101' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000008955' airline_id = 'AZ' connection_number = '0789' flight_date = '20240706'
                    booking_date = '20240624' class = 'Y' foreign_currency_payment = '113875.00' foreign_currency = 'JPY' agency_number = '00000' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000011145' airline_id = 'AZ' connection_number = '0790' flight_date = '20240127'
                    booking_date = '20240114' class = 'Y' foreign_currency_payment = '1014.00' foreign_currency = 'EUR' agency_number = '00122' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000012287' airline_id = 'AZ' connection_number = '0790' flight_date = '20240401'
                    booking_date = '20240320' class = 'Y' foreign_currency_payment = '1014.00' foreign_currency = 'EUR' agency_number = '00124' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000012829' airline_id = 'AZ' connection_number = '0790' flight_date = '20240604'
                    booking_date = '20240523' class = 'Y' foreign_currency_payment = '1014.00' foreign_currency = 'EUR' agency_number = '00105' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000005369' airline_id = 'JL' connection_number = '0408' flight_date = '20240303'
                    booking_date = '20240218' class = 'F' foreign_currency_payment = '961.00' foreign_currency = 'EUR' agency_number = '00188' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000003' booking_number = '0000007782' airline_id = 'JL' connection_number = '0408' flight_date = '20240911'
                    booking_date = '20240703' class = 'C' foreign_currency_payment = '961.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 4
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000000317' airline_id = 'AA' connection_number = '0017' flight_date = '20240127'
                    booking_date = '20240113' class = 'Y' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00188' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000000884' airline_id = 'AZ' connection_number = '0555' flight_date = '20240807'
                    booking_date = '20240702' class = 'Y' foreign_currency_payment = '185.00' foreign_currency = 'EUR' agency_number = '00110' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000001662' airline_id = 'AZ' connection_number = '0788' flight_date = '20240126'
                    booking_date = '20240112' class = 'F' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000004203' airline_id = 'AZ' connection_number = '0788' flight_date = '20240705'
                    booking_date = '20240621' class = 'F' foreign_currency_payment = '1704.45' foreign_currency = 'SGD' agency_number = '00103' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000008335' airline_id = 'AZ' connection_number = '0789' flight_date = '20240604'
                    booking_date = '20240521' class = 'C' foreign_currency_payment = '2060.00' foreign_currency = 'EUR' agency_number = '00122' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000008336' airline_id = 'AZ' connection_number = '0789' flight_date = '20240604'
                    booking_date = '20240130' class = 'C' foreign_currency_payment = '2060.00' foreign_currency = 'EUR' agency_number = '00093' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000003804' airline_id = 'DL' connection_number = '1699' flight_date = '20240226'
                    booking_date = '20240213' class = 'Y' foreign_currency_payment = '285.98' foreign_currency = 'GBP' agency_number = '00109' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000007213' airline_id = 'JL' connection_number = '0408' flight_date = '20240810'
                    booking_date = '20240702' class = 'C' foreign_currency_payment = '961.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000008474' airline_id = 'JL' connection_number = '0408' flight_date = '20241216'
                    booking_date = '20240701' class = 'Y' foreign_currency_payment = '881.00' foreign_currency = 'USD' agency_number = '00297' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000000164' airline_id = 'LH' connection_number = '0400' flight_date = '20240130'
                    booking_date = '20240116' class = 'Y' foreign_currency_payment = '666.00' foreign_currency = 'EUR' agency_number = '00117' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000001120' airline_id = 'LH' connection_number = '0400' flight_date = '20240404'
                    booking_date = '20240321' class = 'Y' foreign_currency_payment = '611.01' foreign_currency = 'USD' agency_number = '00055' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000004' booking_number = '0000002915' airline_id = 'LH' connection_number = '0400' flight_date = '20240728'
                    booking_date = '20240714' class = 'F' foreign_currency_payment = '666.00' foreign_currency = 'EUR' agency_number = '00291' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 5
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000006423' airline_id = 'AA' connection_number = '0064' flight_date = '20240809'
                    booking_date = '20240629' class = 'Y' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00119' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000002982' airline_id = 'AZ' connection_number = '0788' flight_date = '20240502'
                    booking_date = '20240417' class = 'C' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00125' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000004696' airline_id = 'AZ' connection_number = '0788' flight_date = '20240806'
                    booking_date = '20240630' class = 'Y' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000007595' airline_id = 'AZ' connection_number = '0789' flight_date = '20240401'
                    booking_date = '20240317' class = 'C' foreign_currency_payment = '638.96' foreign_currency = 'GBP' agency_number = '00107' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000007793' airline_id = 'AZ' connection_number = '0789' flight_date = '20240401'
                    booking_date = '20240317' class = 'C' foreign_currency_payment = '9922.93' foreign_currency = 'SEK' agency_number = '00106' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000009368' airline_id = 'AZ' connection_number = '0789' flight_date = '20240706'
                    booking_date = '20240620' class = 'Y' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00320' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000009549' airline_id = 'AZ' connection_number = '0789' flight_date = '20240807'
                    booking_date = '20240629' class = 'Y' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00310' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000012155' airline_id = 'AZ' connection_number = '0790' flight_date = '20240401'
                    booking_date = '20240317' class = 'Y' foreign_currency_payment = '9768.78' foreign_currency = 'SEK' agency_number = '00106' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000003588' airline_id = 'DL' connection_number = '1699' flight_date = '20240125'
                    booking_date = '20240110' class = 'F' foreign_currency_payment = '50968.00' foreign_currency = 'JPY' agency_number = '00118' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000006853' airline_id = 'JL' connection_number = '0408' flight_date = '20240709'
                    booking_date = '20240624' class = 'C' foreign_currency_payment = '961.00' foreign_currency = 'EUR' agency_number = '00120' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000006093' airline_id = 'LH' connection_number = '0401' flight_date = '20240728'
                    booking_date = '20240714' class = 'Y' foreign_currency_payment = '611.01' foreign_currency = 'USD' agency_number = '00304' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000010713' airline_id = 'LH' connection_number = '0402' flight_date = '20240704'
                    booking_date = '20240619' class = 'Y' foreign_currency_payment = '666.00' foreign_currency = 'EUR' agency_number = '00116' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000013701' airline_id = 'LH' connection_number = '2402' flight_date = '20240303'
                    booking_date = '20240216' class = 'Y' foreign_currency_payment = '242.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000005' booking_number = '0000014917' airline_id = 'LH' connection_number = '2402' flight_date = '20240506'
                    booking_date = '20240422' class = 'Y' foreign_currency_payment = '150.12' foreign_currency = 'GBP' agency_number = '00112' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 6
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' booking_number = '0000004541' airline_id = 'AA' connection_number = '0064' flight_date = '20240302'
                    booking_date = '20240213' class = 'Y' foreign_currency_payment = '422.94' foreign_currency = 'USD' agency_number = '00152' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' booking_number = '0000000079' airline_id = 'AZ' connection_number = '0555' flight_date = '20240127'
                    booking_date = '20240111' class = 'Y' foreign_currency_payment = '185.00' foreign_currency = 'EUR' agency_number = '00115' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' booking_number = '0000002911' airline_id = 'AZ' connection_number = '0788' flight_date = '20240502'
                    booking_date = '20240415' class = 'C' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00284' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' booking_number = '0000005507' airline_id = 'AZ' connection_number = '0788' flight_date = '20241009'
                    booking_date = '20240629' class = 'F' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00111' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' booking_number = '0000007963' airline_id = 'AZ' connection_number = '0789' flight_date = '20240503'
                    booking_date = '20240417' class = 'Y' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00320' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' booking_number = '0000010562' airline_id = 'AZ' connection_number = '0789' flight_date = '20241010'
                    booking_date = '20240629' class = 'C' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00111' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000006' booking_number = '0000011204' airline_id = 'AZ' connection_number = '0790' flight_date = '20240127'
                    booking_date = '20240110' class = 'Y' foreign_currency_payment = '930.27' foreign_currency = 'USD' agency_number = '00152' is_cancelled = 'X' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 7
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000003341' airline_id = 'AA' connection_number = '0017' flight_date = '20240908'
                    booking_date = '20240628' class = 'Y' foreign_currency_payment = '285.98' foreign_currency = 'GBP' agency_number = '00109' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000002804' airline_id = 'AZ' connection_number = '0788' flight_date = '20240331'
                    booking_date = '20240314' class = 'Y' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00297' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000013815' airline_id = 'AZ' connection_number = '0790' flight_date = '20240807'
                    booking_date = '20240627' class = 'F' foreign_currency_payment = '1014.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000007587' airline_id = 'DL' connection_number = '1984' flight_date = '20240501'
                    booking_date = '20240414' class = 'Y' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00116' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000003251' airline_id = 'JL' connection_number = '0407' flight_date = '20240809'
                    booking_date = '20240628' class = 'C' foreign_currency_payment = '106136.00' foreign_currency = 'JPY' agency_number = '00118' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000002447' airline_id = 'LH' connection_number = '0400' flight_date = '20240709'
                    booking_date = '20240622' class = 'Y' foreign_currency_payment = '666.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000004256' airline_id = 'LH' connection_number = '0401' flight_date = '20240129'
                    booking_date = '20240112' class = 'Y' foreign_currency_payment = '413.15' foreign_currency = 'GBP' agency_number = '00109' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000006421' airline_id = 'LH' connection_number = '0401' flight_date = '20240809'
                    booking_date = '20240628' class = 'F' foreign_currency_payment = '666.00' foreign_currency = 'EUR' agency_number = '00116' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000012019' airline_id = 'LH' connection_number = '0402' flight_date = '20240906'
                    booking_date = '20240628' class = 'Y' foreign_currency_payment = '666.00' foreign_currency = 'EUR' agency_number = '00119' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000013186' airline_id = 'LH' connection_number = '2402' flight_date = '20240130'
                    booking_date = '20240113' class = 'C' foreign_currency_payment = '242.00' foreign_currency = 'EUR' agency_number = '00114' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000001762' airline_id = 'QF' connection_number = '0005' flight_date = '20240606'
                    booking_date = '20240520' class = 'Y' foreign_currency_payment = '1050.00' foreign_currency = 'EUR' agency_number = '00119' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000005122' airline_id = 'QF' connection_number = '0006' flight_date = '20240706'
                    booking_date = '20240618' class = 'Y' foreign_currency_payment = '1050.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000000240' airline_id = 'SQ' connection_number = '0002' flight_date = '20240128'
                    booking_date = '20240110' class = 'F' foreign_currency_payment = '1286.23' foreign_currency = 'USD' agency_number = '00323' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000012250' airline_id = 'SQ' connection_number = '0988' flight_date = '20240504'
                    booking_date = '20240416' class = 'Y' foreign_currency_payment = '550.00' foreign_currency = 'EUR' agency_number = '00116' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000013752' airline_id = 'SQ' connection_number = '0988' flight_date = '20240909'
                    booking_date = '20240627' class = 'F' foreign_currency_payment = '504.59' foreign_currency = 'USD' agency_number = '00323' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000007' booking_number = '0000005359' airline_id = 'SQ' connection_number = '0015' flight_date = '20240127'
                    booking_date = '20240110' class = 'C' foreign_currency_payment = '869.74' foreign_currency = 'GBP' agency_number = '00109' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Customer 8 has no bookings
    "------------------------------------------------------------


    "------------------------------------------------------------
    " Bookings - Customer 9
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000009' booking_number = '0000002170' airline_id = 'AA' connection_number = '0017' flight_date = '20240604'
                    booking_date = '20240515' class = 'Y' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00110' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000009' booking_number = '0000003694' airline_id = 'AZ' connection_number = '0788' flight_date = '20240603'
                    booking_date = '20240514' class = 'Y' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00110' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000009' booking_number = '0000005076' airline_id = 'AZ' connection_number = '0788' flight_date = '20240907'
                    booking_date = '20240624' class = 'Y' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000009' booking_number = '0000007326' airline_id = 'AZ' connection_number = '0789' flight_date = '20240401'
                    booking_date = '20240313' class = 'F' foreign_currency_payment = '3090.00' foreign_currency = 'EUR' agency_number = '00101' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000009' booking_number = '0000007994' airline_id = 'AZ' connection_number = '0789' flight_date = '20240503'
                    booking_date = '20240412' class = 'C' foreign_currency_payment = '638.96' foreign_currency = 'GBP' agency_number = '00109' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000009' booking_number = '0000005308' airline_id = 'DL' connection_number = '1699' flight_date = '20240805'
                    booking_date = '20240625' class = 'F' foreign_currency_payment = '422.94' foreign_currency = 'USD' agency_number = '00310' is_cancelled = 'X' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 10
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000010' booking_number = '0000003391' airline_id = 'AZ' connection_number = '0788' flight_date = '20240603'
                    booking_date = '20240513' class = 'C' foreign_currency_payment = '1277.92' foreign_currency = 'GBP' agency_number = '00107' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000010' booking_number = '0000012248' airline_id = 'AZ' connection_number = '0790' flight_date = '20240401'
                    booking_date = '20240311' class = 'Y' foreign_currency_payment = '930.27' foreign_currency = 'USD' agency_number = '00111' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000010' booking_number = '0000006435' airline_id = 'DL' connection_number = '1984' flight_date = '20240125'
                    booking_date = '20240103' class = 'Y' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00121' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 11
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000006988' airline_id = 'AA' connection_number = '0064' flight_date = '20241113'
                    booking_date = '20240622' class = 'C' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00116' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000007047' airline_id = 'AA' connection_number = '0064' flight_date = '20240116'
                    booking_date = '20240622' class = 'F' foreign_currency_payment = '1383.01' foreign_currency = 'EUR' agency_number = '00093' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000003782' airline_id = 'AZ' connection_number = '0788' flight_date = '20240603'
                    booking_date = '20240511' class = 'Y' foreign_currency_payment = '944.95' foreign_currency = 'USD' agency_number = '00310' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000012585' airline_id = 'AZ' connection_number = '0790' flight_date = '20240503'
                    booking_date = '20240411' class = 'Y' foreign_currency_payment = '930.27' foreign_currency = 'USD' agency_number = '00320' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000007798' airline_id = 'DL' connection_number = '1984' flight_date = '20240501'
                    booking_date = '20240408' class = 'F' foreign_currency_payment = '685.51' foreign_currency = 'CHF' agency_number = '00108' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000004234' airline_id = 'DL' connection_number = '1699' flight_date = '20240501'
                    booking_date = '20240409' class = 'C' foreign_currency_payment = '922.01' foreign_currency = 'EUR' agency_number = '00124' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000007081' airline_id = 'JL' connection_number = '0408' flight_date = '20240709'
                    booking_date = '20240616' class = 'Y' foreign_currency_payment = '961.00' foreign_currency = 'EUR' agency_number = '00284' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000011' booking_number = '0000003123' airline_id = 'JL' connection_number = '0407' flight_date = '20240708'
                    booking_date = '20240615' class = 'C' foreign_currency_payment = '961.00' foreign_currency = 'EUR' agency_number = '00101' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Bookings - Customer 12
    "------------------------------------------------------------

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000001501' airline_id = 'AA' connection_number = '0017' flight_date = '20240503'
                    booking_date = '20240409' class = 'Y' foreign_currency_payment = '663.22' foreign_currency = 'CAD' agency_number = '00233' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000002068' airline_id = 'AA' connection_number = '0017' flight_date = '20240604'
                    booking_date = '20240511' class = 'Y' foreign_currency_payment = '422.94' foreign_currency = 'USD' agency_number = '00320' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000004276' airline_id = 'AA' connection_number = '0064' flight_date = '20240302'
                    booking_date = '20240207' class = 'C' foreign_currency_payment = '461.00' foreign_currency = 'EUR' agency_number = '00284' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000006010' airline_id = 'AA' connection_number = '0064' flight_date = '20240708'
                    booking_date = '20240614' class = 'F' foreign_currency_payment = '422.94' foreign_currency = 'USD' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000001016' airline_id = 'AZ' connection_number = '0555' flight_date = '20240908'
                    booking_date = '20240621' class = 'Y' foreign_currency_payment = '185.00' foreign_currency = 'EUR' agency_number = '00061' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000001794' airline_id = 'AZ' connection_number = '0788' flight_date = '20240126'
                    booking_date = '20240102' class = 'Y' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00000' is_cancelled = '' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000002115' airline_id = 'AZ' connection_number = '0788' flight_date = '20240227'
                    booking_date = '20240203' class = 'C' foreign_currency_payment = '1030.00' foreign_currency = 'EUR' agency_number = '00114' is_cancelled = 'X' ) TO lt_bookings.

    APPEND VALUE #( client = sy-mandt customer_number = '0000000012' booking_number = '0000012033' airline_id = 'AZ' connection_number = '0790' flight_date = '20240401'
                    booking_date = '20240308' class = 'F' foreign_currency_payment = '930.27' foreign_currency = 'USD' agency_number = '00323' is_cancelled = '' ) TO lt_bookings.


    "------------------------------------------------------------
    " Insert Customers
    "------------------------------------------------------------

    INSERT zui5_customer FROM TABLE @lt_customers
      ACCEPTING DUPLICATE KEYS.

    IF sy-subrc = 0.
      out->write( |Customers processed: { lines( lt_customers ) }| ).
    ELSE.
      out->write( |Customer insert returned SY-SUBRC: { sy-subrc }| ).
    ENDIF.


    "------------------------------------------------------------
    " Insert Bookings
    "------------------------------------------------------------

    INSERT zui5_booking FROM TABLE @lt_bookings
      ACCEPTING DUPLICATE KEYS.

    IF sy-subrc = 0.
      out->write( |Bookings processed: { lines( lt_bookings ) }| ).
    ELSE.
      out->write( |Booking insert returned SY-SUBRC: { sy-subrc }| ).
    ENDIF.


    COMMIT WORK.

    out->write( '----------------------------------------' ).
    out->write( 'Test data loading completed.' ).
    out->write( |Customers : { lines( lt_customers ) }| ).
    out->write( |Bookings  : { lines( lt_bookings ) }| ).

  ENDMETHOD.

ENDCLASS.
