@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'UI5 Booking Projection'
@Metadata.allowExtensions: true

define view entity ZC_UI5_BOOKING
  as projection on ZI_UI5_BOOKING
{
  key CustomerNumber,
  key BookingNumber,
      AirlineID,
      ConnectionNumber,
      FlightDate,
      BookingDate,
      Class,
      ForeignCurrencyPayment,
      ForeignCurrency,
      AgencyNumber,
      IsCancelled,

      LocalLastChangedAt,

      _Customer : redirected to parent ZC_UI5_CUSTOMER
}
