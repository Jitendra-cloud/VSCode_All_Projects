@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'UI5 Customer Projection'
@Metadata.allowExtensions: true

define root view entity ZC_UI5_CUSTOMER
  provider contract transactional_query
  as projection on ZI_UI5_CUSTOMER
{
  key CustomerNumber,
      Form,
      CustomerName,
      Street,
      PostCode,
      City,
      Country,
      Email,
      Telephone,
      Discount,

      LocalLastChangedAt,

      _Bookings : redirected to composition child ZC_UI5_BOOKING
}
