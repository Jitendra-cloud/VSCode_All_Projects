CLASS lhc_UX_Customer DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR UX_Customer RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR UX_Customer RESULT result.

    METHODS Resume FOR MODIFY
      IMPORTING keys FOR ACTION UX_Customer~Resume.
    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE UX_Customer.

ENDCLASS.

CLASS lhc_UX_Customer IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD get_global_authorizations.
  ENDMETHOD.

  METHOD Resume.
  ENDMETHOD.

  METHOD earlynumbering_create.
    SELECT FROM zui5_customer FIELDS MAX( customer_number ) INTO @DATA(ld_max_customer).

*    LOOP AT mapped-partner REFERENCE INTO DATA(lr_partner).
*      ld_max_partner += 1.
*      lr_partner->PartnerNumber = ld_max_partner.
*    ENDLOOP.

    LOOP AT entities INTO DATA(entity).
      ld_max_customer += 1.
      APPEND VALUE #( %cid = entity-%cid
                     "" %key      = entity-%key
                      %is_draft = entity-%is_draft
                      customernumber = ld_max_customer ) TO mapped-ux_customer.
    ENDLOOP.

  ENDMETHOD.

ENDCLASS.
