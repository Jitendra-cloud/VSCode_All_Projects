@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'UI5 Customer'

define root view entity ZI_UI5_CUSTOMER
  as select from zui5_customer
  composition [0..*] of ZI_UI5_BOOKING as _Bookings
{
  key customer_number       as CustomerNumber,
      form                  as Form,
      customer_name         as CustomerName,
      street                as Street,
      post_code             as PostCode,
      city                  as City,
      country               as Country,
      email                 as Email,
      telephone             as Telephone,
      discount              as Discount,

      @Semantics.user.createdBy: true
      local_created_by      as LocalCreatedBy,
      @Semantics.systemDateTime.createdAt: true
      local_created_at      as LocalCreatedAt,
      @Semantics.user.localInstanceLastChangedBy: true
      local_last_changed_by as LocalLastChangedBy,
      //local ETag field --> OData ETag
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt,

      //total ETag field
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,

      _Bookings
}
