@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'UI5 Booking'

define view entity ZI_UI5_BOOKING
  as select from zui5_booking
  association to parent ZI_UI5_CUSTOMER as _Customer on $projection.CustomerNumber = _Customer.CustomerNumber
{
  key customer_number          as CustomerNumber,
  key booking_number           as BookingNumber,
      airline_id               as AirlineID,
      connection_number        as ConnectionNumber,
      flight_date              as FlightDate,
      booking_date             as BookingDate,
      class                    as Class,
      foreign_currency_payment as ForeignCurrencyPayment,
      foreign_currency         as ForeignCurrency,
      agency_number            as AgencyNumber,
      is_cancelled             as IsCancelled,

      local_last_changed_at    as LocalLastChangedAt,

      _Customer
}
