*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZEI_PO_LINK.....................................*
DATA:  BEGIN OF STATUS_ZEI_PO_LINK                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZEI_PO_LINK                   .
CONTROLS: TCTRL_ZEI_PO_LINK
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZEI_PO_LINK                   .
TABLES: ZEI_PO_LINK                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
