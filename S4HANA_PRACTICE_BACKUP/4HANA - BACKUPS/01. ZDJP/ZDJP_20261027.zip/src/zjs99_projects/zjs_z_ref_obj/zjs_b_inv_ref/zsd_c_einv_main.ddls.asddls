@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'EInvoice Main CDS View'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
@Metadata.allowExtensions: true
define root view entity ZSD_C_EINV_MAIN
  as select from    zsd_t_einv_log as ewaybill_status

    left outer join vbpa           as vbpa on  vbpa.vbeln = ewaybill_status.custom1
                                           and vbpa.parvw = 'SP'

    left outer join lfa1           as lfa1 on lfa1.lifnr = vbpa.lifnr
{
  key ewaybill_status.document_number         as DocumentNumber,
  key ewaybill_status.document_date           as DocumentDate,
  key ewaybill_status.company_code            as CompanyCode,
      ewaybill_status.fiscal_year             as FiscalYear,
      ewaybill_status.referencedocumentnumber as ReferenceDocumentNumber,
      ewaybill_status.location_gstin          as LocationGstin,
      ewaybill_status.billfromgstin           as Billfromgstin,
      ewaybill_status.billfromname            as Billfromname,
      ewaybill_status.billfromadd1            as Billfromadd1,
      ewaybill_status.billfromadd2            as Billfromadd2,
      ewaybill_status.billfrompincode         as Billfrompincode,
      ewaybill_status.billfromcity            as Billfromcity,
      ewaybill_status.billtogstin             as Billtogstin,
      ewaybill_status.billtoname              as Billtoname,
      ewaybill_status.billtoadd1              as Billtoadd1,
      ewaybill_status.billtoadd2              as Billtoadd2,
      ewaybill_status.billtopincode           as Billtopincode,
      ewaybill_status.billtocity              as Billtocity,
      ewaybill_status.billtostatecode         as Billtostatecode,
      ewaybill_status.transactiontype         as TransactionType,
      ewaybill_status.dispatchfromgstin       as Dispatchfromgstin,
      ewaybill_status.dispatchfromname        as Dispatchfromname,
      ewaybill_status.dispatchfromadd1        as Dispatchfromadd1,
      ewaybill_status.dispatchfromadd2        as Dispatchfromadd2,
      ewaybill_status.dispatchfrompincode     as Dispatchfrompincode,
      ewaybill_status.dispatchfromcity        as Dispatchfromcity,
      ewaybill_status.shiptogstin             as Shiptogstin,
      ewaybill_status.shiptoname              as Shiptoname,
      ewaybill_status.shiptoadd1              as Shiptoadd1,
      ewaybill_status.shiptoadd2              as Shiptoadd2,
      ewaybill_status.shiptopincode           as Shiptopincode,
      ewaybill_status.shiptostatecode         as Shiptostatecode,
      ewaybill_status.shiptocity              as Shiptocity,
      ewaybill_status.documenttype            as Documenttype,
      ewaybill_status.pending                 as Pending,
      ewaybill_status.fail                    as Fail,
      ewaybill_status.success                 as Success,
      ewaybill_status.cancel                  as Cancel,
      ewaybill_status.cancel_date             as CancelDate,
      ewaybill_status.cancel_by               as CancelBy,
      ewaybill_status.cancel_time             as CancelTime,
      ewaybill_status.entry_date              as EntryDate,
      ewaybill_status.entry_time              as EntryTime,
      ewaybill_status.einv_module             as EinvModule,
      ewaybill_status.einv_error              as EinvError,
      ewaybill_status.irn                     as Irn,
      ewaybill_status.buss_place              as BussPlace,
      ewaybill_status.ack_no                  as AckowlegementNumber,
      ewaybill_status.ack_date                as AckDate,
      ewaybill_status.qrcode                  as QrCode,
      ewaybill_status.signed_qrcode           as SignedQrcode,
      ewaybill_status.signed_inv              as SignedInv,
      ewaybill_status.ewaybill_number         as EwaybillNumber,
      ewaybill_status.ewaybill_valid_upto     as EwaybillValidUpto,
      ewaybill_status.ewaybill_generated      as EwaybillGenerated,
      ewaybill_status.ewaybill_error          as EwaybillError,
      ewaybill_status.ewaybill_distance       as EwaybillDistance,
      ewaybill_status.eway_gen                as EwayGen,
      ewaybill_status.eway_fail               as EwayFail,
      ewaybill_status.eway_cancel             as EwayCancel,
      ewaybill_status.eway_cancel_date        as EwayCancelDate,
      ewaybill_status.eway_cancel_by          as EwayCancelBy,
      ewaybill_status.eway_cancel_time        as EwayCancelTime,
      ewaybill_status.plant                   as Plant,
      ewaybill_status.einv_error              as Error,
      ewaybill_status.custom1                 as Custom1,
      case
      when lfa1.stenr is not initial
      then lfa1.stenr
      else ewaybill_status.transporter_id
      end                                     as TransporterId,
      case
      when lfa1.name1 is not initial
      then lfa1.name1
      else ewaybill_status.transporter_name
      end                                     as TransporterName,
      ewaybill_status.transport_mode          as TransportMode,
      ewaybill_status.transporter_doc_num     as TransporterDocNum,
      ewaybill_status.transporter_doc_date    as TransporterDocDate,
      ewaybill_status.vehicle_number          as VehicleNumber,
      ewaybill_status.vehicle_type            as VehicleType,
      ewaybill_status.irn_status              as irnstatus,
      ewaybill_status.ewb_status              as ewbstatus,
      ewaybill_status.created_by              as CreatedBy,
      ewaybill_status.created_at              as CreatedAt,
      ewaybill_status.last_changed_by         as LastChangedBy,
      ewaybill_status.last_changed_at         as LastChangedAt,
      ewaybill_status.local_last_changed_at   as LocalLastChangedAt,
      vbpa.lifnr                              as lifnr,

      case
        when ewaybill_status.irn is not initial or ewaybill_status.success is not initial then 'IRN Generated'
        when ewaybill_status.cancel = 'X'   then 'IRN Cancelled'
        else 'IRN Pending'
      end                                     as irn_status,

      @UI.hidden: true
      //      case
      //        when ewaybill_status.cancel = 'X'   then 1   // Error
      //        when ewaybill_status.irn is initial then 2   // Warning
      //        else 3                       // Success
      //      end                                   as irn_icon,
      case
        when ewaybill_status.irn is not initial or ewaybill_status.success is not initial then  3
              when ewaybill_status.cancel = 'X'   then 1
              else 2
      end                                     as irn_icon,

      case
        when ewaybill_status.ewaybill_number is not initial then 'E-Way Bill Generated'
        when ewaybill_status.ewaybill_error is not initial then 'Error!'
        when ewaybill_status.eway_cancel = 'X'          then 'E-Way Bill Cancelled'
        else 'E-Way Bill Pending'
      end                                     as ewb_status,
      @UI.hidden: true
      case
         when ewaybill_status.ewaybill_number  is not initial then 3
        when ewaybill_status.ewaybill_error is not initial then 1   // success
        when ewaybill_status.eway_cancel is not initial then 1   // error
        else 2                                // Warning
      end                                     as ewb_icon

}
//where irn is not initial
//and cancel is initial
