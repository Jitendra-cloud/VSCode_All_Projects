@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Bill types for SD Flow'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZSD_C_BILLTYPE
  as select from zsd_t_billtype
{
  key fkart    as Fkart,
      doc_type as Doc_Type
}
