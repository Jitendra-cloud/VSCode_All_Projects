@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Table Maintenance for Supply Details'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZSD_C_SUPPLY_DETAIL
  as select from zsd_t_suppdetail
{
  key warehouse      as Warehouse,
  key shipping_point as ShippingPoint,
      address1       as Address1,
      address2       as Address2,
      place          as Place,
      pincode        as Pincode
}
