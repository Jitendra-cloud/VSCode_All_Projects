@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'View for BSEG'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZSD_C_BSEG
  as select from bseg
  association to I_CompanyCode as _t001 on _t001.CompanyCode = $projection.Bukrs

{
  key bukrs          as Bukrs,
  key belnr          as Belnr,
  key gjahr          as Gjahr,
  key buzei          as Buzei,
      buzid          as Buzid,
      augdt          as Augdt,
      augcp          as Augcp,
      augbl          as Augbl,
      bschl          as Bschl,
      koart          as Koart,
      umskz          as Umskz,
      umsks          as Umsks,
      zumsk          as Zumsk,
      shkzg          as Shkzg,
      gsber          as Gsber,
      pargb          as Pargb,
      tax_country    as TaxCountry,
      mwskz          as Mwskz,
      txdat_from     as TxdatFrom,
      qsskz          as Qsskz,
      @Semantics.amount.currencyCode : 'waers'
      dmbtr          as Dmbtr,
      @Semantics.amount.currencyCode : 'waers'
      wrbtr          as Wrbtr,
      @Semantics.amount.currencyCode : 'waers'
      fcsl           as Fcsl,
      rfccur         as Rfccur,
      @Semantics.amount.currencyCode : 'waers'
      kzbtr          as Kzbtr,
      @Semantics.amount.currencyCode : 'waers'
      pswbt          as Pswbt,
      pswsl          as Pswsl,
      @Semantics.amount.currencyCode : 'waers'
      txbhw          as Txbhw,
      @Semantics.amount.currencyCode : 'waers'
      txbfw          as Txbfw,
      @Semantics.amount.currencyCode : 'waers'
      mwsts          as Mwsts,
      @Semantics.amount.currencyCode : 'waers'
      wmwst          as Wmwst,
      @Semantics.amount.currencyCode : 'waers'
      lwsts          as Lwsts,
      @Semantics.amount.currencyCode : 'waers'
      lwbtr          as Lwbtr,
      @Semantics.amount.currencyCode : 'waers'
      hwbas          as Hwbas,
      @Semantics.amount.currencyCode : 'waers'
      fwbas          as Fwbas,
      @Semantics.amount.currencyCode : 'waers'
      hwzuz          as Hwzuz,
      @Semantics.amount.currencyCode : 'waers'
      fwzuz          as Fwzuz,
      shzuz          as Shzuz,
      stekz          as Stekz,
      mwart          as Mwart,
      txgrp          as Txgrp,
      ktosl          as Ktosl,
      @Semantics.amount.currencyCode : 'waers'
      qsshb          as Qsshb,
      kursr          as Kursr,
      bupla,
      kunnr          as kunnr,
      lifnr          as lifnr,
      segment        as segment,
      vbeln,
      hsn_sac,
      plc_sup,
      gst_part,
      matnr,
      werks,
      xauto,
      gvtyp,
      @Semantics.quantity.unitOfMeasure : 'meins'
      menge,
      hkont,
      meins,
      sgtxt,
      prctr,
      _t001.Currency as waers
}
//where
//     lifnr is not initial
//  or kunnr is not initial
