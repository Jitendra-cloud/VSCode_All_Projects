@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'View for tvarvc'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZSD_C_tvarvc
  as select from tvarvc
{
  key name       as Name,
  key type       as Type,
  key numb       as Numb,
      sign       as Sign,
      opti       as Opti,
      low        as Low,
      high       as High,
      clie_indep as ClieIndep
}
