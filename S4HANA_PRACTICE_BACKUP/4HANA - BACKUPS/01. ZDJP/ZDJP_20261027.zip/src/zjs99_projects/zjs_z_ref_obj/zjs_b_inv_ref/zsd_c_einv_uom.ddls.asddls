@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Table Maintenance for UOM'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZSD_C_EINV_UOM
  as select from zsd_t_einv_uom
{
  key sap_uom as SapUom,
      gst_uom as GstUom
}
