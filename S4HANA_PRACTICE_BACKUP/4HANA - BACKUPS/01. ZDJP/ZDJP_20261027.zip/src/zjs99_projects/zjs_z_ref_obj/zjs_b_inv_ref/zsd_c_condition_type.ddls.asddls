@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Table Maintenance for Condition Types'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZSD_C_CONDITION_TYPE
  as select from zsd_t_condtype
{
  key condition_type as ConditionType,
      category       as Category
}
