@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ZPB_I_2A_PAY_BLOCK'
@Metadata.ignorePropagatedAnnotations: true
define root view entity ZPB_I_2A_PAY_BLOCK

  as select from    zcy_tab_rrp_e    as a
    left outer join zcy_t_2a_pay_blk as b on  a.returnperiod   = b.returnperiod
                                          and a.locationgstin  = b.locationgstin
                                          and a.documentnumber = b.documentnumber
                                          and a.documentdate   = b.documentdate
                                          and a.custom1        = b.custom1
                                          and a.custom4        = b.custom4
                                          and a.custom9        = b.custom9
    left outer join zcy_t_2a_recstat as c on a.reconciliationsection = c.reco_status
                                          and( c.category               = 'X' )
    left outer join zcyg_panno_exmp  as p on p.panno = substring( b.gstin, 3, 10 )

{
  key a.custom1                                       as Custom1,
  key a.custom4                                       as Custom4,
  key a.custom9                                       as Custom9,
      a.returnperiod                                  as Returnperiod,
      a.locationgstin                                 as Locationgstin,
      a.documentnumber                                as Documentnumber,
      a.serialnumber                                  as Serialnumber,
      a.documentdate                                  as Documentdate,
      a.billfromgstin                                 as Billfromgstin,
      a.financialyear                                 as Financialyear,
      a.mapperid                                      as Mapperid,
      a.supplytype                                    as Supplytype,
      a.purpose                                       as Purpose,
      a.locationname                                  as Locationname,
      a.irn                                           as Irn,
      a.liabilitydischargereturnperiod                as Liabilitydischargereturnperiod,
      a.itcclaimreturnperiod                          as Itcclaimreturnperiod,
      a.documenttype                                  as Documenttype,
      a.transactiontype                               as Transactiontype,
      a.taxpayertype                                  as Taxpayertype,
      a.transactionnature                             as Transactionnature,
      a.documentseriescode                            as Documentseriescode,
      a.billfromlegalname                             as Billfromlegalname,
      a.billfromtradename                             as Billfromtradename,
      a.billfromvendorcode                            as Billfromvendorcode,
      a.billfromaddress1                              as Billfromaddress1,
      a.billfromaddress2                              as Billfromaddress2,
      a.billfromcity                                  as Billfromcity,
      a.billfromstatecode                             as Billfromstatecode,
      a.billfrompincode                               as Billfrompincode,
      a.billfromphone                                 as Billfromphone,
      a.billfromemail                                 as Billfromemail,
      a.dispatchfromgstin                             as Dispatchfromgstin,
      a.dispatchfromtradename                         as Dispatchfromtradename,
      a.dispatchfromvendorcode                        as Dispatchfromvendorcode,
      a.dispatchfromaddress1                          as Dispatchfromaddress1,
      a.dispatchfromaddress2                          as Dispatchfromaddress2,
      a.dispatchfromcity                              as Dispatchfromcity,
      a.dispatchfromstatecode                         as Dispatchfromstatecode,
      a.dispatchfrompincode                           as Dispatchfrompincode,
      a.billtogstin                                   as Billtogstin,
      a.billtolegalname                               as Billtolegalname,
      a.billtotradename                               as Billtotradename,
      a.billtovendorcode                              as Billtovendorcode,
      a.billtoaddress1                                as Billtoaddress1,
      a.billtoaddress2                                as Billtoaddress2,
      a.billtocity                                    as Billtocity,
      a.billtostatecode                               as Billtostatecode,
      a.billtopincode                                 as Billtopincode,
      a.billtophone                                   as Billtophone,
      a.billtoemail                                   as Billtoemail,
      a.shiptogstin                                   as Shiptogstin,
      a.shiptolegalname                               as Shiptolegalname,
      a.shiptotradename                               as Shiptotradename,
      a.shiptovendorcode                              as Shiptovendorcode,
      a.shiptoaddress1                                as Shiptoaddress1,
      a.shiptoaddress2                                as Shiptoaddress2,
      a.shiptocity                                    as Shiptocity,
      a.shiptostatecode                               as Shiptostatecode,
      a.shiptopincode                                 as Shiptopincode,
      a.paymenttype                                   as Paymenttype,
      a.paymentmode                                   as Paymentmode,
      @Semantics.amount.currencyCode: 'Currency'
      a.paymentamount                                 as Paymentamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.advancepaidamount                             as Advancepaidamount,
      a.paymentdate                                   as Paymentdate,
      a.paymentremarks                                as Paymentremarks,
      a.paymentterms                                  as Paymentterms,
      a.paymentinstruction                            as Paymentinstruction,
      a.payeename                                     as Payeename,
      a.payeeaccountnumber                            as Payeeaccountnumber,
      @Semantics.amount.currencyCode: 'Currency'
      a.paymentamountdue                              as Paymentamountdue,
      a.ifsc                                          as Ifsc,
      a.credittransfer                                as Credittransfer,
      a.directdebit                                   as Directdebit,
      a.creditdays                                    as Creditdays,
      a.creditavaileddate                             as Creditavaileddate,
      a.creditreversaldate                            as Creditreversaldate,
      a.refdocumentremarks                            as Refdocumentremarks,
      a.refdocumentperiodstartdate                    as Refdocumentperiodstartdate,
      a.refdocumentperiodenddate                      as Refdocumentperiodenddate,
      a.invno                                         as Invno,
      a.invdt                                         as Invdt,
      a.refcontractdetails                            as Refcontractdetails,
      a.additionalsupportingdocumentde                as Additionalsupportingdocumentde,
      a.portcode                                      as Portcode,
      a.documentcurrencycode                          as Documentcurrencycode,
      a.destinationcountry                            as Destinationcountry,
      a.pos                                           as Pos,
      @Semantics.amount.currencyCode: 'Currency'
      a.documentvalue                                 as Documentvalue,
      a.documentdiscount                              as Documentdiscount,
      a.documentothercharges                          as Documentothercharges,
      @Semantics.amount.currencyCode: 'Currency'
      a.documentvalueinforeigncurrency                as Documentvalueinforeigncurrency,
      @Semantics.amount.currencyCode: 'Currency'
      a.roundoffamount                                as Roundoffamount,
      a.differentialpercentage                        as Differentialpercentage,
      a.reversecharge                                 as Reversecharge,
      a.claimrefund                                   as Claimrefund,
      a.underigstact                                  as Underigstact,
      a.refundeligibility                             as Refundeligibility,
      a.pnroruniquenumber                             as Pnroruniquenumber,
      a.availprovisionalitc                           as Availprovisionalitc,
      a.originalstatecode                             as Originalstatecode,
      a.originaldocumentnumber                        as Originaldocumentnumber,
      a.originaldocumentdate                          as Originaldocumentdate,
      a.originalreturnperiod                          as Originalreturnperiod,
      @Semantics.amount.currencyCode: 'Currency'
      a.originaltaxablevalue                          as Originaltaxablevalue,
      a.toemailaddresses                              as Toemailaddresses,
      a.tomobilenumbers                               as Tomobilenumbers,
      a.jworiginaldocumentnumber                      as Jworiginaldocumentnumber,
      a.jworiginaldocumentdate                        as Jworiginaldocumentdate,
      a.jwdocumentnumber                              as Jwdocumentnumber,
      a.jwdocumentdate                                as Jwdocumentdate,
      a.autodraftsource                               as Autodraftsource,
      a.irngenerationdate                             as Irngenerationdate,
      a.isamendment                                   as Isamendment,
      a.isavailableingstr2b                           as Isavailableingstr2b,
      a.itcavailability                               as Itcavailability,
      a.itcunavailabilityreason                       as Itcunavailabilityreason,
      a.custom2                                       as Custom2,
      a.custom3                                       as Custom3,
      a.custom5                                       as Custom5,
      a.custom6                                       as Custom6,
      a.custom7                                       as Custom7,
      a.custom8                                       as Custom8,
      a.custom10                                      as Custom10,
      a.custom20                                      as Custom20,
      a.natureofjwdone                                as Natureofjwdone,
      a.lossunitofmeasure                             as Lossunitofmeasure,
      @Semantics.quantity.unitOfMeasure: 'uom'
      a.losstotalquantity                             as Losstotalquantity,
      a.pusherrors                                    as Pusherrors,
      a.pushstatus                                    as Pushstatus,
      a.gstaction                                     as Gstaction,
      a.reconciliationsection                         as Preconciliationsection,

      case when a.filingdate is null then 'MISMATCHED'
           when a.taxdiff < 0
           and a.reconciliationsection = 'MISMATCHED'
           then 'MATCHED'
           else a.reconciliationsection end           as Reconciliationsection,

      a.pushdate                                      as Pushdate,
      a.cancelleddate                                 as Cancelleddate,
      a.ispregstregime                                as Ispregstregime,
      a.amendedtype                                   as Amendedtype,
      a.isgstr3bfiled                                 as Isgstr3bfiled,
      a.isgstr3bfildate                               as Isgstr3bfildate,
      a.filingdate                                    as Filingdate,
      a.filingreturnperiod                            as Filingreturnperiod,
      a.filingstatus                                  as Filingstatus,
      a.isservice                                     as Isservice,
      a.hsn                                           as Hsn,
      a.productcode                                   as Productcode,
      a.name                                          as Name,
      a.description                                   as Description,
      a.barcode                                       as Barcode,
      a.uqc                                           as Uqc,
      @Semantics.quantity.unitOfMeasure: 'uom'
      a.quantity                                      as Quantity,
      a.freequantity                                  as Freequantity,
      @Semantics.amount.currencyCode: 'Currency'
      a.rate                                          as Rate,
      @Semantics.amount.currencyCode: 'Currency'
      a.cessrate                                      as Cessrate,
      a.statecessrate                                 as Statecessrate,
      @Semantics.amount.currencyCode: 'Currency'
      a.cessnonadvaloremrate                          as Cessnonadvaloremrate,
      a.priceperquantity                              as Priceperquantity,
      @Semantics.amount.currencyCode: 'Currency'
      a.discountamount                                as Discountamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.grossamount                                   as Grossamount,
      a.othercharges                                  as Othercharges,
      @Semantics.amount.currencyCode: 'Currency'
      a.taxablevalue                                  as Taxablevalue,
      @Semantics.amount.currencyCode: 'Currency'
      a.igstamount                                    as Igstamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.cgstamount                                    as Cgstamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.sgstamount                                    as Sgstamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.cessamount                                    as Cessamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.statecessamount                               as Statecessamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.cessnonadvaloremamount                        as Cessnonadvaloremamount,
      a.statecessnonadvaloremamount                   as Statecessnonadvaloremamount,
      a.taxtype                                       as Taxtype,
      a.itceligibility                                as Itceligibility,
      @Semantics.amount.currencyCode: 'Currency'
      a.itcigstamount                                 as Itcigstamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.itccgstamount                                 as Itccgstamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.itcsgstamount                                 as Itcsgstamount,
      @Semantics.amount.currencyCode: 'Currency'
      a.itccessamount                                 as Itccessamount,
      a.customitem1                                   as Customitem1,
      a.customitem2                                   as Customitem2,
      a.customitem3                                   as Customitem3,
      a.customitem4                                   as Customitem4,
      a.customitem5                                   as Customitem5,
      a.customitem6                                   as Customitem6,
      a.customitem7                                   as Customitem7,
      a.customitem8                                   as Customitem8,
      a.customitem9                                   as Customitem9,
      a.customitem10                                  as Customitem10,
      a.cpgstin                                       as Cpgstin,
      a.cptradename                                   as Cptradename,
      a.cplegalname                                   as Cplegalname,
      a.cporiginaldocumentnumber                      as Cporiginaldocumentnumber,
      a.cporiginaldocumentdate                        as Cporiginaldocumentdate,
      a.cpportcode                                    as Cpportcode,
      a.cpdocumentnumber                              as Cpdocumentnumber,
      a.cpdocumentdate                                as Cpdocumentdate,
      a.cpvalue                                       as Cpvalue,
      a.cppos                                         as Cppos,
      a.cpreversecharge                               as Cpreversecharge,
      a.cpdifferentialpercentage                      as Cpdifferentialpercentage,
      a.cptransactiontype                             as Cptransactiontype,
      a.cptaxpayertype                                as Cptaxpayertype,
      a.cptaxablevalue                                as Cptaxablevalue,
      a.cprate                                        as Cprate,
      a.cpigstamount                                  as Cpigstamount,
      a.cpcgstamount                                  as Cpcgstamount,
      a.cpsgstamount                                  as Cpsgstamount,
      a.cpcessamount                                  as Cpcessamount,
      a.cpfilingstatus                                as Cpfilingstatus,
      a.cpsuppliercancellationdate                    as Cpsuppliercancellationdate,
      a.cpfilingdate                                  as Cpfilingdate,
      a.cpfilingreturnperiod                          as Cpfilingreturnperiod,
      a.cpautodraftsource                             as Cpautodraftsource,
      a.cpirn                                         as Cpirn,
      a.cpirngenerationdate                           as Cpirngenerationdate,
      a.cprefprecedingdocumentdetails                 as Cprefprecedingdocumentdetails,
      a.cpavailableingstr2b                           as Cpavailableingstr2b,
      a.cpgstr2breturnperiod                          as Cpgstr2breturnperiod,
      a.cpavailableingstr98a                          as Cpavailableingstr98a,
      a.cpitcavailability                             as Cpitcavailability,
      a.cpitcunavailabilityreason                     as Cpitcunavailabilityreason,
      a.cpitcclaimmonth                               as Cpitcclaimmonth,
      a.cpreturnperiod                                as Cpreturnperiod,
      a.cpisamendment                                 as Cpisamendment,
      a.cporiginalreturnperiod                        as Cporiginalreturnperiod,
      a.cpamendedtype                                 as Cpamendedtype,
      @Semantics.amount.currencyCode: 'Currency'
      a.valuediff                                     as Valuediff,
      @Semantics.amount.currencyCode: 'Currency'
      a.taxablediff                                   as Taxablediff,
      @Semantics.amount.currencyCode: 'Currency'
      a.taxdiff                                       as Taxdiff,
      a.reason                                        as Reason,
      a.rec_date                                      as RecDate,
      a.rec_time                                      as RecTime,
      a.p_dbf                                         as P_dbf1,
      a.p_jv                                          as P_jv1,
      a.p_pbf                                         as P_pbf1,
      b.currency                                      as Currency,
      @Semantics.amount.currencyCode: 'Currency'
      b.fi_doc_value                                  as FiDocValue,
      @Semantics.amount.currencyCode: 'Currency'
      b.fi_tax_value                                  as FiTaxValue,
      b.fi_tax_code                                   as FiTaxCode,
      @Semantics.amount.currencyCode: 'Currency'
      b.fi_tax_rate                                   as FiTaxRate,
      b.status                                        as Status,
      b.gst_part                                      as GstPart,
      b.vendor                                        as Vendor,
      b.mindk                                         as Mindk,
      b.vendor_block_type                             as VendorBlockType,
      b.payment_due_date                              as PaymentDueDate,
      b.clearing_no                                   as ClearingNo,
      b.clearing_date                                 as ClearingDate,
      b.expected_filing_date                          as ExpectedFilingDate,
      b.due_date_before_filing                        as DueDateBeforeFiling,
      b.cleared_before_filing                         as ClearedBeforeFiling,
      b.grc_check_applicable                          as GrcCheckApplicable,
      b.grc_checked_on                                as GrcCheckedOn,
      b.grc_checked_at                                as GrcCheckedAt,
      b.grc_checked_by                                as GrcCheckedBy,
      b.grc_score                                     as GrcScore,
      b.gstr3b_score                                  as Gstr3bScore,
      b.grc_check_result                              as GrcCheckResult,
      b.grc_check_comment                             as GrcCheckComment,
      b.blocked_on                                    as BlockedOn,
      b.blocked_at                                    as BlockedAt,
      b.blocked_by                                    as BlockedBy,
      b.block_comment                                 as BlockComment,
      b.split_comp_code                               as SplitCompCode,
      b.split_gst_doc_num                             as SplitGstDocNum,
      b.split_year                                    as SplitYear,
      b.split_on                                      as SplitOn,
      b.split_at                                      as SplitAt,
      b.split_by                                      as SplitBy,
      b.split_comment                                 as SplitComment,
      b.split_rev_comp_code                           as SplitRevCompCode,
      b.split_rev_doc_num                             as SplitRevDocNum,
      b.split_rev_year                                as SplitRevYear,
      b.split_rev_on                                  as SplitRevOn,
      b.split_rev_at                                  as SplitRevAt,
      b.split_rev_by                                  as SplitRevBy,
      b.split_rev_comment                             as SplitRevComment,
      b.jv_comp_code                                  as JvCompCode,
      b.jv_doc_num                                    as JvDocNum,
      b.jv_year                                       as JvYear,
      b.jv_posted_on                                  as JvPostedOn,
      b.jv_posted_at                                  as JvPostedAt,
      b.jv_posted_by                                  as JvPostedBy,
      b.jv_comment                                    as JvComment,
      b.jv_rev_comp_code                              as JvRevCompCode,
      b.jv_rev_doc_num                                as JvRevDocNum,
      b.jv_rev_year                                   as JvRevYear,
      b.jv_reversed_on                                as JvReversedOn,
      b.jv_reversed_at                                as JvReversedAt,
      b.jv_reversed_by                                as JvReversedBy,
      b.jv_rev_comment                                as JvRevComment,
      b.released_on                                   as ReleasedOn,
      b.released_at                                   as ReleasedAt,
      b.released_by                                   as ReleasedBy,
      b.release_comment                               as ReleaseComment,
      b.debit_note_comp                               as DebitNoteComp,
      b.debit_note_num                                as DebitNoteNum,
      b.debit_note_year                               as DebitNoteYear,
      b.debit_note_posted_on                          as DebitNotePostedOn,
      b.debit_note_posted_at                          as DebitNotePostedAt,
      b.debit_note_posted_by                          as DebitNotePostedBy,
      b.debit_note_comment                            as DebitNoteComment,
      b.debit_note_rev_comp                           as DebitNoteRevComp,
      b.debit_note_rev_num                            as DebitNoteRevNum,
      b.debit_note_rev_year                           as DebitNoteRevYear,
      b.debit_note_reversed_on                        as DebitNoteReversedOn,
      b.debit_note_reversed_at                        as DebitNoteReversedAt,
      b.debit_note_reversed_by                        as DebitNoteReversedBy,
      b.debit_note_rev_comment                        as DebitNoteRevComment,
      b.message                                       as Message,
      b.last_checked_on                               as LastCheckedOn,
      b.last_checked_at                               as LastCheckedAt,
      b.last_checked_by                               as LastCheckedBy,
      b.processing_options                            as ProcessingOptions,
      b.wronggst                                      as Wronggst,
      b.gstin                                         as Gstin,
      b.gstin_part                                    as GstinPart,
      b.remark                                        as Remark,

      cast( '' as meins )                             as uom,
      @Semantics.amount.currencyCode: 'Currency'
      a.igstamount + a.cgstamount + a.sgstamount      as TOTALTAX,
      cast( '' as abap.char( 4 ))                     as Procstat,
      cast( '' as abap.char( 1 ) )                    as Cbox,
      cast( '' as abap.char( 4 )  )                   as Recostat,
      cast( '' as abap.char( 50 ) )                   as Statusdesc,
      cast( '' as abap.char( 50 ) )                   as BlockTypeDesc,
      cast( '' as abap.char( 35 ) )                   as Vendorname,
      cast( '' as blart )                             as Blart,
      cast( '' as abap.char( 1 ) )                    as Qblock,
      cast( '' as abap.char( 20 ))                    as Msme,

      p.panno                                         as Panno,

      // MT_ACC_DATA ------------------------------------------------

      substring( a.custom9, 1, 4 )                    as MtAccDoc1_BUKRS,
      lpad( substring( a.custom1, 1, 10 ), 10, '0' )  as MtAccDoc1_BELNR,
      substring( a.custom4, 1, 4 )                    as MtAccDoc1_GJAHR,

      case when b.split_gst_doc_num is not null and b.split_gst_doc_num <> '' then b.split_comp_code
           else '' end                                as MtAccDoc2_BUKRS,
      case when b.split_gst_doc_num is not null and b.split_gst_doc_num <> '' then b.split_gst_doc_num
            else '' end                               as MtAccDoc2_BELNR,
      case when b.split_gst_doc_num is not null and b.split_gst_doc_num <> '' then b.split_year
            else cast( '0000' as abap.numc( 4 ) ) end as MtAccDoc2_GJAHR,

      case when b.jv_doc_num is not null and b.jv_doc_num <> '' then b.jv_comp_code
           else '' end                                as MtAccDoc3_BUKRS,
      case when b.jv_doc_num is not null and b.jv_doc_num <> '' then b.jv_doc_num
           else '' end                                as MtAccDoc3_BELNR,
      case when b.jv_doc_num is not null and b.jv_doc_num <> '' then b.jv_year
           else cast( '0000' as abap.numc( 4 ) ) end  as MtAccDoc3_GJAHR,

      case when b.jv_rev_doc_num is not null and b.jv_rev_doc_num <> '' then b.jv_rev_comp_code
           else '' end                                as MtAccDoc4_BUKRS,
      case when b.jv_rev_doc_num is not null and b.jv_rev_doc_num <> '' then b.jv_rev_doc_num
           else '' end                                as MtAccDoc4_BELNR,
      case when b.jv_rev_doc_num is not null and b.jv_rev_doc_num <> '' then b.jv_rev_year
           else cast( '0000' as abap.numc( 4 ) ) end  as MtAccDoc4_GJAHR,

      case when b.debit_note_num is not null and b.debit_note_num <> '' then b.debit_note_comp
           else '' end                                as MtAccDoc5_BUKRS,
      case when b.debit_note_num is not null and b.debit_note_num <> '' then b.debit_note_num
           else '' end                                as MtAccDoc5_BELNR,
      case when b.debit_note_num is not null and b.debit_note_num <> '' then b.debit_note_year
           else cast( '0000' as abap.numc( 4 ) ) end  as MtAccDoc5_GJAHR,

      case when b.debit_note_rev_num is not null and b.debit_note_rev_num <> '' then b.debit_note_rev_comp
           else '' end                                as MtAccDoc6_BUKRS,
      case when b.debit_note_rev_num is not null and b.debit_note_rev_num <> '' then b.debit_note_rev_num
          else '' end                                 as MtAccDoc6_BELNR,
      case when b.debit_note_rev_num is not null and b.debit_note_rev_num <> '' then b.debit_note_rev_year
          else cast( '0000' as abap.numc( 4 ) ) end   as MtAccDoc6_GJAHR

      // MT_ACC_DATA ------------------------------------------------

}
where
  c.reco_status is null
