@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Aggrigated FI TAX TOTAL'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R_MT_TAX_TOTAL
  as select from ZPB_R_MT_TAX_DATA
{
  key Bukrs,
  key Belnr,
  key Gjahr,
      @Semantics.amount.currencyCode: 'Currency'
      sum(
       case
           when shkzg = 'S' then hwste
           when shkzg = 'H' then hwste * -1
           else cast( 0 as abap.curr( 15, 2 ) )
           end

      )                                              as FiTaxTotal,

      Currency,
      mwskz,
      sum( cast( kbetr as abap.dec( 15, 2 ) ) / 10 ) as TaxRate
}
group by
  Bukrs,
  Belnr,
  Gjahr,
  Currency,
  mwskz
