@EndUserText.label: 'Abstract Entity for process'
define abstract entity ZPB_S_PROCESS_PARAM

{
      @EndUserText.label: 'PBF'
  key PBF    : abap_boolean;
      @EndUserText.label: 'JV'
      JV     : abap_boolean;
      @EndUserText.label: 'DBF'
      DBF    : abap_boolean;
      @EndUserText.label: 'DBF_CL'
      DBF_CL : abap_boolean;
      @EndUserText.label: 'DBF_OP'
      DBF_OP : abap_boolean;
      @EndUserText.label: 'DAF_CL'
      DAF_CL : abap_boolean;
      @EndUserText.label: 'DAF_OP'
      DAF_OP : abap_boolean;


}
