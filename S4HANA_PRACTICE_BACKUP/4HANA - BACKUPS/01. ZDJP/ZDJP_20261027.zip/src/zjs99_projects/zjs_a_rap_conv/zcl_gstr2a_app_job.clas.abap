
CLASS zcl_gstr2a_app_job DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_apj_dt_exec_object.
    INTERFACES if_apj_rt_exec_object.

ENDCLASS.


CLASS zcl_gstr2a_app_job IMPLEMENTATION.

  METHOD if_apj_dt_exec_object~get_parameters.

    et_parameter_def = VALUE #(
      (
        selname        = 'S_UP_DT'
        kind           = if_apj_dt_exec_object=>select_option
        datatype       = 'D'
        length         = 8
        param_text     = 'Upload Date'
        changeable_ind = abap_true
      )
    ).
  ENDMETHOD.

  METHOD if_apj_rt_exec_object~execute.
    DATA:
      lt_selection TYPE STANDARD TABLE OF rsparams,
      ls_selection TYPE rsparams.

    "Read the scheduled upload-date selection
    LOOP AT it_parameters INTO DATA(ls_parameter)
         WHERE selname = 'S_UP_DT'.

      CLEAR ls_selection.

      ls_selection-selname = 'S_UP_DT'.
      ls_selection-kind    = 'S'.
      ls_selection-sign    = ls_parameter-sign.
      ls_selection-option  = ls_parameter-option.
      ls_selection-low     = ls_parameter-low.
      ls_selection-high    = ls_parameter-high.

      APPEND ls_selection TO lt_selection.

    ENDLOOP.

    "Validate upload date
    IF NOT line_exists(
         lt_selection[ selname = 'S_UP_DT' ] ).
      RETURN.
    ENDIF.

    "Set GSTR2A radio button
    CLEAR ls_selection.

    ls_selection-selname = 'R_2A'.
    ls_selection-kind    = 'P'.
    ls_selection-sign    = 'I'.
    ls_selection-option  = 'EQ'.
    ls_selection-low     = abap_true.

    APPEND ls_selection TO lt_selection.

    "Execute existing report for GSTR2A only
    SUBMIT zcyg_gstr2a_report
      WITH SELECTION-TABLE lt_selection
      AND RETURN.
  ENDMETHOD.

ENDCLASS.

