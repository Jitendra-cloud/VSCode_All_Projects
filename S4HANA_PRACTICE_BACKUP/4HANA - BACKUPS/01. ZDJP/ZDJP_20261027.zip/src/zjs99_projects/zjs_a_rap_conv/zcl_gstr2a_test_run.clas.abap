CLASS zcl_gstr2a_test_run DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.

  PRIVATE SECTION.

    TYPES:
      BEGIN OF ty_gstin,
        gstin TYPE j_1bbranch-gstin,
      END OF ty_gstin,
      BEGIN OF ty_panno,
        panno TYPE zcyg_panno_exmp-panno,
      END OF ty_panno,
      BEGIN OF ty_collect_data,
        pr_custom_item1 TYPE char10,
        taxable_value   TYPE netwr,
        igst_amount     TYPE netwr,
        cgst_amount     TYPE netwr,
        sgst_amount     TYPE netwr,
        cess_amount     TYPE netwr,
      END OF ty_collect_data.

    DATA:
      mo_out                TYPE REF TO if_oo_adt_classrun_out,
      mv_token              TYPE string,
      mv_message            TYPE string,
      mv_error_system       TYPE string,
      mv_error_application  TYPE string,
      mv_request_failed     TYPE abap_bool,
      mv_from_uploaded      TYPE c LENGTH 25,
      mv_to_uploaded        TYPE c LENGTH 25,
      mv_begin              TYPE char20,
      mv_total_records      TYPE i,
      mv_count              TYPE i,
      mv_success            TYPE string,
      mv_reco_upper         TYPE c LENGTH 40,
      mv_docno              TYPE bkpf-belnr,
      mv_len_from           TYPE i,
      mv_len_to             TYPE i,
      mv_upload_date_from   TYPE sy-datum,
      mv_upload_date_to     TYPE sy-datum,
      mv_page_size          TYPE char10 VALUE '5000',
      mv_return_period_from TYPE zcy_tab_rrp_e-returnperiod,
      mv_return_period_to   TYPE zcy_tab_rrp_e-returnperiod.

    DATA:
      mt_gstin             TYPE STANDARD TABLE OF ty_gstin WITH EMPTY KEY,
      mt_branches          TYPE STANDARD TABLE OF j_1bbranch WITH EMPTY KEY,
      mt_panno             TYPE STANDARD TABLE OF ty_panno WITH EMPTY KEY,
      mt_locations         TYPE zdt_gstr2a_reconciliation_tab3,
      ms_location          TYPE zdt_gstr2a_reconciliation_req,
      ms_request           TYPE zmt_gstr2a_reconciliation_req,
      ms_response          TYPE zmt_gstr2a_reconciliation_res,
      mt_errors            TYPE STANDARD TABLE OF zdt_gstr2a_reconciliation_res4 WITH EMPTY KEY,
      ms_error             TYPE zdt_gstr2a_reconciliation_res4,
      mt_root              TYPE STANDARD TABLE OF zdt_gstr2a_reconciliation_res WITH EMPTY KEY,
      ms_root_row          TYPE zdt_gstr2a_reconciliation_res,
      ms_root_error        TYPE zdt_gstr2a_reconciliation_res3,
      mt_collect_data      TYPE HASHED TABLE OF ty_collect_data WITH UNIQUE KEY pr_custom_item1,
      ms_collect_data      TYPE ty_collect_data,
      mt_result            TYPE zdt_gstr2a_reconciliation_tab1,
      ms_result            TYPE zdt_gstr2a_reconciliation_res1,
      mt_result_items      TYPE STANDARD TABLE OF zdt_gstr2a_reconciliation_res2 WITH EMPTY KEY,
      ms_result_item       TYPE zdt_gstr2a_reconciliation_res2,
      mt_db_records        TYPE STANDARD TABLE OF zcy_tab_rrp_e WITH EMPTY KEY,
      ms_db_record         TYPE zcy_tab_rrp_e,
      mo_proxy             TYPE REF TO zco_si_gstr2a_reconciliation_o,
      mo_system_fault      TYPE REF TO cx_ai_system_fault,
      mo_application_fault TYPE REF TO cx_ai_application_fault.

    CONSTANTS:
      c_error   TYPE char5 VALUE 'Error',
      c_code    TYPE char7 VALUE 'VAL0114',
      c_source  TYPE char6 VALUE 'Gstr2a',
      c_purpose TYPE char4 VALUE 'OGST',
      c_supply  TYPE char1 VALUE 'P'.

    METHODS:
      send_request
        IMPORTING
          iv_begin TYPE char20
          iv_gstin TYPE j_1bbranch-gstin,
      get_root_error,
      get_response
        IMPORTING
          iv_gstin TYPE j_1bbranch-gstin.

ENDCLASS.


CLASS zcl_gstr2a_test_run IMPLEMENTATION.

  METHOD if_oo_adt_classrun~main.

  out->write( |Current SAP System ID: { sy-sysid }| ).

    DATA:
      lt_panno_raw TYPE STANDARD TABLE OF ty_panno WITH EMPTY KEY,
      ls_panno     TYPE ty_panno,
      ls_branch    TYPE j_1bbranch,
      ls_gstin     TYPE ty_gstin,
      lv_gstin     TYPE j_1bbranch-gstin,
      lv_no_record TYPE abap_bool.

    mo_out = out.

    "---------------------------------------------------------------
    " Upload date range: change these values for testing.
    " By default, the class processes today's upload date only.
    "---------------------------------------------------------------
    mv_upload_date_from = sy-datum.
    mv_upload_date_to   = sy-datum.

    "The original report defaults P_2 to 5000. S_MONTH and P_GSTIN
    "are not exposed here because the requested input is S_UP_DT only.
    CLEAR:
      mv_message,
      mv_total_records,
      mv_count,
      mv_success.

    "Build the DD-MM-YYYY dates required by the remote service.
    mv_from_uploaded = |{ mv_upload_date_from+6(2) }-{ mv_upload_date_from+4(2) }-{ mv_upload_date_from(4) }|.
    mv_to_uploaded   = |{ mv_upload_date_to+6(2) }-{ mv_upload_date_to+4(2) }-{ mv_upload_date_to(4) }|.

    "Read token used by the original report.
    SELECT SINGLE token
      FROM zei_po_link
      WHERE sysid = @sy-sysid
      INTO @mv_token.

    IF mv_token IS INITIAL.
      mo_out->write( `No token found in ZEI_PO_LINK for the current system ID.` ).
      RETURN.
    ENDIF.

    "Load exempted PAN numbers and sort for binary search.
    SELECT DISTINCT panno
      FROM zcyg_panno_exmp
      INTO TABLE @mt_panno.

    SORT mt_panno BY panno.

    "The original report processes all branch GSTINs when P_GSTIN
    "is not supplied. This class exposes only S_UP_DT, so use all GSTINs.
    SELECT *
      FROM j_1bbranch
      INTO TABLE @mt_branches.

    DELETE mt_branches WHERE gstin IS INITIAL.

    LOOP AT mt_branches INTO ls_branch.
      ls_gstin-gstin = ls_branch-gstin.
      APPEND ls_gstin TO mt_gstin.
      CLEAR ls_gstin.
    ENDLOOP.

    SORT mt_gstin BY gstin.
    DELETE ADJACENT DUPLICATES FROM mt_gstin COMPARING gstin.

    IF mt_gstin IS INITIAL.
      mo_out->write( `No GSTINs found in J_1BBRANCH.` ).
      RETURN.
    ENDIF.

    LOOP AT mt_gstin INTO ls_gstin.

      lv_gstin = ls_gstin-gstin.
      mv_begin = '0'.
      CLEAR:
        mv_total_records,
        mv_count,
        mv_message.

      mo_out->write( |Processing GSTIN { lv_gstin }| ).

      DO.
        send_request( iv_begin = mv_begin iv_gstin = lv_gstin ).
        IF mv_request_failed = abap_true.
          EXIT.
        ENDIF.

        IF ms_response-mt_gstr2a_reconciliation_res-root IS NOT INITIAL.
          get_root_error( ).
          mo_out->write( |Service error for GSTIN { lv_gstin }: { mv_message }| ).
          EXIT.
        ENDIF.

        IF ms_response-mt_gstr2a_reconciliation_res-errors IS NOT INITIAL.
          mt_errors = ms_response-mt_gstr2a_reconciliation_res-errors.
          READ TABLE mt_errors INTO ms_error WITH KEY code = c_code.
          IF sy-subrc = 0.
            mo_out->write( |{ ms_error-message } for GSTIN { lv_gstin }| ).
            EXIT.
          ENDIF.
        ENDIF.

        IF ms_response-mt_gstr2a_reconciliation_res-result IS NOT INITIAL.
          IF mv_count IS INITIAL.
            mv_count = lines( ms_response-mt_gstr2a_reconciliation_res-result ).
            mv_total_records = ms_response-mt_gstr2a_reconciliation_res-total_records.
          ELSE.
            mv_count = mv_count + lines( ms_response-mt_gstr2a_reconciliation_res-result ).
          ENDIF.

          get_response( iv_gstin = lv_gstin ).
        ENDIF.

        "Stop when all records reported by the service have been read.
        IF mv_count >= mv_total_records.
          EXIT.
        ENDIF.

        "Avoid a non-terminating loop if the service returns no rows
        "and does not provide a total record count.
        IF ms_response-mt_gstr2a_reconciliation_res-result IS INITIAL
           AND mv_total_records IS INITIAL.
          EXIT.
        ENDIF.

        mv_begin = mv_begin + mv_page_size.
      ENDDO.

      CLEAR:
        mv_message,
        mv_total_records,
        mv_count.
    ENDLOOP.

    mo_out->write( `GSTR2A processing completed.` ).

  ENDMETHOD.


  METHOD send_request.

    CLEAR:
      ms_request,
      ms_response,
      mt_locations,
      ms_location,
      mv_error_system,
      mv_error_application,
      mv_request_failed.

    "One GSTIN is processed per request.
    ms_location-location_gstin = iv_gstin.
    ms_location-location_name = ''.
    APPEND ms_location TO mt_locations.
    CLEAR ms_location.

    ms_request-mt_gstr2a_reconciliation_req-auth_token = mv_token.
    ms_request-mt_gstr2a_reconciliation_req-source = c_source.
    ms_request-mt_gstr2a_reconciliation_req-from_return_period = mv_return_period_from.
    ms_request-mt_gstr2a_reconciliation_req-to_return_period = mv_return_period_to.
    ms_request-mt_gstr2a_reconciliation_req-size = mv_page_size.
    ms_request-mt_gstr2a_reconciliation_req-start = iv_begin.
    CONDENSE ms_request-mt_gstr2a_reconciliation_req-start.
    ms_request-mt_gstr2a_reconciliation_req-from_reconciliation_date = mv_from_uploaded.
    ms_request-mt_gstr2a_reconciliation_req-to_reconciliation_date = mv_to_uploaded.
    ms_request-mt_gstr2a_reconciliation_req-is_aggregated_items = 'true'.

    ms_request-mt_gstr2a_reconciliation_req-locations = mt_locations.

    TRY.
        CREATE OBJECT mo_proxy.

        mo_proxy->si_gstr2a_reconciliation_obs(
          EXPORTING
            output = ms_request
          IMPORTING
            input  = ms_response ).

      CATCH cx_ai_system_fault INTO mo_system_fault.
        mv_request_failed = abap_true.
        mv_error_system = mo_system_fault->errortext.
        mo_out->write( |System fault calling GSTR2A service: { mv_error_system }| ).

      CATCH cx_ai_application_fault INTO mo_application_fault.
        mv_request_failed = abap_true.
        mv_error_application = mo_application_fault->get_text( ).
        mo_out->write( |Application fault calling GSTR2A service: { mv_error_application }| ).
    ENDTRY.

  ENDMETHOD.


  METHOD get_root_error.

    CLEAR mv_message.

    IF ms_response-mt_gstr2a_reconciliation_res-root IS NOT INITIAL.
      mt_root = ms_response-mt_gstr2a_reconciliation_res-root.

      LOOP AT mt_root INTO ms_root_row.
        READ TABLE ms_root_row-errors INTO ms_root_error
          WITH KEY type = c_error.

        IF sy-subrc = 0.
          IF mv_message IS INITIAL.
            mv_message = ms_root_error-message.
          ELSE.
            CONCATENATE mv_message ms_root_error-message
              INTO mv_message SEPARATED BY '|'.
          ENDIF.
        ENDIF.

        CLEAR:
          ms_root_row,
          ms_root_error.
      ENDLOOP.
    ENDIF.

  ENDMETHOD.


  METHOD get_response.

    DATA:
      ls_panno_local TYPE ty_panno,
      lv_docno       TYPE bkpf-belnr,
      lv_len_from    TYPE i,
      lv_len_to      TYPE i.

    IF ms_response-mt_gstr2a_reconciliation_res-result IS INITIAL.
      RETURN.
    ENDIF.

    mt_result = ms_response-mt_gstr2a_reconciliation_res-result.

    LOOP AT mt_result INTO ms_result.

      CLEAR ms_db_record.

      ms_db_record-returnperiod      = ms_result-pr_return_period.
      ms_db_record-locationgstin     = ms_result-location_gstin.
      ms_db_record-billfromgstin     = ms_result-pr_gstin.
      ms_db_record-documentnumber    = ms_result-pr_document_number.
      ms_db_record-cpdocumentnumber  = ms_result-cp_document_number.

      IF ms_result-pr_document_date IS NOT INITIAL.
        CONCATENATE ms_result-pr_document_date+6(4)
                    ms_result-pr_document_date+3(2)
                    ms_result-pr_document_date+0(2)
          INTO ms_db_record-documentdate.
      ENDIF.

      IF ms_result-cp_document_date IS NOT INITIAL.
        CONCATENATE ms_result-cp_document_date+6(4)
                    ms_result-cp_document_date+3(2)
                    ms_result-cp_document_date+0(2)
          INTO ms_db_record-cpdocumentdate.
      ENDIF.

      ms_db_record-custom4                = ms_result-pr_custom4.
      ms_db_record-custom9                = ms_result-pr_custom9.
      ms_db_record-supplytype             = c_supply.
      ms_db_record-purpose                = c_purpose.
      ms_db_record-locationname           = ms_result-location_name.
      ms_db_record-irn                    = ms_result-cp_irn.
      ms_db_record-documenttype           = ms_result-document_type.
      ms_db_record-transactiontype        = ms_result-pr_transaction_type.
      ms_db_record-cpfilingdate           = ms_result-cp_filing_date.
      ms_db_record-filingdate             = ms_result-cp_filing_date.
      ms_db_record-cptransactiontype      = ms_result-cp_transaction_type.
      ms_db_record-taxpayertype           = ms_result-pr_tax_payer_type.
      ms_db_record-cptaxpayertype         = ms_result-cp_tax_payer_type.
      ms_db_record-billfromlegalname      = ms_result-cp_legal_name.
      ms_db_record-billfromtradename      = ms_result-cp_trade_name.
      ms_db_record-billtogstin            = ms_result-location_gstin.
      ms_db_record-billtolegalname        = ms_result-pr_legal_name.
      ms_db_record-billtotradename        = ms_result-pr_trade_name.
      ms_db_record-pos                    = ms_result-pr_pos.
      ms_db_record-documentvalue          = ms_result-pr_value.
      ms_db_record-cpvalue                = ms_result-cp_value.
      ms_db_record-cporiginaldocumentnumber = ms_result-cp_original_document_number.
      ms_db_record-cporiginaldocumentdate  = ms_result-cp_original_document_date.
      ms_db_record-cporiginalreturnperiod  = ms_result-cp_return_period.
      ms_db_record-cpirngenerationdate     = ms_result-cp_irn_generation_date.
      ms_db_record-cpisamendment           = ms_result-cp_is_amendment.
      ms_db_record-custom2                = ms_result-pr_custom2.
      ms_db_record-custom3                = ms_result-pr_custom3.
      ms_db_record-custom5                = ms_result-pr_custom5.
      ms_db_record-custom6                = ms_result-pr_custom6.
      ms_db_record-custom7                = ms_result-pr_custom7.
      ms_db_record-custom8                = ms_result-pr_custom8.
      ms_db_record-custom10               = ms_result-pr_custom10.
      ms_db_record-custom20               = ms_result-pr_custom20.
      ms_db_record-reversecharge          = ms_result-pr_reverse_charge.
      ms_db_record-pushstatus             = ms_result-action_status.
      ms_db_record-gstaction              = ms_result-action.
      ms_db_record-reconciliationsection  = ms_result-reconciliation_section.
      ms_db_record-taxdiff                = ms_result-tax_difference.
      ms_db_record-taxablediff            = ms_result-taxable_difference.
      ms_db_record-valuediff              = ms_result-value_difference.
      ms_db_record-itcclaimreturnperiod   = ms_result-pr_itc_claim_month.

      mv_reco_upper = ms_db_record-reconciliationsection.
      TRANSLATE mv_reco_upper TO UPPER CASE.
      ms_db_record-reconciliationsection = mv_reco_upper.

      ms_db_record-reason          = ms_result-reason.
      ms_db_record-cpfilingstatus  = ms_result-cp_filing_status.
      ms_db_record-cptaxpayertype  = ms_result-cp_tax_payer_type.

      IF ms_result-reconciliation_date_time IS NOT INITIAL.
        CONCATENATE ms_result-reconciliation_date_time+6(4)
                    ms_result-reconciliation_date_time+3(2)
                    ms_result-reconciliation_date_time(2)
          INTO ms_db_record-rec_date.
        CONCATENATE ms_result-reconciliation_date_time+11(2)
                    ms_result-reconciliation_date_time+14(2)
                    ms_result-reconciliation_date_time+17(2)
          INTO ms_db_record-rec_time.
      ENDIF.

      mt_result_items = ms_result-pr_items.

      CLEAR mt_collect_data.
      LOOP AT mt_result_items INTO ms_result_item.
        CLEAR ms_collect_data.
        ms_collect_data-pr_custom_item1 = ms_result_item-pr_custom_item1.
        ms_collect_data-taxable_value   = ms_result_item-pr_taxable_value.
        ms_collect_data-igst_amount     = ms_result_item-pr_igst_amount.
        ms_collect_data-cgst_amount     = ms_result_item-pr_cgst_amount.
        ms_collect_data-sgst_amount     = ms_result_item-pr_sgst_amount.
        ms_collect_data-cess_amount     = ms_result_item-pr_cess_amount.
        COLLECT ms_collect_data INTO mt_collect_data.
      ENDLOOP.

      LOOP AT mt_collect_data INTO ms_collect_data.

        READ TABLE mt_result_items INTO ms_result_item
          WITH KEY pr_custom_item1 = ms_collect_data-pr_custom_item1.

        IF sy-subrc = 0.
          ms_db_record-hsn             = ms_result_item-pr_hsn.
          ms_db_record-rate            = ms_result_item-pr_rate.
          ms_db_record-itceligibility  = ms_result_item-pr_itc_eligibility.
          ms_db_record-customitem1     = ms_result_item-pr_custom_item1.
          ms_db_record-customitem2     = ms_result_item-pr_custom_item2.
          ms_db_record-customitem3     = ms_result_item-pr_custom_item3.
          ms_db_record-customitem4     = ms_result_item-pr_custom_item4.
          ms_db_record-customitem5     = ms_result_item-pr_custom_item5.
          ms_db_record-customitem6     = ms_result_item-pr_custom_item6.
          ms_db_record-customitem7     = ms_result_item-pr_custom_item7.
          ms_db_record-customitem8     = ms_result_item-pr_custom_item8.
          ms_db_record-customitem9     = ms_result_item-pr_custom_item9.
          ms_db_record-customitem10    = ms_result_item-pr_custom_item10.
        ENDIF.

        ms_db_record-taxablevalue = ms_collect_data-taxable_value.
        ms_db_record-igstamount  = ms_collect_data-igst_amount.
        ms_db_record-cgstamount   = ms_collect_data-cgst_amount.
        ms_db_record-sgstamount   = ms_collect_data-sgst_amount.
        ms_db_record-cessamount   = ms_collect_data-cess_amount.

        CLEAR lv_docno.
        IF ms_result-pr_custom1 IS NOT INITIAL.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = ms_result-pr_custom1
            IMPORTING
              output = lv_docno.
        ENDIF.

        ms_db_record-custom1 = lv_docno.

        IF ms_db_record-custom1 IS INITIAL.
          CLEAR ms_db_record.
          CONTINUE.
        ENDIF.

        lv_len_from = strlen( ms_db_record-billfromgstin ).
        lv_len_to   = strlen( ms_db_record-billtogstin ).

        IF lv_len_from > 12 AND lv_len_to > 12.
          READ TABLE mt_panno INTO ls_panno_local
            WITH KEY panno = ms_db_record-billfromgstin+2(10)
            BINARY SEARCH.

          IF sy-subrc <> 0.
            IF ms_db_record-billfromgstin+2(10)
               <> ms_db_record-billtogstin+2(10).
              APPEND ms_db_record TO mt_db_records.
            ENDIF.
          ENDIF.
        ELSE.
          APPEND ms_db_record TO mt_db_records.
        ENDIF.

        CLEAR:
          ms_collect_data,
          mv_reco_upper,
          ms_result_item,
          lv_len_from,
          lv_len_to.
      ENDLOOP.

      CLEAR:
        ms_db_record,
        mt_collect_data,
        mt_result_items.
    ENDLOOP.

    "Retain the original GSTR2A exclusion rules.
    DELETE mt_db_records WHERE reconciliationsection = 'GSTONLY'.
    DELETE mt_db_records WHERE reversecharge = 'Y'.
    DELETE mt_db_records WHERE documenttype = 'CRN'.
    DELETE mt_db_records WHERE documenttype = 'CAN'.
    DELETE mt_db_records WHERE transactiontype = 'IMPG'.
    DELETE mt_db_records WHERE transactiontype = 'IMPS'.

    IF mt_db_records IS NOT INITIAL.
      MODIFY zcy_tab_rrp_e FROM TABLE @mt_db_records.
      IF sy-subrc = 0.
        COMMIT WORK AND WAIT.
        mo_out->write(
          |GSTIN { iv_gstin }: saved { lines( mt_db_records ) } record(s).|
        ).
      ELSE.
        ROLLBACK WORK.
        mo_out->write( |GSTIN { iv_gstin }: database update failed.| ).
      ENDIF.
    ELSE.
      mo_out->write( |GSTIN { iv_gstin }: no records to save after filtering.| ).
    ENDIF.

    CLEAR mt_db_records.

  ENDMETHOD.

ENDCLASS.

