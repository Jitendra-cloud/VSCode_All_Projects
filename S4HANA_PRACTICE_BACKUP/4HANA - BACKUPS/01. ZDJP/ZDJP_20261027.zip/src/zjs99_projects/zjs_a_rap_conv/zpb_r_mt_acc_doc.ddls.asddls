@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ZPB_R_MT_ACC_DOC'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R_MT_ACC_DOC
  as select from ZPB_I_2A_PAY_BLOCK_LY1
{
  Custom9 as BUKRS,
  Custom1 as BELNR,
  Custom4 as GJAHR

}

union all

select from ZPB_I_2A_PAY_BLOCK_LY1
{
  MtAccDoc2_BUKRS as BUKRS,
  MtAccDoc2_BELNR as BELNR,
  MtAccDoc2_GJAHR as GJAHR
}

union all

select from ZPB_I_2A_PAY_BLOCK_LY1
{
  MtAccDoc3_BUKRS as BUKRS,
  MtAccDoc3_BELNR as BELNR,
  MtAccDoc3_GJAHR as GJAHR
}

union all

select from ZPB_I_2A_PAY_BLOCK_LY1
{
  MtAccDoc4_BUKRS as BUKRS,
  MtAccDoc4_BELNR as BELNR,
  MtAccDoc4_GJAHR as GJAHR
}

union all

select from ZPB_I_2A_PAY_BLOCK_LY1
{
  MtAccDoc5_BUKRS as BUKRS,
  MtAccDoc5_BELNR as BELNR,
  MtAccDoc5_GJAHR as GJAHR
}

union all

select from ZPB_I_2A_PAY_BLOCK_LY1
{
  MtAccDoc6_BUKRS as BUKRS,
  MtAccDoc6_BELNR as BELNR,
  MtAccDoc6_GJAHR as GJAHR
};
