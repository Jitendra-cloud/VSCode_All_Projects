@EndUserText.label: 'Abstract Entity for status'
define abstract entity ZPB_A_STATUS
  
{
    @EndUserText.label: 'pbf'
    
    pbf : abap_boolean;
    @EndUserText.label: 'jv'
    jv : abap_boolean;
    @EndUserText.label: 'dbf'
    dbf : abap_boolean;
    
}
