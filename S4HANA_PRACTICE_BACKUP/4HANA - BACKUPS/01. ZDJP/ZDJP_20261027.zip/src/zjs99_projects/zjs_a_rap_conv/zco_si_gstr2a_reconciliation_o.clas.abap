CLASS zco_si_gstr2a_reconciliation_o DEFINITION
  PUBLIC
  INHERITING FROM cl_proxy_client
  CREATE PUBLIC .

  PUBLIC SECTION.

    METHODS constructor
      IMPORTING
        !logical_port_name TYPE prx_logical_port_name OPTIONAL
      RAISING
        cx_ai_system_fault .
    METHODS si_gstr2a_reconciliation_obs
      IMPORTING
        !output TYPE zmt_gstr2a_reconciliation_req
      EXPORTING
        !input  TYPE zmt_gstr2a_reconciliation_res
      RAISING
        cx_ai_system_fault .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS zco_si_gstr2a_reconciliation_o IMPLEMENTATION.


  METHOD constructor.

    super->constructor(
      class_name          = 'ZCO_SI_GSTR2A_RECONCILIATION_O'
      logical_port_name   = logical_port_name
    ).

  ENDMETHOD.


  METHOD si_gstr2a_reconciliation_obs.

    DATA:
      ls_parmbind TYPE abap_parmbind,
      lt_parmbind TYPE abap_parmbind_tab.

    ls_parmbind-name = 'OUTPUT'.
    ls_parmbind-kind = cl_abap_objectdescr=>importing.
    GET REFERENCE OF output INTO ls_parmbind-value.
    INSERT ls_parmbind INTO TABLE lt_parmbind.

    ls_parmbind-name = 'INPUT'.
    ls_parmbind-kind = cl_abap_objectdescr=>exporting.
    GET REFERENCE OF input INTO ls_parmbind-value.
    INSERT ls_parmbind INTO TABLE lt_parmbind.

    if_proxy_client~execute(
      EXPORTING
        method_name = 'SI_GSTR2A_RECONCILIATION_OBS'
      CHANGING
        parmbind_tab = lt_parmbind
    ).

  ENDMETHOD.
ENDCLASS.
