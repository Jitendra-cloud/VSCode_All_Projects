@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Combined Vendor Block Type'
@Metadata.ignorePropagatedAnnotations: true

define view entity ZPB_R_VENDOR_BLOCK_TYPE
  as select from ZPB_R_VEND_BLOCK_DIRECT
{
  key vendor,
      vendor_block_type,
      grc_check_applicable
}

union

select from ZPB_R_VEND_BLOCK_GROUP
{
  key vendor,
      vendor_block_type,
      grc_check_applicable
}
