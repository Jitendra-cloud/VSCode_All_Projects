*&---------------------------------------------------------------------*
*&  Include           ZFI_GSTR2A_UPDATE_TOP
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_str_gstin,
         gstin TYPE j_1bbranch-gstin,
       END OF ty_str_gstin,

       BEGIN OF ty_panno,
         panno TYPE zcyg_panno_exmp-panno,
       END OF ty_panno.

TYPES: BEGIN OF ty_str_collect_data_item,
         pr_custom_item1 TYPE char10,
         taxable_value   TYPE netwr,
         igst_amount     TYPE netwr,
         cgst_amount     TYPE netwr,
         sgst_amount     TYPE netwr,
         cess_amount     TYPE netwr,
       END OF ty_str_collect_data_item.

DATA: w_token            TYPE string,
      w_msg1             TYPE string,
      w_msg              TYPE string,
      w_msg2             TYPE string,
      w_error1           TYPE string,
      w_error2           TYPE string,
      w_fromuploadeddate TYPE c LENGTH 25,
      w_touploadeddate   TYPE c LENGTH 25,
      w_cal_date         TYPE sy-datum,
      w_months           TYPE t5a4a-dlymo,
      w_years            TYPE t5a4a-dlyyr,
      w_gjahr            TYPE t009b-bdatj,
      w_docno            TYPE bkpf-belnr,
      w_tot_records      TYPE char10,
      w_count            TYPE char10,
      w_success          TYPE string,
      w_reco_upper(40)   TYPE c,
      w_begin            TYPE char20.

DATA: it_tab_zcy_tab_gstin    TYPE TABLE OF ty_str_gstin,
      is_str_zcy_tab_gstin    TYPE ty_str_gstin,
      it_g_tab_zcy_tab_gstin1 TYPE TABLE OF j_1bbranch,
      is_g_str_zcy_tab_gstin1 TYPE j_1bbranch,
      it_panno                TYPE STANDARD TABLE OF ty_panno,
      is_panno                TYPE ty_panno.

DATA: it_output_auth2       TYPE zmt_gstr2a_reconciliation_req,
      it_input_auth2        TYPE zmt_gstr2a_reconciliation_res,
      it_locations          TYPE zdt_gstr2a_reconciliation_tab3,
      is_locations          TYPE zdt_gstr2a_reconciliation_req,
      it_error              TYPE TABLE OF zdt_gstr2a_reconciliation_res4,
      is_message            TYPE zdt_gstr2a_reconciliation_res4,
      it_root               TYPE TABLE OF zdt_gstr2a_reconciliation_res,
      is_erros1             TYPE zdt_gstr2a_reconciliation_res,
      is_root               TYPE zdt_gstr2a_reconciliation_res3,
      it_collect_data       TYPE TABLE OF ty_str_collect_data_item,
      is_collect_data       TYPE ty_str_collect_data_item,
      it_zcy_tab_rrp_e_temp TYPE TABLE OF zcy_tab_rrp_e,
      is_zcy_tab_rrp_e_temp TYPE zcy_tab_rrp_e,
      it_data               TYPE zdt_gstr2a_reconciliation_tab1,
      is_data               TYPE zdt_gstr2a_reconciliation_res1,
      it_data_items         TYPE TABLE OF zdt_gstr2a_reconciliation_res2,
      is_data_items         TYPE zdt_gstr2a_reconciliation_res2.

DATA: z_otc_cl_exception1 TYPE REF TO cx_ai_system_fault,
      z_otc_cl_app_fault  TYPE REF TO cx_ai_application_fault,
      g_ref_send_data     TYPE REF TO zco_si_gstr2a_reconciliation_o.

CONSTANTS : c_code    TYPE char7  VALUE 'VAL0114'.
CONSTANTS : c_error   TYPE char5  VALUE 'Error'.
CONSTANTS : c_cyg_2a  TYPE char6  VALUE 'Gstr2a'.
CONSTANTS : c_ogst    TYPE char4  VALUE 'OGST'.
CONSTANTS : c_p       TYPE char1  VALUE 'P'.

***************** GSTR6A

DATA: it_output_auth_6a TYPE zmt_gstr6a_rconciliation_req,
      it_locations6a    TYPE zdt_gstr6a_rconciliation__tab3,
      is_locations6a    TYPE zdt_gstr6a_rconciliation_req_l,
      g_ref_send_data6a TYPE REF TO zco_si_gstr6a_rconciliation_ob,
*      IT_OUTPUT_AUTH6A  TYPE ZMT_GSTR6A_RCONCILIATION_REQ,
      it_input_auth6a   TYPE zmt_gstr6a_rconciliation_res,
      it_root6a         TYPE TABLE OF zdt_gstr6a_rconciliation_res_r,
      is_erros6a        TYPE zdt_gstr6a_rconciliation_res_r,
      is_root6a         TYPE zdt_gstr6a_rconciliation_res_e,
      it_error6a        TYPE TABLE OF zdt_gstr6a_rconciliation_res_2,
      is_message6a      TYPE zdt_gstr6a_rconciliation_res_2.

CONSTANTS : c_cyg_6a  TYPE char20 VALUE 'ReturnPeriodTillDate'.

DATA: it_data6a       TYPE zdt_gstr6a_rconciliation__tab1,
      is_data6a       TYPE zdt_gstr6a_rconciliation_res_1,
      it_data6a_items TYPE TABLE OF zdt_gstr6a_rconciliation_res_p,
      is_data6a_items TYPE zdt_gstr6a_rconciliation_res_p.

DATA: len_from TYPE int4,
      len_to   TYPE int4.
