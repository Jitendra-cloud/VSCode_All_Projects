@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ZPB_R_MT_TAX_DATA'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R_MT_TAX_DATA
  as select from    bset as a
    left outer join t001 as t on a.bukrs = t.bukrs

{
  key a.bukrs as Bukrs,
  key a.belnr as Belnr,
  key a.gjahr as Gjahr,
  key a.buzei as Buzei,
      a.mwskz,
      a.txgrp,
      a.taxps,
      a.ktosl,
      a.kschl,
      @Semantics.amount.currencyCode: 'Currency'
      a.kbetr,
      @Semantics.amount.currencyCode: 'Currency'
      a.hwbas,
      @Semantics.amount.currencyCode: 'Currency'
      a.hwste,
      a.shkzg,
      a.hkont,
      t.waers as Currency

}
