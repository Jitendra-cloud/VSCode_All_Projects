
CLASS lhc_PayBlock DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR PayBlock RESULT result.





    METHODS unblock FOR MODIFY
      IMPORTING keys FOR ACTION PayBlock~unblock RESULT result.
    METHODS process FOR MODIFY
      IMPORTING keys FOR ACTION PayBlock~process.
    METHODS pbf FOR MODIFY
      IMPORTING keys FOR ACTION PayBlock~pbf RESULT result.



ENDCLASS.

CLASS lhc_PayBlock IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.



  METHOD unblock.

    DATA:
      lo_processor TYPE REF TO zcl_pb_processor,
      lt_update    TYPE TABLE FOR UPDATE zpb_i_2a_pay_block_ly4.

    "------------------------------------------------------------
    " Read selected PayBlock records
    "------------------------------------------------------------
    READ ENTITIES OF zpb_i_2a_pay_block_ly4 IN LOCAL MODE
      ENTITY PayBlock
      ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_data)
      FAILED DATA(lt_read_failed)
      REPORTED DATA(lt_read_reported).

    "Pass read failures and messages to the RAP response
    APPEND LINES OF lt_read_failed-payblock TO failed-payblock.
    APPEND LINES OF lt_read_reported-payblock TO reported-payblock.

    IF lt_data IS INITIAL.
      RETURN.
    ENDIF.

    "------------------------------------------------------------
    " Initialize processor
    "------------------------------------------------------------
    "These are the existing constructor parameters.
    "Unblock itself does not require the process-action parameters.
    READ ENTITIES OF zpb_i_2a_pay_block_ly4 IN LOCAL MODE
      ENTITY PayBlock
      ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_Unb_data)
      FAILED DATA(lt_Unb_failed)
      REPORTED DATA(lt_Unb_reported).



*    DATA(ls_param) = keys[ 1 ]-%param.
    DATA(wa_Unb_data) = lt_Unb_data[ 1 ].

    lo_processor = NEW zcl_pb_processor(
      iv_p_pbf    = wa_Unb_data-p_pbf
        iv_p_jv     = wa_Unb_data-p_jv
        iv_p_dbf    = wa_Unb_data-p_dbf
        iv_p_daf    = wa_Unb_data-p_daf
        iv_p_dbf_cl = wa_Unb_data-p_dbf_cl
        iv_p_dbf_op = wa_Unb_data-p_dbf_op
        iv_p_daf_cl = wa_Unb_data-p_daf_cl
        iv_p_daf_op = wa_Unb_data-p_daf_op
    ).

    "------------------------------------------------------------
    " Process each selected document
    "------------------------------------------------------------
    LOOP AT lt_data ASSIGNING FIELD-SYMBOL(<data>).

      DATA(ls_data) =
        CORRESPONDING zpb_i_2a_pay_block_ly4( <data> ).

      "Execute the unblock business logic
      lo_processor->unblock(
        CHANGING
          cs_data = ls_data
      ).

      "Collect the changed fields for the RAP update
      APPEND VALUE #(
        %tky              = <data>-%tky

        status            = ls_data-status
        message           = ls_data-message

        debitnotecomp     = ls_data-debitnotecomp
        debitnotenum      = ls_data-debitnotenum
        debitnoteyear     = ls_data-debitnoteyear
        debitnotepostedon = ls_data-debitnotepostedon
        debitnotepostedat = ls_data-debitnotepostedat
        debitnotepostedby = ls_data-debitnotepostedby
        debitnotecomment  = ls_data-debitnotecomment

        jvcompcode        = ls_data-jvcompcode
        jvdocnum          = ls_data-jvdocnum
        jvyear            = ls_data-jvyear
        jvpostedon        = ls_data-jvpostedon
        jvpostedat        = ls_data-jvpostedat
        jvpostedby        = ls_data-jvpostedby
        jvcomment         = ls_data-jvcomment

      ) TO lt_update.

      "Return the changed entity as the action result
      APPEND VALUE #(
        %tky   = <data>-%tky
        %param = CORRESPONDING #( ls_data )
      ) TO result.

    ENDLOOP.

    "------------------------------------------------------------
    " Persist changed fields through RAP
    "------------------------------------------------------------
    IF lt_update IS NOT INITIAL.

      MODIFY ENTITIES OF zpb_i_2a_pay_block_ly4 IN LOCAL MODE
        ENTITY PayBlock
        UPDATE FIELDS (
          status
          message
          debitnotecomp
          debitnotenum
          debitnoteyear
          debitnotepostedon
          debitnotepostedat
          debitnotepostedby
          debitnotecomment
          jvcompcode
          jvdocnum
          jvyear
          jvpostedon
          jvpostedat
          jvpostedby
          jvcomment
        )
        WITH lt_update
        FAILED DATA(lt_update_failed)
        REPORTED DATA(lt_update_reported).

      APPEND LINES OF lt_update_failed-payblock
        TO failed-payblock.

      APPEND LINES OF lt_update_reported-payblock
        TO reported-payblock.

    ENDIF.

  ENDMETHOD.

  METHOD process.


*    SELECT bukrs,
*           belnr,
*           gjahr,
*           buzei,
*           shkzg,
*           hwste,
*           mwskz
*      FROM bset
*      WHERE bukrs = '1000'
*        AND belnr = '5325000002'
*        AND gjahr = '2026'
*      INTO TABLE @DATA(lt_tax).





    DATA lo_processor TYPE REF TO zcl_pb_processor.

*    AUTHORITY-CHECK OBJECT 'ZCYG_BUPLA'
*      ID 'ACTVT' FIELD '01'.
*
*    IF sy-subrc <> 0.
*
*      AUTHORITY-CHECK OBJECT 'ZCYG_BUPLA'
*        ID 'ACTVT' FIELD '02'.
*
*    ENDIF.
*
*    IF sy-subrc <> 0.
*
*      LOOP AT keys ASSIGNING FIELD-SYMBOL(<key>).
*
*        APPEND VALUE #(
*          %tky = <key>-%cid
*        ) TO failed-payblock.
*
*        APPEND VALUE #(
*          %tky = <key>-%cid
*          %msg = new_message(
*            id       = 'ZPB'
*            number   = '001'
*            severity = if_abap_behv_message=>severity-error
*            v1 =
*              'You are not Authorized for Process for Block/Unblock'
*          )
*        ) TO reported-payblock.
*
*      ENDLOOP.
*
*      RETURN.
*
*    ENDIF.



    READ ENTITIES OF zpb_i_2a_pay_block_ly4 IN LOCAL MODE
      ENTITY PayBlock
      ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_data)
      FAILED DATA(lt_failed)
      REPORTED DATA(lt_reported).



*    DATA(ls_param) = keys[ 1 ]-%param.
    DATA(wa_data1) = lt_data[ 1 ] .

    lo_processor =
      NEW zcl_pb_processor(
        iv_p_pbf    = wa_data1-p_pbf
        iv_p_jv     = wa_data1-p_jv
        iv_p_dbf    = wa_data1-p_dbf
        iv_p_daf    = wa_data1-p_daf
        iv_p_dbf_cl = wa_data1-p_dbf_cl
        iv_p_dbf_op = wa_data1-p_dbf_op
        iv_p_daf_cl = wa_data1-p_daf_cl
        iv_p_daf_op = wa_data1-p_daf_op  ).

*--------------------------------------------------------------------*
* Process selected documents
*--------------------------------------------------------------------*

    LOOP AT lt_data ASSIGNING FIELD-SYMBOL(<data>).

      DATA(ls_data) = CORRESPONDING zpb_i_2a_pay_block_ly4( <data> ).
      lo_processor->process(
        CHANGING
          cs_data = ls_data ).


      <data>-status         = ls_data-status.
      <data>-message        = ls_data-message.
      <data>-releasecomment = ls_data-releasecomment.
      <data>-releasedon     = ls_data-releasedon.
      <data>-releasedat     = ls_data-releasedat.
      <data>-releasedby     = ls_data-releasedby.

      <data>-jvrevcompcode  = ls_data-jvrevcompcode.
      <data>-jvrevdocnum    = ls_data-jvrevdocnum.
      <data>-jvrevyear      = ls_data-jvrevyear.
      <data>-jvrevcomment   = ls_data-jvrevcomment.
      <data>-jvreversedon   = ls_data-jvreversedon.
      <data>-jvreversedat   = ls_data-jvreversedat.
      <data>-jvreversedby   = ls_data-jvreversedby.

      <data>-splityear      = ls_data-splityear.



*--------------------------------------------------------------------*
* Update RAP entity
*--------------------------------------------------------------------*

*      MODIFY ENTITIES OF zpb_i_2a_pay_block_ly4 IN LOCAL MODE
*        ENTITY PayBlock
*        UPDATE FIELDS (
*          status
*          message
*          releasecomment
*          releasedon
*          releasedat
*          releasedby
*          jvrevcompcode
*          jvrevdocnum
*          jvrevyear
*          jvrevcomment
*          jvreversedon
*          jvreversedat
*          jvreversedby
*          splityear
*        )
*        WITH VALUE #(
*          (
*            %tky = <data>-%tky
*
*            status = <data>-status
*            message = <data>-message
*            releasecomment = <data>-releasecomment
*            releasedon = <data>-releasedon
*            releasedat = <data>-releasedat
*            releasedby = <data>-releasedby
*
*            jvrevcompcode = <data>-jvrevcompcode
*            jvrevdocnum = <data>-jvrevdocnum
*            jvrevyear = <data>-jvrevyear
*            jvrevcomment = <data>-jvrevcomment
*            jvreversedon = <data>-jvreversedon
*            jvreversedat = <data>-jvreversedat
*            jvreversedby = <data>-jvreversedby
*
*            splityear = <data>-splityear
*          )
*        ).

*--------------------------------------------------------------------*
* Return result
*--------------------------------------------------------------------*

*      APPEND VALUE #(
*        %tky = <data>-%tky
*      ) TO result.

    ENDLOOP.

  ENDMETHOD.





  METHOD pbf.



    DATA: lv_pbf TYPE abap_bool,
          lv_jv  TYPE abap_bool,
          lv_dbf TYPE abap_bool.

*    READ TABLE keys INTO DATA(ls_keys) INDEX 1.
    IF keys IS INITIAL.
      RETURN.
    ENDIF.

    DATA(wa_action_key) = keys[ 1 ].
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.


    lv_pbf = wa_action_key-%param-pbf.
    lv_jv  = wa_action_key-%param-jv.
    lv_dbf = wa_action_key-%param-dbf.

    UPDATE zcy_tab_rrp_e
         SET p_pbf = @lv_pbf,
             p_dbf = @lv_dbf,
             p_jv = @lv_jv.




  ENDMETHOD.

ENDCLASS.
