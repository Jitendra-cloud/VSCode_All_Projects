@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ZPB_R_MT_ACC_DOC_F'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R_MT_ACC_DOC_F
  as select distinct from ZPB_R_MT_ACC_DOC
{
  key BUKRS,
  key BELNR,
  key GJAHR
}
