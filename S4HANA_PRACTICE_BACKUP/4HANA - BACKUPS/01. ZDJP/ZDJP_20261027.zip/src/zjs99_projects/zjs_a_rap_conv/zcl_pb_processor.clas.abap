CLASS zcl_pb_processor DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.

    METHODS constructor
      IMPORTING
        iv_p_pbf    TYPE abap_boolean
        iv_p_jv     TYPE abap_boolean
        iv_p_dbf    TYPE abap_boolean
        iv_p_daf    TYPE abap_boolean
        iv_p_dbf_cl TYPE abap_boolean
        iv_p_dbf_op TYPE abap_boolean
        iv_p_daf_cl TYPE abap_boolean
        iv_p_daf_op TYPE abap_boolean
        iv_p_block  TYPE abap_boolean OPTIONAL
        iv_p_split  TYPE abap_boolean OPTIONAL
        iv_p_deb_n  TYPE abap_boolean OPTIONAL.

    METHODS unblock
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS process
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

  PROTECTED SECTION.

  PRIVATE SECTION.

    CONSTANTS:
      BEGIN OF mcs_doc_status,
        unprocessed             TYPE zcy_t_2a_pay_blk-status VALUE '',
        blocked                 TYPE zcy_t_2a_pay_blk-status VALUE 'B',
        split                   TYPE zcy_t_2a_pay_blk-status VALUE 'S',
        released                TYPE zcy_t_2a_pay_blk-status VALUE 'R',
        ireleased               TYPE zcy_t_2a_pay_blk-status VALUE 'I',
        matched                 TYPE zcy_t_2a_pay_blk-status VALUE 'M',
        exempted                TYPE zcy_t_2a_pay_blk-status VALUE 'X',
        waiting_for_filing_date TYPE zcy_t_2a_pay_blk-status VALUE 'W',
        debit_note_posted       TYPE zcy_t_2a_pay_blk-status VALUE 'D',
      END OF mcs_doc_status,

      BEGIN OF mcs_vendor_block_type,
        exempted TYPE zcy_t_2a_pay_blk-vendor_block_type VALUE 'X',
        block    TYPE zcy_t_2a_pay_blk-vendor_block_type VALUE 'B',
        split    TYPE zcy_t_2a_pay_blk-vendor_block_type VALUE 'S',
      END OF mcs_vendor_block_type,

      BEGIN OF mcs_yes_no,
        yes TYPE zcy_t_2a_pay_blk-due_date_before_filing VALUE 'Y',
        no  TYPE zcy_t_2a_pay_blk-due_date_before_filing VALUE 'N',
      END OF mcs_yes_no.

    DATA:
      lt_grc TYPE STANDARD TABLE OF zgrc_control,
      ls_grc TYPE zgrc_control,
      grc    TYPE i.

    DATA:
      mrt_matched    TYPE RANGE OF zpb_i_2a_pay_block_ly4-reconciliationsection,
      mrt_mismatched TYPE RANGE OF zpb_i_2a_pay_block_ly4-reconciliationsection,
      mrt_exempted   TYPE RANGE OF zpb_i_2a_pay_block_ly4-reconciliationsection,
      lv_mess        TYPE c LENGTH 200.

    DATA:
      mv_p_pbf    TYPE abap_boolean,
      mv_p_jv     TYPE abap_boolean,
      mv_p_dbf    TYPE abap_boolean,
      mv_p_daf    TYPE abap_boolean,
      mv_p_dbf_cl TYPE abap_boolean,
      mv_p_dbf_op TYPE abap_boolean,
      mv_p_daf_cl TYPE abap_boolean,
      mv_p_daf_op TYPE abap_boolean,
      mv_p_block  TYPE abap_boolean,
      mv_p_split  TYPE abap_boolean,
      mv_p_deb_n  TYPE abap_boolean.

    METHODS unblock_document
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS process_unprocessed
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS process_blocked
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS process_dbf
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS process_daf
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS release_document
      CHANGING
        cs_data            TYPE zpb_i_2a_pay_block_ly4
      RETURNING
        VALUE(rv_released) TYPE abap_boolean.

    METHODS process_daf_open
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS process_dbf_open
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_ly4.

    METHODS block_open_document
      CHANGING
        cs_data           TYPE zpb_i_2a_pay_block_ly4
      RETURNING
        VALUE(rv_blocked) TYPE abap_boolean.

    METHODS toggle_payment_block
      IMPORTING
        iv_doc_num        TYPE bkpf-belnr
        iv_comp_code      TYPE bkpf-bukrs
        iv_fis_year       TYPE bkpf-gjahr
      EXPORTING
        ev_message        TYPE string
      RETURNING
        VALUE(rv_toggled) TYPE abap_boolean.

    METHODS fill_reco_status_range.

    METHODS post_debit_note
      CHANGING
        cs_data          TYPE zpb_i_2a_pay_block_ly4
      RETURNING
        VALUE(rv_posted) TYPE abap_boolean.

    METHODS perform_grc_check
      IMPORTING
        iv_vendor        TYPE lifnr
      EXPORTING
        ev_score         TYPE zcy_grc_score-gstr1_score
        ev_message       TYPE string
      RETURNING
        VALUE(rv_result) TYPE char1.

    METHODS get_log
      EXPORTING
        ev_date TYPE sydatum
        ev_time TYPE syuzeit
        ev_user TYPE string.

    METHODS post_jv
      CHANGING
        cs_data          TYPE zpb_i_2a_pay_block_ly4
      RETURNING
        VALUE(rv_posted) TYPE abap_boolean.

    METHODS reverse_jv
      CHANGING
        cs_data            TYPE zpb_i_2a_pay_block_ly4
      RETURNING
        VALUE(rv_reversed) TYPE abap_boolean.

    METHODS reverse_debit_note
      CHANGING
        cs_data            TYPE zpb_i_2a_pay_block_ly4
      RETURNING
        VALUE(rv_reversed) TYPE abap_boolean.

    METHODS is_document_open
      IMPORTING
        iv_doc_num     TYPE bkpf-belnr
        iv_comp_code   TYPE bkpf-bukrs
        iv_fis_year    TYPE bkpf-gjahr
      RETURNING
        VALUE(rv_open) TYPE abap_boolean.

    METHODS reverse_document
      IMPORTING
        iv_doc_num         TYPE bkpf-belnr
        iv_comp_code       TYPE bkpf-bukrs
        iv_fis_year        TYPE bkpf-gjahr
      EXPORTING
        ev_reversed_doc    TYPE bkpf-belnr
        ev_fis_year        TYPE bkpf-gjahr
        ev_message         TYPE string
      RETURNING
        VALUE(rv_reversed) TYPE abap_boolean.

    METHODS check_document_posted
      IMPORTING
        iv_doc_num       TYPE bkpf-belnr
        iv_comp_code     TYPE bkpf-bukrs
        iv_fis_year      TYPE bkpf-gjahr
      RETURNING
        VALUE(rv_posted) TYPE abap_boolean.

    METHODS get_fiscal_year
      IMPORTING
        iv_bukrs        TYPE bukrs
        iv_budat        TYPE budat
      RETURNING
        VALUE(rv_gjahr) TYPE gjahr.

    METHODS process_bapi_return
      IMPORTING
        it_return         TYPE bapiret2_t
      EXPORTING
        ev_message        TYPE string
      RETURNING
        VALUE(rv_success) TYPE abap_boolean.

    METHODS is_document_in_bsik
      IMPORTING
        iv_bukrs         TYPE bukrs
        iv_belnr         TYPE belnr_d
        iv_gjahr         TYPE gjahr
      RETURNING
        VALUE(rv_exists) TYPE abap_boolean.

ENDCLASS.

CLASS zcl_pb_processor IMPLEMENTATION.

  METHOD constructor.

    mv_p_pbf    = iv_p_pbf.
    mv_p_jv     = iv_p_jv.
    mv_p_dbf    = iv_p_dbf.
    mv_p_daf    = iv_p_daf.
    mv_p_dbf_cl = iv_p_dbf_cl.
    mv_p_dbf_op = iv_p_dbf_op.
    mv_p_daf_cl = iv_p_daf_cl.
    mv_p_daf_op = iv_p_daf_op.

    mv_p_block = iv_p_block.
    mv_p_split = iv_p_split.
    mv_p_deb_n = iv_p_deb_n.

    fill_reco_status_range( ).

  ENDMETHOD.


  METHOD process.

    CASE cs_data-status.

      WHEN mcs_doc_status-unprocessed
        OR mcs_doc_status-waiting_for_filing_date
        OR mcs_doc_status-exempted.

        process_unprocessed(
          CHANGING
            cs_data = cs_data ).

      WHEN mcs_doc_status-blocked
        OR mcs_doc_status-split
        OR mcs_doc_status-debit_note_posted.

        process_blocked(
          CHANGING
            cs_data = cs_data ).

      WHEN mcs_doc_status-matched
        OR mcs_doc_status-released.

      WHEN OTHERS.
        cs_data-message = 'Document status is not valid for processing'.

    ENDCASE.

  ENDMETHOD.


  METHOD process_blocked.

    " Here Release might mean:
    " 1. Unblock in case of B or S
    " 2. Reversal in case of JV (with B or S) and D

    DATA:
      lv_released TYPE abap_boolean,
      ls_bsik     TYPE bsik.

    " What if vendor is exempted after doc is blocked/split?
    IF cs_data-vendorblocktype = mcs_vendor_block_type-exempted.

      lv_released = release_document(
        CHANGING
          cs_data = cs_data ).

    ELSE.

      " Document follows the normal blocked/split/DN-posted flow
      IF to_upper( cs_data-reconciliationsection )
         IN mrt_matched[].

        lv_released = release_document(
          CHANGING
            cs_data = cs_data ).

        IF is_document_in_bsik(
             iv_bukrs = CONV #( cs_data-custom9 )
             iv_belnr = CONV #( cs_data-custom1 )
             iv_gjahr = CONV #( cs_data-custom4 ) ).

        ELSE.

          reverse_debit_note(
            CHANGING
              cs_data = cs_data
            RECEIVING
              rv_reversed = DATA(lv_reversed) ).

          IF lv_reversed = abap_true.

            get_log(
              IMPORTING
                ev_date = cs_data-debitnotereversedon
                ev_time = cs_data-debitnotereversedat
                ev_user = DATA(lv_user) ).

            cs_data-debitnotereversedby = lv_user.

          ELSE.

            cs_data-releasecomment = cs_data-debitnoterevcomment.

          ENDIF.

        ENDIF.

      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD is_document_in_bsik.

    rv_exists = abap_false.

    SELECT SINGLE belnr
      FROM bsak
      WHERE bukrs = @iv_bukrs
        AND belnr = @iv_belnr
        AND gjahr = @iv_gjahr
        AND zlspr <> 'Y'
      INTO @DATA(lv_belnr).

    IF sy-subrc = 0.
      rv_exists = abap_true.
    ENDIF.

  ENDMETHOD.


  METHOD process_daf.

    IF cs_data-ClearingDate IS NOT INITIAL.

      IF mv_p_daf_cl = abap_true.
        process_daf_open(
          CHANGING
            cs_data = cs_data ).
      ENDIF.

    ELSE.

      IF mv_p_daf_op = abap_true.
        process_daf_open(
          CHANGING
            cs_data = cs_data ).
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD process_dbf.

    IF cs_data-clearingdate IS NOT INITIAL.

      IF mv_p_dbf_cl = abap_true.
        process_dbf_open(
          CHANGING
            cs_data = cs_data ).
      ENDIF.

    ELSE.

      IF mv_p_dbf_op = abap_true.
        process_dbf_open(
          CHANGING
            cs_data = cs_data ).
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD process_unprocessed.

    IF cs_data-status = mcs_doc_status-exempted.

      IF cs_data-VendorBlockType <>
         mcs_vendor_block_type-exempted.

        cs_data-status = mcs_doc_status-unprocessed.

      ELSE.

        RETURN.

      ENDIF.

    ENDIF.

    IF cs_data-DueDateBeforeFiling = mcs_yes_no-yes.

      IF mv_p_dbf = abap_true.

        process_dbf(
          CHANGING
            cs_data = cs_data ).

      ENDIF.

    ELSE.

      IF mv_p_daf = abap_true.

        process_daf(
          CHANGING
            cs_data = cs_data ).

      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD release_document.

    CLEAR rv_released.

    CASE cs_data-status.

      WHEN mcs_doc_status-blocked.

        toggle_payment_block(
          EXPORTING
            iv_doc_num   = |{ CONV bkpf-belnr( cs_data-custom1 ) ALPHA = IN }|
            iv_comp_code = CONV #( cs_data-custom9 )
            iv_fis_year  = CONV #( cs_data-custom4 )
          IMPORTING
            ev_message   = DATA(lv_message)
          RECEIVING
            rv_toggled   = rv_released ).

        cs_data-ReleaseComment = lv_message.

      WHEN mcs_doc_status-split.

        toggle_payment_block(
          EXPORTING
            iv_doc_num   = |{ cs_data-DebitNoteNum ALPHA = IN }|
            iv_comp_code = cs_data-SplitCompCode
            iv_fis_year  = cs_data-splityear
          IMPORTING
            ev_message   = lv_message
          RECEIVING
            rv_toggled   = rv_released ).

        cs_data-ReleaseComment = lv_message.

      WHEN mcs_doc_status-debit_note_posted.

        toggle_payment_block(
          EXPORTING
            iv_doc_num   = |{ cs_data-DebitNoteNum ALPHA = IN }|
            iv_comp_code = cs_data-debitnotecomp
            iv_fis_year  = cs_data-debitnoteyear
          IMPORTING
            ev_message   = lv_message
          RECEIVING
            rv_toggled   = rv_released ).

        cs_data-ReleaseComment = lv_message.

    ENDCASE.

    IF rv_released = abap_true.

      cs_data-status  = mcs_doc_status-released.
      cs_data-message = TEXT-014.

    ELSE.

      cs_data-message = TEXT-013.

    ENDIF.

  ENDMETHOD.


  METHOD fill_reco_status_range.

    CLEAR:
      mrt_matched[],
      mrt_mismatched[],
      mrt_exempted[].

    " #ToDo
    " Fill status ranges
    SELECT 'I' AS sign,
           'EQ' AS option,
           reco_status AS low
      FROM zcy_t_2a_recstat
      WHERE category = 'M'
      INTO TABLE @mrt_matched[].

    LOOP AT mrt_matched ASSIGNING FIELD-SYMBOL(<ls_matched>).
      <ls_matched>-low = to_upper( <ls_matched>-low ).
    ENDLOOP.

    SELECT 'I' AS sign,
           'EQ' AS option,
           reco_status AS low
      FROM zcy_t_2a_recstat
      WHERE category = 'B'
      INTO TABLE @mrt_mismatched[].

    LOOP AT mrt_mismatched ASSIGNING FIELD-SYMBOL(<ls_mismatched>).
      <ls_mismatched>-low = to_upper( <ls_mismatched>-low ).
    ENDLOOP.

    SELECT 'I' AS sign,
           'EQ' AS option,
           reco_status AS low
      FROM zcy_t_2a_recstat
      WHERE category = 'X'
      INTO TABLE @mrt_exempted[].

    LOOP AT mrt_exempted ASSIGNING FIELD-SYMBOL(<ls_exempted>).
      <ls_exempted>-low = to_upper( <ls_exempted>-low ).
    ENDLOOP.

    IF mrt_matched[] IS INITIAL
       OR mrt_mismatched[] IS INITIAL.

*     RAISE EXCEPTION TYPE LCX_GENERIC
*       MESSAGE ID '00' TYPE MCS_MSG_TYPE-ERROR NUMBER '001'
*       WITH TEXT-009.

      RETURN.

    ENDIF.

  ENDMETHOD.


  METHOD process_dbf_open.

    IF sy-datum >= cs_data-expectedfilingdate
       OR cs_data-filingdate IS NOT INITIAL
       OR mv_p_pbf = abap_true
       OR cs_data-qblock IS NOT INITIAL.

      IF to_upper( cs_data-reconciliationsection )
         IN mrt_mismatched[].

        DATA(lv_blocked) = block_open_document(
          CHANGING
            cs_data = cs_data ).

      ENDIF.

      IF to_upper( cs_data-reconciliationsection )
         IN mrt_matched[].

        cs_data-status = mcs_doc_status-matched.

      ENDIF.

    ELSE.

      " Filing date is in the future

      IF to_upper( cs_data-reconciliationsection )
         IN mrt_matched[].

        cs_data-status = mcs_doc_status-matched.

      ELSE.

        DATA(due_check) = sy-datum.
        due_check = sy-datum + 1.

        IF cs_data-grccheckapplicable = mcs_yes_no-yes.

          DATA:
            lv_grc_score   TYPE zcy_grc_score-gstr1_score,
            lv_grc_message TYPE string.

          perform_grc_check(
            EXPORTING
              iv_vendor  = cs_data-vendor
            IMPORTING
              ev_score   = lv_grc_score
              ev_message = lv_grc_message
            RECEIVING
              rv_result  = cs_data-grccheckresult ).

          cs_data-GrcScore        = lv_grc_score.
          cs_data-GrcCheckComment = lv_grc_message.

          get_log(
            IMPORTING
              ev_date = cs_data-grccheckedon
              ev_time = cs_data-grccheckedat
              ev_user = DATA(lv_user) ).

          cs_data-grccheckedby = lv_user.

          grc = cs_data-grcscore.

          CLEAR ls_grc.

          READ TABLE lt_grc
            INTO ls_grc
            INDEX 1.

          IF ( grc <= ls_grc-grc_block1
               OR grc IS INITIAL )
             AND cs_data-mindk IS INITIAL.

            lv_blocked = block_open_document(
              CHANGING
                cs_data = cs_data ).

          ELSEIF grc > ls_grc-grc_block2
             AND grc <= ls_grc-grc_block3.

            cs_data-status = mcs_doc_status-waiting_for_filing_date.

          ELSE.

            cs_data-status = mcs_doc_status-waiting_for_filing_date.

          ENDIF.

        ELSE.

          cs_data-status = mcs_doc_status-waiting_for_filing_date.

        ENDIF.

      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD process_daf_open.

    " Filing date has passed?
    CLEAR ls_grc.

    IF cs_data-mindk = '6'
       OR cs_data-mindk = '7'.

      cs_data-qblock = 'X'.

    ENDIF.

    READ TABLE lt_grc
      INTO ls_grc
      INDEX 1.

    IF sy-datlo >= cs_data-expectedfilingdate
       OR mv_p_pbf = abap_true
       OR cs_data-qblock = 'X'.

      IF to_upper( cs_data-reconciliationsection )
         IN mrt_mismatched[].

        DATA(lv_blocked) = block_open_document(
          CHANGING
            cs_data = cs_data ).

      ENDIF.

      IF to_upper( cs_data-reconciliationsection )
         IN mrt_matched[].

        cs_data-status = mcs_doc_status-matched.

      ENDIF.

    ELSE.

      " Filing date is in the future
      cs_data-status = mcs_doc_status-waiting_for_filing_date.

    ENDIF.

  ENDMETHOD.


  METHOD block_open_document.

    CLEAR rv_blocked.

    DATA lv_jv_applicable TYPE abap_boolean.

    CASE cs_data-vendorblocktype.

      WHEN mcs_vendor_block_type-exempted.

        cs_data-status = mcs_doc_status-exempted.

      WHEN mcs_vendor_block_type-block.

        toggle_payment_block(
          EXPORTING
            iv_doc_num   = |{ CONV bkpf-belnr( cs_data-custom1 ) ALPHA = IN }|
            iv_comp_code = CONV #( cs_data-custom9 )
            iv_fis_year  = CONV #( cs_data-custom4 )
          IMPORTING
            ev_message   = DATA(lv_block_message)
          RECEIVING
            rv_toggled   = rv_blocked ).

        cs_data-blockcomment = lv_block_message.

        IF rv_blocked = abap_true.

          cs_data-status = mcs_doc_status-blocked.

          get_log(
            IMPORTING
              ev_date = cs_data-blockedon
              ev_time = cs_data-blockedat
              ev_user = DATA(lv_user) ).

          cs_data-blockedby = lv_user.
          cs_data-message  = 'Document blocked successfully'.

          IF mv_p_jv = abap_true
             AND mv_p_block = abap_true.

            lv_jv_applicable = abap_true.

          ENDIF.

        ELSE.

          cs_data-message = 'Document blocking failed'.

        ENDIF.

      WHEN mcs_vendor_block_type-split.

        post_debit_note(
          CHANGING
            cs_data = cs_data
          RECEIVING
            rv_posted = DATA(lv_dn_posted) ).

        IF lv_dn_posted = abap_true.

          cs_data-status = mcs_doc_status-debit_note_posted.

          get_log(
            IMPORTING
              ev_date = cs_data-debitnotepostedon
              ev_time = cs_data-debitnotepostedat
              ev_user = DATA(lv_debit) ).

          cs_data-debitnotepostedby = lv_debit.
          cs_data-message = 'Document processed successfully'.

        ENDIF.

      WHEN OTHERS.

        cs_data-message = 'Invalid vendor block type'.

    ENDCASE.

    IF lv_jv_applicable = abap_true.

      post_jv(
        CHANGING
          cs_data = cs_data
        RECEIVING
          rv_posted = DATA(lv_jv_posted) ).

      IF lv_jv_posted = abap_true.

        get_log(
          IMPORTING
            ev_date = cs_data-jvpostedon
            ev_time = cs_data-jvpostedat
            ev_user = DATA(lv_post) ).

        cs_data-jvpostedby = lv_post.

        IF cs_data-message <> 'Document blocking failed'.
          cs_data-message = 'Document processed successfully'.
        ENDIF.

      ELSE.

        cs_data-message = 'Document processing failed'.

      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD check_document_posted.

    rv_posted = abap_false.

    DO 10 TIMES.

      CALL FUNCTION 'ENQUE_SLEEP'
        EXPORTING
          seconds        = 1
        EXCEPTIONS
          system_failure = 1
          OTHERS         = 2.

      SELECT SINGLE @abap_true
        FROM bkpf
        WHERE bukrs = @iv_comp_code
          AND belnr = @iv_doc_num
          AND gjahr = @iv_fis_year
        INTO @rv_posted.

      IF rv_posted = abap_true.
        RETURN.
      ENDIF.

    ENDDO.

  ENDMETHOD.


  METHOD get_fiscal_year.

    CLEAR rv_gjahr.

    CALL FUNCTION 'FI_PERIOD_DETERMINE'
      EXPORTING
        i_budat        = iv_budat
        i_bukrs        = iv_bukrs
      IMPORTING
        e_gjahr        = rv_gjahr
      EXCEPTIONS
        fiscal_year    = 1
        period         = 2
        period_version = 3
        posting_period = 4
        special_period = 5
        version        = 6
        posting_date   = 7
        OTHERS         = 8.

    IF sy-subrc <> 0.
      CLEAR rv_gjahr.
    ENDIF.

  ENDMETHOD.


  METHOD is_document_open.

    rv_open = abap_false.

    SELECT SINGLE @abap_true
      FROM bseg
      WHERE bukrs = @iv_comp_code
        AND belnr = @iv_doc_num
        AND gjahr = @iv_fis_year
        AND augbl = @space
      INTO @rv_open.

  ENDMETHOD.


  METHOD toggle_payment_block.

    CONSTANTS lc_pay_block TYPE bseg-zlspr VALUE 'Q'.

    DATA:
      lt_accchg    TYPE STANDARD TABLE OF accchg,
      ls_acc_item  TYPE bseg,
      lv_new_block TYPE bseg-zlspr.

    CLEAR:
      ev_message,
      rv_toggled.

    " Read the accounting document line items
    SELECT *
      FROM bseg
      WHERE bukrs = @iv_comp_code
        AND belnr = @iv_doc_num
        AND gjahr = @iv_fis_year
      INTO TABLE @DATA(lt_acc_items).

    IF lt_acc_items IS INITIAL.

      ev_message =
        |{ iv_comp_code }-{ iv_doc_num }-{ iv_fis_year } does not exist|.

      RETURN.

    ENDIF.

    " Prefer the special G/L item, as in the legacy method
    READ TABLE lt_acc_items
      INTO ls_acc_item
      WITH KEY umskz = 'A'.

    " Otherwise select the vendor credit item
    IF sy-subrc <> 0.

      READ TABLE lt_acc_items
        INTO ls_acc_item
        WITH KEY koart = 'K'
                 shkzg = 'H'.

    ENDIF.

    IF ls_acc_item IS INITIAL.

      ev_message =
        |{ iv_comp_code }-{ iv_doc_num }-{ iv_fis_year } - Cannot find suitable item for payment block|.

      RETURN.

    ENDIF.

    " Toggle payment block Q
    IF ls_acc_item-zlspr = lc_pay_block.
      CLEAR lv_new_block.
    ELSE.
      lv_new_block = lc_pay_block.
    ENDIF.

    lt_accchg = VALUE #(
      (
        fdname = 'ZLSPR'
        oldval = ls_acc_item-zlspr
        newval = lv_new_block
      )
    ).

    CALL FUNCTION 'FI_DOCUMENT_CHANGE'
      EXPORTING
        i_obzei              = ls_acc_item-buzei
        i_bukrs              = ls_acc_item-bukrs
        i_belnr              = ls_acc_item-belnr
        i_gjahr              = ls_acc_item-gjahr
      TABLES
        t_accchg             = lt_accchg
      EXCEPTIONS
        no_reference         = 1
        no_document          = 2
        many_documents       = 3
        wrong_input          = 4
        overwrite_creditcard = 5
        error_message        = 6
        OTHERS               = 7.

    IF sy-subrc <> 0.

      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
              INTO ev_message.

      RETURN.

    ENDIF.

    rv_toggled = abap_true.
    ev_message = 'Payment block updated successfully'.

  ENDMETHOD.


  METHOD post_debit_note.

    CONSTANTS:
      lc_doc_type  TYPE bapiache09-doc_type VALUE 'DS',
      lc_curr_type TYPE bapiaccr09-curr_type VALUE '00'.

    DATA:
      lt_acc_pay    TYPE STANDARD TABLE OF bapiacap09,
      lt_gl         TYPE STANDARD TABLE OF bapiacgl09,
      lt_amount     TYPE STANDARD TABLE OF bapiaccr09,
      lt_return     TYPE bapiret2_t,
      lv_posted_key TYPE bapiache09-obj_key,
      lv_message    TYPE string,
      lv_success    TYPE abap_boolean.

    rv_posted = abap_false.

    " 1. Read input from RAP record
    DATA(lv_comp_code)  = CONV bukrs( cs_data-custom9 ).
    DATA(lv_doc_num)    = CONV belnr_d( cs_data-custom1 ).
    DATA(lv_fis_year)   = CONV gjahr( cs_data-custom4 ).
    DATA(lv_vendor)     = CONV lifnr( cs_data-vendor ).
    DATA(lv_gst_amount) = cs_data-fitaxvalue.

    IF lv_comp_code IS INITIAL
       OR lv_doc_num IS INITIAL
       OR lv_fis_year IS INITIAL
       OR lv_vendor IS INITIAL
       OR lv_gst_amount IS INITIAL.

      cs_data-message = 'Required debit note input is missing'.
      RETURN.

    ENDIF.

    " 2. Read original document header
    SELECT SINGLE
      bldat,
      waers,
      awsys,
      glvor,
      bktxt,
      xblnr
      FROM bkpf
      WHERE bukrs = @lv_comp_code
        AND belnr = @lv_doc_num
        AND gjahr = @lv_fis_year
      INTO @DATA(ls_source_header).

    IF sy-subrc <> 0.
      cs_data-message = 'Source accounting document not found'.
      RETURN.
    ENDIF.

    IF ls_source_header-waers IS INITIAL.
      cs_data-message = 'Source document currency is missing'.
      RETURN.
    ENDIF.

    " 3. Read source vendor line
    SELECT SINGLE
      buzei,
      zuonr,
      bupla,
      secco,
      gsber,
      prctr,
      zterm
      FROM bseg
      WHERE bukrs = @lv_comp_code
        AND belnr = @lv_doc_num
        AND gjahr = @lv_fis_year
        AND koart = 'K'
        AND lifnr = @lv_vendor
      INTO @DATA(ls_source_vendor).

    IF sy-subrc <> 0.
      cs_data-message = 'Source vendor line not found'.
      RETURN.
    ENDIF.

    " 4. Prepare posting header
    DATA(ls_header) = VALUE bapiache09(
      obj_type   = 'BKPFF'
      obj_key    = '$'
      obj_sys    = ls_source_header-awsys
      bus_act    = ls_source_header-glvor
      username   = sy-uname
      header_txt = ls_source_header-bktxt
      comp_code  = lv_comp_code
      doc_date   = ls_source_header-bldat
      pstng_date = sy-datum
      doc_type   = lc_doc_type
      ref_doc_no = ls_source_header-xblnr
    ).

    " 5. Prepare the two vendor items
    lt_acc_pay = VALUE #(
      (
        itemno_acc    = '0000000010'
        vendor_no     = lv_vendor
        alloc_nmbr    = ls_source_vendor-zuonr
        businessplace = ls_source_vendor-bupla
        bus_area      = ls_source_vendor-gsber
        profit_ctr    = ls_source_vendor-prctr
        item_text     = 'GST Hold due to Mismatch/Non Compliance'
        sectioncode   = ls_source_vendor-secco
        pmnttrms      = ls_source_vendor-zterm
        pmnt_block    = 'Q'
        comp_code     = lv_comp_code
      )
      (
        itemno_acc    = '0000000020'
        vendor_no     = lv_vendor
        alloc_nmbr    = ls_source_vendor-zuonr
        businessplace = ls_source_vendor-bupla
        bus_area      = ls_source_vendor-gsber
        profit_ctr    = ls_source_vendor-prctr
        item_text     = 'GST Hold due to Mismatch/Non Compliance'
        sectioncode   = ls_source_vendor-secco
        pmnttrms      = ls_source_vendor-zterm
        pmnt_block    = 'Q'
        comp_code     = lv_comp_code
      )
    ).

    " 6. Prepare currency amounts
    " This reproduces the amount pattern in the legacy method.
    lt_amount = VALUE #(
      (
        itemno_acc = '0000000010'
        curr_type  = lc_curr_type
        currency   = ls_source_header-waers
        amt_doccur = lv_gst_amount
      )
      (
        itemno_acc = '0000000020'
        curr_type  = lc_curr_type
        currency   = ls_source_header-waers
        amt_doccur = ( lv_gst_amount * -1 )
      )
    ).

    " 7. Validate the amount balance
    DATA(lv_total_amount) = CONV decfloat34( 0 ).

    LOOP AT lt_amount INTO DATA(ls_amount).

      lv_total_amount =
        lv_total_amount + CONV decfloat34( ls_amount-amt_doccur ).

    ENDLOOP.

    IF lv_total_amount <> 0.
      cs_data-message = 'Debit note currency amounts are not balanced'.
      RETURN.
    ENDIF.

    " 8. Post the FI document
    CLEAR:
      lt_return,
      lv_posted_key,
      lv_message.

    CALL FUNCTION 'BAPI_ACC_DOCUMENT_POST'
      EXPORTING
        documentheader = ls_header
      IMPORTING
        obj_key        = lv_posted_key
      TABLES
        accountgl      = lt_gl
        accountpayable = lt_acc_pay
        currencyamount = lt_amount
        return         = lt_return.

    " 9. Evaluate the BAPI response
    lv_success = me->process_bapi_return(
      EXPORTING
        it_return  = lt_return
      IMPORTING
        ev_message = lv_message
    ).

    IF lv_success <> abap_true
       OR lv_posted_key IS INITIAL.

*     CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.

      IF lv_message IS INITIAL.
        lv_message = 'Debit note posting was not confirmed by the BAPI'.
      ENDIF.

      cs_data-message = lv_message.
      rv_posted = abap_false.
      RETURN.

    ENDIF.

    " 10. Commit the posted document
*   CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*     EXPORTING
*       wait = abap_true.

    " 11. Extract document key components
    DATA(lv_posted_doc) = CONV belnr_d(
      |{ lv_posted_key+0(10) ALPHA = IN }|
    ).

    DATA(lv_posted_comp) = CONV bukrs(
      lv_posted_key+10(4)
    ).

    DATA(lv_posted_year) = CONV gjahr(
      lv_posted_key+14(4)
    ).

    " 12. Confirm that the document exists
    DATA(lv_confirmed) = check_document_posted(
      iv_doc_num   = lv_posted_doc
      iv_comp_code = lv_posted_comp
      iv_fis_year  = lv_posted_year
    ).

    IF lv_confirmed <> abap_true.

      cs_data-message =
        'BAPI returned a document key, but document existence was not confirmed'.

      rv_posted = abap_false.
      RETURN.

    ENDIF.

    " 13. Return posted document details to RAP
    cs_data-debitnotenum  = lv_posted_doc.
    cs_data-debitnotecomp = lv_posted_comp.
    cs_data-debitnoteyear = lv_posted_year.

    cs_data-message = 'Debit note posted successfully'.
    rv_posted = abap_true.

  ENDMETHOD.


  METHOD process_bapi_return.

    CLEAR:
      ev_message,
      rv_success.

    rv_success = abap_false.

    IF it_return IS INITIAL.
      ev_message = 'No return messages received from BAPI'.
      RETURN.
    ENDIF.

    " Check for abort, error, or system-exit messages
    LOOP AT it_return INTO DATA(ls_return)
      WHERE type = 'A'
         OR type = 'E'
         OR type = 'X'.

      IF ev_message IS INITIAL.
        ev_message = ls_return-message.
      ELSE.
        ev_message = |{ ev_message }; { ls_return-message }|.
      ENDIF.

    ENDLOOP.

    IF ev_message IS NOT INITIAL.
      RETURN.
    ENDIF.

    " BAPI returned no abort/error messages
    READ TABLE it_return INTO ls_return
      WITH KEY type = 'S'.

    IF sy-subrc = 0.
      ev_message = ls_return-message.
      rv_success = abap_true.
      RETURN.
    ENDIF.

    READ TABLE it_return INTO ls_return INDEX 1.

    ev_message = ls_return-message.

    " Do not treat warning/information-only responses as confirmed success
    rv_success = abap_false.

  ENDMETHOD.


  METHOD reverse_debit_note.

    CLEAR rv_reversed.

    DATA lv_message TYPE string.

    IF is_document_open(
         iv_doc_num   = CONV #( cs_data-debitnotenum )
         iv_comp_code = CONV #( cs_data-debitnotecomp )
         iv_fis_year  = CONV #( cs_data-debitnoteyear ) ).

      rv_reversed = reverse_document(
        EXPORTING
          iv_doc_num   = CONV #( cs_data-debitnotenum )
          iv_comp_code = CONV #( cs_data-debitnotecomp )
          iv_fis_year  = CONV #( cs_data-debitnoteyear )
        IMPORTING
          ev_reversed_doc = cs_data-debitnoterevnum
          ev_fis_year     = cs_data-debitnoterevyear
          ev_message      = lv_message ).

      cs_data-debitnoterevcomment = lv_message.

      IF rv_reversed = abap_true.
        cs_data-debitnoterevcomp = cs_data-debitnotecomp.
      ENDIF.

    ELSE.

      cs_data-debitnoterevcomment =
        'Document is cleared; reversal is not possible'.

    ENDIF.

  ENDMETHOD.


  METHOD reverse_document.

    CONSTANTS lc_rev_reason TYPE bapiacrev-reason_rev VALUE '04'.

    DATA:
      lv_post_date TYPE bkpf-budat,
      lt_bdc_msg   TYPE STANDARD TABLE OF bdcmsgcoll,
      lt_return    TYPE STANDARD TABLE OF bapiret2.

    CLEAR:
      ev_reversed_doc,
      ev_fis_year,
      ev_message,
      rv_reversed,
      lv_post_date,
      lt_bdc_msg,
      lt_return.

    " Reverse the FI document using the existing FB08 wrapper
    CALL FUNCTION 'ZCY_FI_FM_CALL_FB08'
      EXPORTING
        i_bukrs       = iv_comp_code
        i_belnr       = iv_doc_num
        i_gjahr       = iv_fis_year
        i_stgrd       = lc_rev_reason
        i_no_auth     = abap_true
      IMPORTING
        e_budat       = lv_post_date
      TABLES
        et_messtab    = lt_bdc_msg
      EXCEPTIONS
        not_possible  = 1
        error_message = 2
        OTHERS        = 3.

    IF sy-subrc <> 0.

      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
              INTO ev_message.

      RETURN.

    ENDIF.

    IF lt_bdc_msg IS INITIAL.
      ev_message = 'FB08 returned no messages; reversal not confirmed'.
      RETURN.
    ENDIF.

    CALL FUNCTION 'CONVERT_BDCMSGCOLL_TO_BAPIRET2'
      TABLES
        imt_bdcmsgcoll = lt_bdc_msg
        ext_return     = lt_return.

    " Check whether the reversal success message is present
    READ TABLE lt_return INTO DATA(ls_success)
      WITH KEY type   = 'S'
               id     = '312'
               number = 'F5'.

    IF sy-subrc = 0.

      rv_reversed = abap_true.

      ev_reversed_doc = CONV bkpf-belnr(
        |{ CONV belnr_d( ls_success-message_v1 ) ALPHA = IN }|
      ).

      ev_fis_year = get_fiscal_year(
        iv_bukrs = iv_comp_code
        iv_budat = lv_post_date ).

    ELSE.

      READ TABLE lt_return INTO DATA(ls_error)
        WITH KEY type = 'E'.

      IF sy-subrc = 0.
        ev_message = ls_error-message.
      ELSE.
        ev_message = 'Reversal success could not be confirmed'.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD reverse_jv.

    rv_reversed = abap_false.

    CLEAR:
      cs_data-jvrevdocnum,
      cs_data-jvrevyear,
      cs_data-jvrevcomment.

    " Check whether the JV document exists and is open
    IF cs_data-jvdocnum IS INITIAL.

      cs_data-jvrevcomment = 'JV document number is missing'.
      RETURN.

    ENDIF.

    IF is_document_open(
         iv_doc_num   = CONV #( cs_data-jvdocnum )
         iv_comp_code = cs_data-jvcompcode
         iv_fis_year  = cs_data-jvyear ) = abap_true.

      " Open document: reverse using FB08
      reverse_document(
        EXPORTING
          iv_doc_num   = CONV #( cs_data-jvdocnum )
          iv_comp_code = cs_data-jvcompcode
          iv_fis_year  = cs_data-jvyear
        IMPORTING
          ev_reversed_doc = cs_data-jvrevdocnum
          ev_fis_year     = cs_data-jvrevyear
          ev_message      = DATA(lv_message)
        RECEIVING
          rv_reversed     = rv_reversed ).

      cs_data-jvrevcomment = lv_message.

      IF rv_reversed = abap_true.
        cs_data-jvrevcompcode = cs_data-jvcompcode.
      ENDIF.

    ELSE.

      " Cleared JV reversal is not implemented in the legacy source
      cs_data-jvrevcomment =
        'JV is cleared; reversal is not implemented'.

    ENDIF.

  ENDMETHOD.


  METHOD post_jv.



  ENDMETHOD.


  METHOD get_log.

    CLEAR:
      ev_date,
      ev_time,
      ev_user.

    GET TIME.

    ev_date = sy-datlo.
    ev_time = sy-timlo.

    SELECT SINGLE name_text
      FROM v_usr_name
      WHERE bname = @sy-uname
      INTO @DATA(lv_name).

    ev_user = COND string(
      WHEN lv_name IS NOT INITIAL
      THEN |{ sy-uname } - { lv_name }|
      ELSE sy-uname
    ).

  ENDMETHOD.


  METHOD perform_grc_check.



  ENDMETHOD.


  METHOD unblock_document.

    DATA:
      lv_document_open     TYPE abap_boolean,
      lv_debit_note_posted TYPE abap_boolean,
      lv_jv_posted         TYPE abap_boolean,
      lv_user              TYPE string.

    CLEAR:
      cs_data-message,
      lv_document_open,
      lv_debit_note_posted,
      lv_jv_posted.

    "------------------------------------------------------------
    " Process only documents having status I (IRELEASED)
    "------------------------------------------------------------
    IF cs_data-status <> mcs_doc_status-ireleased.

      cs_data-message = 'Document status is not IRELEASED'.
      RETURN.

    ENDIF.

    "------------------------------------------------------------
    " Legacy PROCESS_DOCUMENTS_BLK1:
    " Check whether the debit-note document is still open
    "------------------------------------------------------------
    lv_document_open = is_document_open(
      iv_doc_num   = |{ CONV bkpf-belnr( cs_data-debitnotenum ) ALPHA = IN }|
      iv_comp_code = cs_data-debitnotecomp
      iv_fis_year  = cs_data-debitnoteyear
    ).

    IF lv_document_open = abap_true.

      " The debit note is open.
      " Continue through the existing blocked-document logic.
      process_blocked(
        CHANGING
          cs_data = cs_data
      ).

      RETURN.

    ENDIF.

    "------------------------------------------------------------
    " Debit note is cleared:
    " Port of legacy BLOCK_CLEARED_DOCUMENT_BK
    "------------------------------------------------------------
    CASE cs_data-vendorblocktype.

      WHEN mcs_vendor_block_type-exempted.

        cs_data-status  = mcs_doc_status-exempted.
        cs_data-message = 'Vendor is exempted from payment block'.

      WHEN mcs_vendor_block_type-block
        OR mcs_vendor_block_type-split.

        " Post the debit note using the existing processor method
        post_debit_note(
          CHANGING
            cs_data = cs_data
          RECEIVING
            rv_posted = lv_debit_note_posted
        ).

        IF lv_debit_note_posted = abap_true.

          cs_data-status = mcs_doc_status-debit_note_posted.

          get_log(
            IMPORTING
              ev_date = cs_data-debitnotepostedon
              ev_time = cs_data-debitnotepostedat
              ev_user = lv_user
          ).

          cs_data-debitnotepostedby = lv_user.
          cs_data-message = 'Debit note posted successfully'.

          " Post JV only when both options are enabled.
          " Confirm these flags match your original configuration.
          IF mv_p_jv = abap_true
             AND mv_p_deb_n = abap_true.

            post_jv(
              CHANGING
                cs_data = cs_data
              RECEIVING
                rv_posted = lv_jv_posted
            ).

            IF lv_jv_posted = abap_true.

              get_log(
                IMPORTING
                  ev_date = cs_data-jvpostedon
                  ev_time = cs_data-jvpostedat
                  ev_user = lv_user
              ).

              cs_data-jvpostedby = lv_user.
              cs_data-message = 'Debit note and JV posted successfully'.

            ELSE.

              cs_data-message = 'Debit note posted, but JV posting failed'.

            ENDIF.

          ENDIF.

        ELSE.

          cs_data-message = 'Debit note posting failed'.

        ENDIF.

      WHEN OTHERS.

        cs_data-message = 'Vendor block type is not valid for unblock'.

    ENDCASE.

  ENDMETHOD.


  METHOD unblock.

    unblock_document(
      CHANGING
        cs_data = cs_data
    ).

  ENDMETHOD.

ENDCLASS.

