@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ZPB_R_MT_ACC_DATA_LY1'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R_MT_ACC_DATA_LY1
  as select distinct from ZPB_R_MT_ACC_DATA
{
  key Bukrs,
  key Belnr,
  key Gjahr,
      bldat,
      budat,
      cpudt,
      xblnr,
      bktxt,
      awtyp,
      awkey,
      awsys,
      blart,
      glvor,
      buzei,
      buzid,
      augdt,
      @Semantics.amount.currencyCode: 'hwaer'
      dmbtr,
      zfbdt,
      zbd1t,
      zbd2t,
      zbd3t,
      koart,
      shkzg,
      lifnr,
      rebzg,
      zuonr,
      sgtxt,
      mwskz,
      zlspr,
      umskz,
      prctr,
      gsber,
      kostl,
      bupla,
      secco,
      hsn_sac,
      gst_part,
      augbl,
      zterm,
      hwaer
}
where
  koart = 'K'
