@EndUserText.label: 'Input fields for generating Eway Bill'
define abstract entity ZSD_A_PARTAB
{

  @EndUserText.label : 'Transporter ID'
  transporterid      : abap.char(40);
  @EndUserText.label : 'Transporter Name'
  transportername    : abap.char(50);
  //@Consumption.valueHelpDefinition: [{ entity : { name: 'ZSD_C_TRANSPORT_DROPDOWN' , element: 'TransportMode'} } ]
  @EndUserText.label : 'Transport Mode'
  transportmode      : abap.char(40);
  @EndUserText.label : 'Transport Document Number'
  transportdocnumber : abap.char(20);
  @EndUserText.label : 'Transport Doc. Date'
  transportdocdate   : abap.dats;
  @EndUserText.label : 'Vehicle Number'
  vehiclenumber      : abap.char(40);
  //@Consumption.valueHelpDefinition: [{ entity : { name: 'ZSD_C_VEHICLE_TYPE_DROPDOWN' , element: 'VehicleType'} } ]
  @EndUserText.label : 'Vehicle Type'
  vehicletype        : abap.char(20);
}
