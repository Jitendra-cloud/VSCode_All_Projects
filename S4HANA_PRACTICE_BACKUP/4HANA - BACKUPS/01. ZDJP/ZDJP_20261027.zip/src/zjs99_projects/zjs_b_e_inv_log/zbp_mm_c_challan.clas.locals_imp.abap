CLASS lhc_ZMM_C_CHALLAN DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_criteria,
             location_gstin  TYPE string,
             location_name   TYPE string,
             document_number TYPE string,
             document_date   TYPE string,
             supply_type     TYPE string,
             document_type   TYPE string,
             bill_from_gstin TYPE string,
             portcode        TYPE string,
           END OF ty_criteria.
    TYPES: tt_criteria TYPE STANDARD TABLE OF ty_criteria WITH EMPTY KEY.
    TYPES: BEGIN OF ty_error_detail,
             code    TYPE string,
             message TYPE string,
             type    TYPE string,
           END OF ty_error_detail,
           tt_error_detail TYPE STANDARD TABLE OF ty_error_detail WITH EMPTY KEY,
           BEGIN OF ty_property_error,
             propertyName TYPE string,
             errors       TYPE tt_error_detail,
           END OF ty_property_error,
           tt_property_error TYPE STANDARD TABLE OF ty_property_error WITH EMPTY KEY,
           BEGIN OF ty_ewb,
             pushStatus           TYPE string,
             eway_bill_number     TYPE string,
             eway_bill_date       TYPE string,
             eway_bill_valid_upto TYPE string,
             ewb_cancel           TYPE string,
             ewb_success          TYPE string,
             ewb_fail             TYPE string,
             errors               TYPE tt_error_detail,
           END OF ty_ewb,
           BEGIN OF ty_cancel_request,
             reason    TYPE string,
             remarks   TYPE string,
             criterias TYPE tt_criteria,
           END OF ty_cancel_request,
           BEGIN OF ty_validation_report,
             locationGstin  TYPE string,
             locationName   TYPE string,
             documentNumber TYPE string,
             documentDate   TYPE string,
             billFromGstin  TYPE string,
             supplyType     TYPE string,
             documentType   TYPE string,
             portCode       TYPE string,
             custom1        TYPE string,
             custom2        TYPE string,
             custom3        TYPE string,
             custom4        TYPE string,
             custom5        TYPE string,
             custom6        TYPE string,
             custom7        TYPE string,
             custom8        TYPE string,
             custom9        TYPE string,
             custom10       TYPE string,
             custom11       TYPE string,
             custom12       TYPE string,
             custom13       TYPE string,
             custom14       TYPE string,
             custom15       TYPE string,
             custom16       TYPE string,
             custom17       TYPE string,
             custom18       TYPE string,
             custom19       TYPE string,
             custom20       TYPE string,
             propertyErrors TYPE tt_property_error,
             ewb            TYPE ty_ewb,
           END OF ty_validation_report,
           tt_validation_report TYPE STANDARD TABLE OF ty_validation_report WITH EMPTY KEY.
    TYPES: BEGIN OF ty_data_report,
             locationGstin  TYPE string,
             locationName   TYPE string,
             documentNumber TYPE string,
             documentDate   TYPE string,
             billFromGstin  TYPE string,
             supplyType     TYPE string,
             documentType   TYPE string,
             irn            TYPE string,
             portCode       TYPE string,
             custom1        TYPE string,
             custom2        TYPE string,
             custom3        TYPE string,
             custom4        TYPE string,
             custom5        TYPE string,
             custom6        TYPE string,
             custom7        TYPE string,
             custom8        TYPE string,
             custom9        TYPE string,
             custom10       TYPE string,
             custom11       TYPE string,
             custom12       TYPE string,
             custom13       TYPE string,
             custom14       TYPE string,
             custom15       TYPE string,
             custom16       TYPE string,
             custom17       TYPE string,
             custom18       TYPE string,
             custom19       TYPE string,
             custom20       TYPE string,
             pushstatus     TYPE string,
             ewayBillNumber TYPE int8,
             generatedDate  TYPE string,
             validUpto      TYPE string,
             distance       TYPE i,
             errors         TYPE STANDARD TABLE OF ty_error WITH EMPTY KEY,
           END OF ty_data_report.
    TYPES: BEGIN OF ty_save_documents_response,
             requestType      TYPE string,
             status           TYPE string,
             version          TYPE string,
             validationReport TYPE tt_validation_report,
             dataReport       TYPE tt_validation_report,
             referenceId      TYPE string,
           END OF ty_save_documents_response.
    TYPES: BEGIN OF ty_ewb1,
             ewaybillnumber TYPE string,
             generateddate  TYPE string,
             validupto      TYPE string,
             distance       TYPE i,
           END OF ty_ewb1.
    TYPES: BEGIN OF ty_einv,
             irn           TYPE string,
             ackNumber     TYPE string,
             ackDate       TYPE string,
             signedInvoice TYPE string,
             signedQrCode  TYPE string,
           END OF ty_einv.
    TYPES: BEGIN OF ty_data_report1,
             locationgstin  TYPE string,
             locationname   TYPE string,
             documentnumber TYPE string,
             documentdate   TYPE string,
             supplytype     TYPE string,
             documenttype   TYPE string,
             billfromgstin  TYPE string,
             einv           TYPE ty_einv,
             ewb            TYPE ty_ewb1,
           END OF ty_data_report1,
           tt_data_report1 TYPE STANDARD TABLE OF ty_data_report1 WITH EMPTY KEY.
    TYPES: BEGIN OF ty_cpi_response,
             requesttype TYPE string,
             status      TYPE string,
             version     TYPE string,
             datareport  TYPE tt_data_report1,
             referenceid TYPE string,
           END OF ty_cpi_response.
    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR zmm_c_challan RESULT result.
    METHODS cancel_challan FOR MODIFY
      IMPORTING keys FOR ACTION zmm_c_challan~cancel_challan.
    METHODS gen_challan FOR MODIFY
      IMPORTING keys FOR ACTION zmm_c_challan~gen_challan.
    METHODS get_resp FOR MODIFY
      IMPORTING keys FOR ACTION zmm_c_challan~get_resp.
    METHODS download_pdf FOR MODIFY
      IMPORTING keys FOR ACTION zmm_c_challan~download_pdf RESULT result.
ENDCLASS.

CLASS lhc_ZMM_C_CHALLAN IMPLEMENTATION.
  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD cancel_challan.
    DATA: wa_cancel_eway_req TYPE ty_cancel_request,
          lt_error_response  TYPE STANDARD TABLE OF ty_property_error,
          lv_error           TYPE string,
          lt_update          TYPE TABLE FOR UPDATE zmm_c_challan.
    IF keys IS NOT INITIAL.
      SELECT document_number,document_date,company_code,fiscal_year,location_gstin,billfromgstin,documenttype
        FROM zsd_t_einv_log
        FOR ALL ENTRIES IN @keys
        WHERE document_number = @keys-DocumentNumber
        AND ewaybill_number IS NOT INITIAL
        INTO TABLE @DATA(lt_einv_log).
      IF lt_einv_log IS NOT INITIAL.
        wa_cancel_eway_req-reason = 'Duplicate'.
        wa_cancel_eway_req-remarks = 'Duplicate'.
        wa_cancel_eway_req-criterias = VALUE #( FOR wa_einv_log IN lt_einv_log ( location_gstin = wa_einv_log-location_gstin
                                                                                 document_number = |{ wa_einv_log-document_number ALPHA = OUT }|
                                                                                 document_date = |{ wa_einv_log-Document_Date+6(2) }-{ wa_einv_log-Document_Date+4(2) }-{ wa_einv_log-Document_Date+0(4) }|
                                                                                 supply_type = 'S'
                                                                                 document_type = wa_einv_log-documenttype
                                                                                 bill_from_gstin = wa_einv_log-billfromgstin ) ).
        DATA(lv_cancel_req) = /ui2/cl_json=>serialize( data = wa_cancel_eway_req
                                                       pretty_name = /ui2/cl_json=>pretty_mode-camel_case ).
        DATA(lo_invoice) = NEW zcl_invoice(  ).
        lo_invoice->call_cpi( EXPORTING iv_req_payload = lv_cancel_req
                                        iv_action      = 'CancelEwaybill'
                                        IMPORTING ev_response    = DATA(lv_reference) ).
        FIND REGEX '"referenceId"\s*:\s*"([^"]+)"' IN lv_reference SUBMATCHES DATA(lv_referenceid).
        IF lv_referenceid IS NOT INITIAL.
          lo_invoice->call_cpi( EXPORTING  iv_action       = 'Status'
                                           iv_reference_id = lv_referenceid
                                IMPORTING  ev_response     = DATA(lv_response) ).
          FIND REGEX '"status"\s*:\s*"([^"]*)"' IN lv_response SUBMATCHES DATA(lv_status).
          IF lv_status EQ 'P'.
            lt_update = VALUE #( FOR wa_keys IN keys ( DocumentNumber = wa_keys-DocumentNumber
                                   DocumentDate = wa_keys-DocumentDate
                                   Company_Code = wa_keys-Company_Code
                                   EwayCancel = 'X'
                                   EwayFail = ''
                                   EwaybillError = ''
                                   %control-DocumentNumber = if_abap_behv=>mk-on
                                   %control-DocumentDate = if_abap_behv=>mk-on
                                   %control-Company_Code = if_abap_behv=>mk-on
                                   %control-EwayFail = if_abap_behv=>mk-on
                                   %control-EwaybillError = if_abap_behv=>mk-on
                                   %control-EwayCancel = if_abap_behv=>mk-on ) ).
            reported-zmm_c_challan = VALUE #( (
                   %msg = new_message( id = 'EWB'
                                       number = '1'
                                       severity = if_abap_behv_message=>severity-information
                                       v1 = 'EWB CANCEL SUCCESSFULLY'
                                      )
) ).
          ENDIF.
        ELSE.
          /ui2/cl_json=>deserialize( EXPORTING json = lv_reference
                                     CHANGING  data = lt_error_response ).
          TRY.
              DATA(wa_error_response) = lt_error_response[ 1 ].
              IF wa_error_response-errors IS NOT INITIAL.
                LOOP AT wa_error_response-errors INTO DATA(wa_errors).
                  lv_error = |{ lv_error } | && '|' &&  | { wa_errors-message }|.
                  IF sy-tabix EQ '1'.
                    REPLACE ALL OCCURRENCES OF '|' IN lv_error WITH ''.
                  ENDIF.
                ENDLOOP.
                lt_update = VALUE #( FOR wa_keys IN keys ( DocumentNumber = wa_keys-DocumentNumber
                                                           DocumentDate = wa_keys-DocumentDate
                                                           Company_Code = wa_keys-Company_Code
                                                           EwaybillError = lv_error
                                                           %control-DocumentNumber = if_abap_behv=>mk-on
                                                           %control-DocumentDate = if_abap_behv=>mk-on
                                                           %control-Company_Code = if_abap_behv=>mk-on
                                                           %control-EwaybillError = if_abap_behv=>mk-on ) ).
                reported-zmm_c_challan = VALUE #( ( %msg = new_message_with_text( text = lv_error
                                     severity = if_abap_behv_message=>severity-error ) )  ).
              ENDIF.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
        ENDIF.
      ELSE.
        reported-zmm_c_challan = VALUE #( ( %msg = new_message( id = 'ZSD_MSG_CYG'
                                                                  number = '003'
                                                                  severity = if_abap_behv_message=>severity-error
                                                                  v1 = keys[ 1 ]-DocumentNumber ) )  ) .
      ENDIF.
      IF lt_update IS NOT INITIAL.
        MODIFY ENTITIES OF zmm_c_challan IN LOCAL MODE
         ENTITY zmm_c_challan
         UPDATE FROM lt_update
         FAILED DATA(lt_failed)
         REPORTED DATA(lt_reported)
         MAPPED DATA(lt_mapped).
      ENDIF.
    ENDIF.
  ENDMETHOD.

  METHOD gen_challan.
    TYPES : BEGIN OF ty_reference_id,
              referenceid TYPE string,
            END OF ty_reference_id.
    DATA : wa_success_ewb TYPE ty_save_documents_response.
    DATA : wa_ewb TYPE ty_cpi_response.
    DATA : wa_lts TYPE abp_creation_tstmpl.
    DATA : lv_counter TYPE char10 VALUE '1'.
    DATA : wa_referenceid    TYPE ty_reference_id,
           wa_error_response TYPE ty_save_documents_response,
           lv_error          TYPE string.
    DATA(lo_invoice) = NEW zcl_invoice(  ).
    DATA : lt_create TYPE TABLE FOR CREATE zmm_c_challan.
    DATA : lt_update TYPE TABLE FOR UPDATE zmm_c_challan.
    READ ENTITIES OF zmm_c_challan
      IN LOCAL MODE
      ENTITY zmm_c_challan
      ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_exist).
    DATA : lr_doc  TYPE RANGE OF mkpf-mblnr,
           lr_date TYPE RANGE OF mkpf-bldat.
    lr_doc  = VALUE #( ( sign = 'I' option = 'EQ' low = keys[ 1 ]-DocumentNumber ) ).
    lr_date = VALUE #( ( sign = 'I' option = 'EQ' low = keys[ 1 ]-DocumentDate ) ).
    TYPES:
      BEGIN OF ty_transport,
        documentnumber        TYPE string,
        documentdate          TYPE string,
        transportername       TYPE string,
        transporterid         TYPE string,
        vehicletype           TYPE string,
        vehiclenumber         TYPE string,
        transportmode         TYPE string,
        transportdocumentdate TYPE string,
        transportdocumentnum  TYPE string,
      END OF ty_transport,
      tt_ewb TYPE STANDARD TABLE OF ty_transport WITH EMPTY KEY.
    DATA lt_transport_p TYPE TABLE OF ty_transport.
    IF keys[ 1 ]-%param IS NOT INITIAL.
      lt_transport_p = VALUE #( (
                                  documentnumber        = keys[ 1 ]-documentnumber
                                  documentdate          = |{ keys[ 1 ]-documentdate+6(2) }-{ keys[ 1 ]-documentdate+4(2) }-{ keys[ 1 ]-documentdate+0(4) }|
                                  transporterid         = keys[ 1 ]-%param-transporterid
                                  transportername       = keys[ 1 ]-%param-transportername
                                  transportmode         = keys[ 1 ]-%param-transportmode
                                  transportdocumentdate = keys[ 1 ]-%param-transportdocdate
                                  transportdocumentnum = keys[ 1 ]-%param-transportdocnumber
                                  vehiclenumber         = keys[ 1 ]-%param-vehiclenumber
                                  vehicletype           = keys[ 1 ]-%param-vehicletype
                                  ) ).
    ENDIF.
    lo_invoice->get_data_for_challan(
      EXPORTING
        iv_billing_document = lr_doc
        iv_document_date    = lr_date
        lt_transport_p = lt_transport_p
      IMPORTING
        et_display_table    = DATA(lt_table)
        lv_request = DATA(lv_request)
    ).
    DATA: tt_final_global TYPE STANDARD TABLE OF zsd_s_global_st .
    tt_final_global = CORRESPONDING #( lt_table ).
    TRY.
        DATA(wa_data) = lt_table[ 1 ].
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.
    IF lv_request IS NOT INITIAL.
      lo_invoice->call_cpi( EXPORTING iv_req_payload = lv_request
                                        iv_action      = 'saveDocuments'
                              IMPORTING ev_response    = DATA(lv_reference) ).
      IF lv_reference CS 'referenceID'.
        /ui2/cl_json=>deserialize( EXPORTING json = lv_reference
                                   CHANGING  data = wa_referenceid  ).
        IF wa_referenceid-referenceid IS NOT INITIAL.
          WAIT UP TO 2 SECONDS.
          IF wa_referenceid-referenceid IS NOT INITIAL.
            lo_invoice->call_cpi( EXPORTING  iv_action       = 'Status'
                                             iv_reference_id = wa_referenceid-referenceid
                                  IMPORTING  ev_response     = DATA(lv_response) ).
            FIND REGEX '"status"\s*:\s*"([^"]*)"' IN lv_response SUBMATCHES DATA(lv_status).
          ENDIF.
          /ui2/cl_json=>deserialize( EXPORTING json = lv_response
                                     CHANGING  data = wa_success_ewb ).
          /ui2/cl_json=>deserialize( EXPORTING json = lv_response
                                     CHANGING data =  wa_ewb ).
          IF lv_status EQ 'P'.
            TRY.
                IF wa_ewb-datareport[ 1 ]-ewb-ewaybillnumber IS NOT INITIAL.
                  DATA(wa_ewb_det) = wa_ewb-datareport[ 1 ].
                  lt_create = VALUE #( ( documentnumber                   = keys[ 1 ]-DocumentNumber
                                           documentdate                     = keys[ 1 ]-DocumentDate
                                           company_code                      = keys[ 1 ]-Company_Code
                                           LocationGstin                    = wa_data-locationgstin
                                           Billfromgstin                    = wa_data-billfromgstin
                                           Documenttype                     = wa_data-documenttype
                                           Billfromlegalname                     = wa_data-billfromlegalname
                                           Billfromaddress1                     = wa_data-billfromaddress1
                                           Billfromaddress2                     = wa_data-billfromaddress2
                                           Billfromcity                     = wa_data-billfromcity
                                           Billfrompincode                  = wa_data-billfrompincode
                                           Billtoaddress1                       = wa_data-billtoaddress1
                                           Billtoaddress2                       = wa_data-billtoaddress2
                                           Billtocity                       = wa_data-billtocity
                                           Billtogstin                      = wa_data-billtogstin
                                           Billtolegalname                       = wa_data-billtolegalname
                                           Billtopincode                    = wa_data-billtopincode
                                           Dispatchfromgstin                = wa_data-dispatchfromgstin
                                           Dispatchfromname                 = wa_data-billfromlegalname
                                           Dispatchfromadd1                 = wa_data-dispatchfromadd1
                                           Dispatchfromadd2                 = wa_data-dispatchfromadd2
                                           Dispatchfromcity                 = wa_data-dispatchfromcity
                                           Dispatchfrompincode              = wa_data-dispatchfrompincode
                                           Shiptoadd1                       = wa_data-shiptoadd1
                                           Shiptoadd2                       = wa_data-shiptoadd2
                                           Shiptocity                       = wa_data-shiptocity
                                           Shiptopincode                    = wa_data-shiptopincode
                                           Shiptoname                       = wa_data-Shiptoname
                                           Shiptogstin                      = wa_data-shiptogstin
                                           EwaybillNumber     = wa_ewb_det-ewb-ewaybillnumber
                                           EwaybillDistance    = wa_ewb_det-ewb-distance
                                           EwaybillValidUpto  = wa_ewb_det-ewb-validupto
                                           EwaybillGenerated = 'X'
                                           EwaybillError = ''
                                           EwayFail = ''
                                           transporterid         = lt_transport_p[ 1 ]-transporterid
                                           transportername       = lt_transport_p[ 1 ]-transportername
                                           transportmode         = lt_transport_p[ 1 ]-transportmode
                                           transporterdocdate    = lt_transport_p[ 1 ]-transportdocumentdate
                                           transporterdocnum     = lt_transport_p[ 1 ]-transportdocumentnum
                                           vehiclenumber         = lt_transport_p[ 1 ]-vehiclenumber
                                           vehicletype           = lt_transport_p[ 1 ]-vehicletype
                                           documentvalue = wa_data-documentvalue
                                           cgstamount = wa_data-cgstamount
                                           sgstamount = wa_data-sgstamount
                                           igstamount = wa_data-igstamount
                                           %control-DocumentNumber = if_abap_behv=>mk-on
                                           %control-DocumentDate = if_abap_behv=>mk-on
                                           %control-Documentvalue = if_abap_behv=>mk-on
                                           %control-transporterid = if_abap_behv=>mk-on
                                           %control-transportername = if_abap_behv=>mk-on
                                           %control-transportmode = if_abap_behv=>mk-on
                                           %control-transporterdocdate = if_abap_behv=>mk-on
                                           %control-TransporterDocNum = if_abap_behv=>mk-on
                                           %control-vehiclenumber = if_abap_behv=>mk-on
                                           %control-vehicletype = if_abap_behv=>mk-on
                                           %control-igstamount = if_abap_behv=>mk-on
                                           %control-cgstamount = if_abap_behv=>mk-on
                                           %control-sgstamount = if_abap_behv=>mk-on
                                           %control-Documenttype = if_abap_behv=>mk-on
                                           %control-Company_Code = if_abap_behv=>mk-on
                                           %control-fiscalyear = if_abap_behv=>mk-on
                                           %control-EwaybillGenerated = if_abap_behv=>mk-on
                                           %control-EwaybillNumber = if_abap_behv=>mk-on
                                           %control-EwaybillValidUpto = if_abap_behv=>mk-on
                                           %control-EwaybillDistance = if_abap_behv=>mk-on
                                           %control-EwaybillError = if_abap_behv=>mk-on
                                           %control-EwayFail = if_abap_behv=>mk-on
                                           %control-Billfromgstin = if_abap_behv=>mk-on
                                           %control-LocationGstin = if_abap_behv=>mk-on
                                           %control-Billfromlegalname = if_abap_behv=>mk-on
                                           %control-Billfromaddress1 = if_abap_behv=>mk-on
                                           %control-Billfromaddress2 = if_abap_behv=>mk-on
                                           %control-Billfromcity = if_abap_behv=>mk-on
                                           %control-Billfrompincode = if_abap_behv=>mk-on
                                           %control-Billtoaddress1 = if_abap_behv=>mk-on
                                           %control-Billtoaddress2 = if_abap_behv=>mk-on
                                           %control-Billtocity = if_abap_behv=>mk-on
                                           %control-Billtogstin = if_abap_behv=>mk-on
                                           %control-Billtolegalname = if_abap_behv=>mk-on
                                           %control-Billtopincode = if_abap_behv=>mk-on
                                           %control-Dispatchfromname = if_abap_behv=>mk-on
                                           %control-Dispatchfromadd1 = if_abap_behv=>mk-on
                                           %control-Dispatchfromadd2 = if_abap_behv=>mk-on
                                           %control-Dispatchfromcity = if_abap_behv=>mk-on
                                           %control-Dispatchfrompincode = if_abap_behv=>mk-on
                                           %control-Shiptoadd1 = if_abap_behv=>mk-on
                                           %control-Shiptoadd2 = if_abap_behv=>mk-on
                                           %control-Shiptocity = if_abap_behv=>mk-on
                                           %control-Shiptopincode = if_abap_behv=>mk-on
                                           %control-Success = if_abap_behv=>mk-on
                                           %control-fail = if_abap_behv=>mk-on
                                           %control-Dispatchfromgstin = if_abap_behv=>mk-on
                                           %control-Shiptogstin = if_abap_behv=>mk-on
                                           %control-Shiptoname = if_abap_behv=>mk-on ) ).
                  reported-zmm_c_challan = VALUE #( ( %msg = new_message( id = 'ZSD_MSG_CYG'
                                                                                 number = '010'
                                                                                 severity = if_abap_behv_message=>severity-success
                                                                                 v1 = keys[ 1 ]-DocumentNumber ) )  ) .
                ENDIF.
              CATCH cx_sy_itab_line_not_found.
            ENDTRY.
          ELSEIF lv_status EQ 'IP' OR lv_status EQ 'YNS'.
            IF wa_success_ewb-status EQ 'IP' AND wa_success_ewb-referenceid IS NOT INITIAL.
              WAIT UP TO 1 SECONDS.
              CLEAR lv_response.
              lo_invoice->call_cpi( EXPORTING  iv_action       = 'Status'
                                               iv_reference_id = wa_success_ewb-referenceid
                                    IMPORTING  ev_response     = lv_response ).
              /ui2/cl_json=>deserialize( EXPORTING json = lv_response
                                         CHANGING  data = wa_success_ewb ).
              TRY.
                  CLEAR wa_data.
                  wa_data = lt_table[ 1 ].
                  DATA(wa_ewb_det1) = wa_success_ewb-datareport[ 1 ].
                  lt_create = VALUE #( ( documentnumber = keys[ 1 ]-DocumentNumber
                                          documentdate = keys[ 1 ]-DocumentDate
                                          company_code = keys[ 1 ]-Company_Code
                                          documentvalue = wa_data-documentvalue
                                          cgstamount = wa_data-cgstamount
                                          sgstamount = wa_data-sgstamount
                                          igstamount = wa_data-igstamount
                                          LocationGstin = wa_data-locationgstin
                                          Billfromgstin = wa_data-billfromgstin
                                          Documenttype = wa_data-documenttype
                                          Billfromlegalname = wa_data-billfromlegalname
                                          Billfromaddress1 = wa_data-billfromaddress1
                                          Billfromaddress2 = wa_data-billfromaddress2
                                          Billfromcity = wa_data-billfromcity
                                          Billfrompincode = wa_data-billfrompincode
                                          Billtoaddress1 = wa_data-billtoaddress1
                                          Billtoaddress2 = wa_data-billtoaddress2
                                          Billtocity = wa_data-billtocity
                                          Billtogstin = wa_data-billtogstin
                                          Billtolegalname = wa_data-billtolegalname
                                          Billtopincode = wa_data-billtopincode
                                          Dispatchfromgstin = wa_data-dispatchfromgstin
                                          Dispatchfromname = wa_data-billfromlegalname
                                          Dispatchfromadd1 = wa_data-dispatchfromadd1
                                          Dispatchfromadd2 = wa_data-dispatchfromadd2
                                          Dispatchfromcity = wa_data-dispatchfromcity
                                          Dispatchfrompincode = wa_data-dispatchfrompincode
                                          Shiptoadd1 = wa_data-shiptoadd1
                                          Shiptoadd2 = wa_data-shiptoadd2
                                          Shiptocity = wa_data-shiptocity
                                          Shiptopincode = wa_data-shiptopincode
                                          Shiptoname = wa_data-Shiptoname
                                          Shiptogstin = wa_data-shiptogstin
                                          EwaybillNumber = wa_ewb_det1-ewb-eway_bill_number
                                          EwaybillValidUpto = wa_ewb_det1-ewb-eway_bill_valid_upto
                                          EwaybillGenerated = 'X'
                                          Success = 'X'
                                          fail = ''
                                          %control-DocumentNumber = if_abap_behv=>mk-on
                                          %control-DocumentDate = if_abap_behv=>mk-on
                                          %control-Documenttype = if_abap_behv=>mk-on
                                          %control-Documentvalue = if_abap_behv=>mk-on
                                          %control-igstamount = if_abap_behv=>mk-on
                                          %control-cgstamount = if_abap_behv=>mk-on
                                          %control-sgstamount = if_abap_behv=>mk-on
                                          %control-Company_Code = if_abap_behv=>mk-on
                                          %control-fiscalyear = if_abap_behv=>mk-on
                                          %control-EwaybillGenerated = if_abap_behv=>mk-on
                                          %control-EwaybillNumber = if_abap_behv=>mk-on
                                          %control-EwaybillValidUpto = if_abap_behv=>mk-on
                                          %control-Billfromgstin = if_abap_behv=>mk-on
                                          %control-LocationGstin = if_abap_behv=>mk-on
                                          %control-Billfromlegalname = if_abap_behv=>mk-on
                                          %control-Billfromaddress1 = if_abap_behv=>mk-on
                                          %control-Billfromaddress2 = if_abap_behv=>mk-on
                                          %control-Billfromcity = if_abap_behv=>mk-on
                                          %control-Billfrompincode = if_abap_behv=>mk-on
                                          %control-Billtoaddress1 = if_abap_behv=>mk-on
                                          %control-Billtoaddress2 = if_abap_behv=>mk-on
                                          %control-Billtocity = if_abap_behv=>mk-on
                                          %control-Billtogstin = if_abap_behv=>mk-on
                                          %control-Billtolegalname = if_abap_behv=>mk-on
                                          %control-Billtopincode = if_abap_behv=>mk-on
                                          %control-Dispatchfromname = if_abap_behv=>mk-on
                                          %control-Dispatchfromadd1 = if_abap_behv=>mk-on
                                          %control-Dispatchfromadd2 = if_abap_behv=>mk-on
                                          %control-Dispatchfromcity = if_abap_behv=>mk-on
                                          %control-Dispatchfrompincode = if_abap_behv=>mk-on
                                          %control-Shiptoadd1 = if_abap_behv=>mk-on
                                          %control-Shiptoadd2 = if_abap_behv=>mk-on
                                          %control-Shiptocity = if_abap_behv=>mk-on
                                          %control-Shiptopincode = if_abap_behv=>mk-on
                                          %control-Success = if_abap_behv=>mk-on
                                          %control-fail = if_abap_behv=>mk-on
                                          %control-Dispatchfromgstin = if_abap_behv=>mk-on
                                          %control-Shiptogstin = if_abap_behv=>mk-on
                                          %control-Shiptoname = if_abap_behv=>mk-on ) ).
                  reported-zmm_c_challan = VALUE #( ( %msg = new_message( id = 'ZSD_MSG_CYG'
                                                                                 number = '010'
                                                                                 severity = if_abap_behv_message=>severity-success
                                                                                 v1 = keys[ 1 ]-DocumentNumber ) )  ) .
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
            ENDIF.
          ELSEIF lv_status EQ 'PE'.
            IF wa_success_ewb-validationreport IS NOT INITIAL.
              DATA(wa_validation_report) = wa_success_ewb-validationreport[ 1 ].
              IF wa_validation_report IS NOT INITIAL.
                LOOP AT wa_validation_report-propertyerrors INTO DATA(wa_property_errors).
                  lv_error = |{ lv_error } | && '|' &&  | { wa_property_errors-errors[ 1 ]-message }|.
                ENDLOOP.
                IF lv_error IS NOT INITIAL.
                  lv_counter = lv_counter + 1.
                  TRY.
                      wa_data = lt_table[ 1 ].
                      lt_create = VALUE #( ( documentnumber = keys[ 1 ]-DocumentNumber
                                        documentdate = keys[ 1 ]-DocumentDate
                                        company_code = keys[ 1 ]-Company_Code
                                        LocationGstin = wa_data-locationgstin
                                        Billfromgstin = wa_data-billfromgstin
                                        Documenttype = wa_data-documenttype
                                        documentvalue = wa_data-documentvalue
                                        cgstamount = wa_data-cgstamount
                                        sgstamount = wa_data-sgstamount
                                        igstamount = wa_data-igstamount
                                        Billfromlegalname = wa_data-billfromlegalname
                                        Billfromaddress1 = wa_data-billfromaddress1
                                        Billfromaddress2 = wa_data-billfromaddress2
                                        Billfromcity = wa_data-billfromcity
                                        Billfrompincode = wa_data-billfrompincode
                                        Billtoaddress1 = wa_data-billtoaddress1
                                        Billtoaddress2 = wa_data-billtoaddress2
                                        Billtocity = wa_data-billtocity
                                        Billtogstin = wa_data-billtogstin
                                        Billtolegalname = wa_data-billtolegalname
                                        Billtopincode = wa_data-billtopincode
                                        Dispatchfromgstin = wa_data-dispatchfromgstin
                                        Dispatchfromname = wa_data-billfromlegalname
                                        Dispatchfromadd1 = wa_data-dispatchfromadd1
                                        Dispatchfromadd2 = wa_data-dispatchfromadd2
                                        Dispatchfromcity = wa_data-dispatchfromcity
                                        Dispatchfrompincode = wa_data-dispatchfrompincode
                                        Shiptoadd1 = wa_data-shiptoadd1
                                        Shiptoadd2 = wa_data-shiptoadd2
                                        Shiptocity = wa_data-shiptocity
                                        Shiptopincode = wa_data-shiptopincode
                                        Shiptoname = wa_data-Shiptoname
                                        Shiptogstin = wa_data-shiptogstin
                                        EwaybillNumber = wa_ewb_det-ewb-ewaybillnumber
                                        EwaybillValidUpto = wa_ewb_det-ewb-validupto
                                        EwayFail = 'X'
                                        EwaybillError = lv_error
                                        fail = ''
                                        transporterid = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transporterid )
                                        transportername = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportername )
                                        transportmode = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportmode )
                                        transporterdocdate = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportdocumentdate )
                                        TransporterDocNum = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportdocumentnum )
                                        vehiclenumber = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-vehiclenumber )
                                        vehicletype = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-vehicletype )
                                        %control-DocumentNumber = if_abap_behv=>mk-on
                                        %control-DocumentDate = if_abap_behv=>mk-on
                                        %control-Documenttype = if_abap_behv=>mk-on
                                        %control-Documentvalue = if_abap_behv=>mk-on
                                        %control-igstamount = if_abap_behv=>mk-on
                                        %control-cgstamount = if_abap_behv=>mk-on
                                        %control-sgstamount = if_abap_behv=>mk-on
                                        %control-Company_Code = if_abap_behv=>mk-on
                                        %control-fiscalyear = if_abap_behv=>mk-on
                                        %control-EwayFail = if_abap_behv=>mk-on
                                        %control-EwaybillError = if_abap_behv=>mk-on
                                        %control-EwaybillNumber = if_abap_behv=>mk-on
                                        %control-EwaybillValidUpto = if_abap_behv=>mk-on
                                        %control-Billfromgstin = if_abap_behv=>mk-on
                                        %control-LocationGstin = if_abap_behv=>mk-on
                                        %control-Billfromlegalname = if_abap_behv=>mk-on
                                        %control-Billfromaddress1 = if_abap_behv=>mk-on
                                        %control-Billfromaddress2 = if_abap_behv=>mk-on
                                        %control-Billfromcity = if_abap_behv=>mk-on
                                        %control-Billfrompincode = if_abap_behv=>mk-on
                                        %control-Billtoaddress1 = if_abap_behv=>mk-on
                                        %control-Billtoaddress2 = if_abap_behv=>mk-on
                                        %control-Billtocity = if_abap_behv=>mk-on
                                        %control-Billtogstin = if_abap_behv=>mk-on
                                        %control-Billtolegalname = if_abap_behv=>mk-on
                                        %control-Billtopincode = if_abap_behv=>mk-on
                                        %control-Dispatchfromname = if_abap_behv=>mk-on
                                        %control-Dispatchfromadd1 = if_abap_behv=>mk-on
                                        %control-Dispatchfromadd2 = if_abap_behv=>mk-on
                                        %control-Dispatchfromcity = if_abap_behv=>mk-on
                                        %control-Dispatchfrompincode = if_abap_behv=>mk-on
                                        %control-Shiptoadd1 = if_abap_behv=>mk-on
                                        %control-Shiptoadd2 = if_abap_behv=>mk-on
                                        %control-Shiptocity = if_abap_behv=>mk-on
                                        %control-Shiptopincode = if_abap_behv=>mk-on
                                        %control-Success = if_abap_behv=>mk-on
                                        %control-fail = if_abap_behv=>mk-on
                                        %control-Dispatchfromgstin = if_abap_behv=>mk-on
                                        %control-Shiptogstin = if_abap_behv=>mk-on
                                        %control-Shiptoname = if_abap_behv=>mk-on
                                        %control-transporterid = if_abap_behv=>mk-on
                                        %control-transportername = if_abap_behv=>mk-on
                                        %control-transportmode = if_abap_behv=>mk-on
                                        %control-transporterdocdate = if_abap_behv=>mk-on
                                        %control-TransporterDocNum = if_abap_behv=>mk-on
                                        %control-vehiclenumber = if_abap_behv=>mk-on
                                        %control-vehicletype = if_abap_behv=>mk-on ) ).
                      reported-zmm_c_challan = VALUE #( FOR wa_error IN wa_validation_report-propertyerrors
                                                      ( %msg = new_message_with_text( text = wa_error-errors[ 1 ]-message
                                                                                      severity = if_abap_behv_message=>severity-error ) )  ).
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                ENDIF.
              ENDIF.
            ELSEIF wa_success_ewb-datareport IS NOT INITIAL.
              DATA(wa_validation_report1) = wa_success_ewb-datareport[ 1 ].
              IF wa_validation_report1 IS NOT INITIAL.
                LOOP AT wa_validation_report1-ewb-errors INTO DATA(wa_property_errors1).
                  lv_error = |{ lv_error } | && '|' &&  | { wa_property_errors1-message }|.
                ENDLOOP.
                IF lv_error IS NOT INITIAL.
                  lv_counter = lv_counter + 1.
                  TRY.
                      wa_data = lt_table[ 1 ].
                      lt_create = VALUE #( ( documentnumber = keys[ 1 ]-DocumentNumber
                                        documentdate = keys[ 1 ]-DocumentDate
                                        company_code = keys[ 1 ]-Company_Code
                                        LocationGstin = wa_data-locationgstin
                                        Billfromgstin = wa_data-billfromgstin
                                        Documenttype = wa_data-documenttype
                                        documentvalue = wa_data-documentvalue
                                        cgstamount = wa_data-cgstamount
                                        sgstamount = wa_data-sgstamount
                                        igstamount = wa_data-igstamount
                                        Billfromlegalname = wa_data-billfromlegalname
                                        Billfromaddress1 = wa_data-billfromaddress1
                                        Billfromaddress2 = wa_data-billfromaddress2
                                        Billfromcity = wa_data-billfromcity
                                        Billfrompincode = wa_data-billfrompincode
                                        Billtoaddress1 = wa_data-billtoaddress1
                                        Billtoaddress2 = wa_data-billtoaddress2
                                        Billtocity = wa_data-billtocity
                                        Billtogstin = wa_data-billtogstin
                                        Billtolegalname = wa_data-billtolegalname
                                        Billtopincode = wa_data-billtopincode
                                        Dispatchfromgstin = wa_data-dispatchfromgstin
                                        Dispatchfromname = wa_data-billfromlegalname
                                        Dispatchfromadd1 = wa_data-dispatchfromadd1
                                        Dispatchfromadd2 = wa_data-dispatchfromadd2
                                        Dispatchfromcity = wa_data-dispatchfromcity
                                        Dispatchfrompincode = wa_data-dispatchfrompincode
                                        Shiptoadd1 = wa_data-shiptoadd1
                                        Shiptoadd2 = wa_data-shiptoadd2
                                        Shiptocity = wa_data-shiptocity
                                        Shiptopincode = wa_data-shiptopincode
                                        Shiptoname = wa_data-Shiptoname
                                        Shiptogstin = wa_data-shiptogstin
                                        EwaybillNumber = wa_ewb_det-ewb-ewaybillnumber
                                        EwaybillValidUpto = wa_ewb_det-ewb-validupto
                                        EwayFail = 'X'
                                        EwaybillError = lv_error
                                        fail = ''
                                        transporterid = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transporterid )
                                        transportername = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportername )
                                        transportmode = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportmode )
                                        transporterdocdate = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportdocumentdate )
                                        TransporterDocNum = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-transportdocumentnum )
                                        vehiclenumber = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-vehiclenumber )
                                        vehicletype = COND #( WHEN lt_transport_p IS NOT INITIAL THEN lt_transport_p[ 1 ]-vehicletype )
                                        %control-DocumentNumber = if_abap_behv=>mk-on
                                        %control-DocumentDate = if_abap_behv=>mk-on
                                        %control-Documenttype = if_abap_behv=>mk-on
                                        %control-Documentvalue = if_abap_behv=>mk-on
                                        %control-igstamount = if_abap_behv=>mk-on
                                        %control-cgstamount = if_abap_behv=>mk-on
                                        %control-sgstamount = if_abap_behv=>mk-on
                                        %control-Company_Code = if_abap_behv=>mk-on
                                        %control-fiscalyear = if_abap_behv=>mk-on
                                        %control-EwayFail = if_abap_behv=>mk-on
                                        %control-EwaybillError = if_abap_behv=>mk-on
                                        %control-EwaybillNumber = if_abap_behv=>mk-on
                                        %control-EwaybillValidUpto = if_abap_behv=>mk-on
                                        %control-Billfromgstin = if_abap_behv=>mk-on
                                        %control-LocationGstin = if_abap_behv=>mk-on
                                        %control-Billfromlegalname = if_abap_behv=>mk-on
                                        %control-Billfromaddress1 = if_abap_behv=>mk-on
                                        %control-Billfromaddress2 = if_abap_behv=>mk-on
                                        %control-Billfromcity = if_abap_behv=>mk-on
                                        %control-Billfrompincode = if_abap_behv=>mk-on
                                        %control-Billtoaddress1 = if_abap_behv=>mk-on
                                        %control-Billtoaddress2 = if_abap_behv=>mk-on
                                        %control-Billtocity = if_abap_behv=>mk-on
                                        %control-Billtogstin = if_abap_behv=>mk-on
                                        %control-Billtolegalname = if_abap_behv=>mk-on
                                        %control-Billtopincode = if_abap_behv=>mk-on
                                        %control-Dispatchfromname = if_abap_behv=>mk-on
                                        %control-Dispatchfromadd1 = if_abap_behv=>mk-on
                                        %control-Dispatchfromadd2 = if_abap_behv=>mk-on
                                        %control-Dispatchfromcity = if_abap_behv=>mk-on
                                        %control-Dispatchfrompincode = if_abap_behv=>mk-on
                                        %control-Shiptoadd1 = if_abap_behv=>mk-on
                                        %control-Shiptoadd2 = if_abap_behv=>mk-on
                                        %control-Shiptocity = if_abap_behv=>mk-on
                                        %control-Shiptopincode = if_abap_behv=>mk-on
                                        %control-Success = if_abap_behv=>mk-on
                                        %control-fail = if_abap_behv=>mk-on
                                        %control-Dispatchfromgstin = if_abap_behv=>mk-on
                                        %control-Shiptogstin = if_abap_behv=>mk-on
                                        %control-Shiptoname = if_abap_behv=>mk-on
                                        %control-transporterid = if_abap_behv=>mk-on
                                        %control-transportername = if_abap_behv=>mk-on
                                        %control-transportmode = if_abap_behv=>mk-on
                                        %control-transporterdocdate = if_abap_behv=>mk-on
                                        %control-TransporterDocNum = if_abap_behv=>mk-on
                                        %control-vehiclenumber = if_abap_behv=>mk-on
                                        %control-vehicletype = if_abap_behv=>mk-on ) ).
                      reported-zmm_c_challan = VALUE #( FOR wa_error1 IN wa_validation_report1-ewb-errors
                                                      ( %msg = new_message_with_text( text = wa_error1-message
                                                                                      severity = if_abap_behv_message=>severity-error ) )  ).
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
      IF lt_create IS NOT INITIAL AND lt_exist IS NOT INITIAL.
        IF lt_create[ 1 ]-DocumentNumber EQ lt_exist[ 1 ]-DocumentNumber.
          lt_update = CORRESPONDING #( lt_create ).
          CLEAR : lt_create.
        ENDIF.
      ENDIF.
      IF lt_create IS NOT INITIAL OR lt_update IS NOT INITIAL.
        MODIFY ENTITIES OF zmm_c_challan
        IN LOCAL MODE
        ENTITY zmm_c_challan
        CREATE AUTO FILL CID WITH lt_create
        UPDATE FROM lt_update
        REPORTED DATA(lt_reported)
        FAILED DATA(lt_failed)
        MAPPED DATA(lt_mapped).
      ENDIF.
    ENDIF.
  ENDMETHOD.

  METHOD get_resp.
    DATA: wa_get_response_req TYPE ty_cancel_request,
          lt_get_response     TYPE STANDARD TABLE OF ty_data_report,
          lt_update_log       TYPE TABLE FOR UPDATE zmm_c_challan,
          lt_error_log        TYPE STANDARD TABLE OF ty_property_error,
          lv_error            TYPE string,
          lv_counter          TYPE char10 VALUE '1'.
    DATA(lo_invoice) = NEW zcl_invoice(  ).
    SELECT document_number,document_date,company_code,fiscal_year,location_gstin,billfromgstin,documenttype
    FROM zsd_t_einv_log
    FOR ALL ENTRIES IN @keys
    WHERE document_number = @keys-DocumentNumber
    INTO TABLE @DATA(lt_einv_log).
    IF lt_einv_log IS NOT INITIAL.
      wa_get_response_req-criterias = VALUE #( FOR wa_einv_log IN lt_einv_log (
                                                 location_gstin = wa_einv_log-location_gstin
                                                 document_number = |{ wa_einv_log-document_number ALPHA = OUT }|
                                                 document_date = |{ wa_einv_log-document_date+6(2) }-{ wa_einv_log-document_date+4(2) }-{ wa_einv_log-document_date+0(4) }|
                                                 document_type = wa_einv_log-documenttype
                                                 bill_from_gstin = wa_einv_log-billfromgstin
                                                 supply_type = 'S' ) ).
      DATA(lv_get_response_req) = /ui2/cl_json=>serialize( EXPORTING data = wa_get_response_req
                                                                pretty_name = /ui2/cl_json=>pretty_mode-camel_case ).
      IF lv_get_response_req IS NOT INITIAL.
        lo_invoice->call_cpi( EXPORTING iv_req_payload = lv_get_response_req
                                        iv_action = 'GetEwaybillResponse'
                              IMPORTING ev_response = DATA(lv_response) ).
        FIND REGEX '"ewayBillNumber"\s*:\s*([0-9]+)' IN lv_response SUBMATCHES DATA(lv_ewaybill).
        IF lv_ewaybill IS NOT INITIAL.
          /ui2/cl_json=>deserialize( EXPORTING json = lv_response
                                     CHANGING data = lt_get_response ).
          FIND REGEX 'pushStatus"\s*:\s*"([^"]*)' IN lv_response SUBMATCHES DATA(lv_pushstatus).
          IF lv_pushstatus EQ 'Cancelled'.
            TRY.
                DATA(wa_eway_response) = lt_get_response[ 1 ].
                lt_update_log = VALUE #( FOR wa_einv_log IN lt_einv_log ( documentnumber = wa_einv_log-document_number
                                                 documentdate = wa_einv_log-document_date
                                                 company_code = wa_einv_log-company_code
                                                 EwaybillNumber = lv_ewaybill
                                                 EwaybillValidUpto = wa_eway_response-validupto
                                                 EwaybillDistance = wa_eway_response-distance
                                                 EwaybillGenerated = ''
                                                 EwayCancel = 'X'
                                                 %control-DocumentNumber = if_abap_behv=>mk-on
                                                 %control-DocumentDate = if_abap_behv=>mk-on
                                                 %control-Company_Code = if_abap_behv=>mk-on
                                                 %control-EwaybillNumber = if_abap_behv=>mk-on
                                                 %control-EwaybillGenerated = if_abap_behv=>mk-on
                                                 %control-EwaybillValidUpto = if_abap_behv=>mk-on
                                                 %control-EwayCancel = if_abap_behv=>mk-on
                                                 %control-EwaybillDistance = if_abap_behv=>mk-on ) ).
                reported-zmm_c_challan = VALUE #( (
                                          %msg = new_message( id = 'EWB'
                                                              number = '1'
                                                              severity = if_abap_behv_message=>severity-information
                                                              v1 = 'E-Way Bill Cancelled'
                                                             )
                     ) ).
              CATCH cx_sy_itab_line_not_found.
            ENDTRY.
          ELSE.
            TRY.
                wa_eway_response = lt_get_response[ 1 ].
                lt_update_log = VALUE #( FOR wa_einv_log IN lt_einv_log ( documentnumber = wa_einv_log-document_number
                                               documentdate = wa_einv_log-document_date
                                               company_code = wa_einv_log-company_code
                                               EwaybillNumber = lv_ewaybill
                                               EwaybillValidUpto = wa_eway_response-validupto
                                               EwaybillDistance = wa_eway_response-distance
                                               EwaybillGenerated = 'X'
                                               EwaybillError = ''
                                               EwayFail = ''
                                               %control-DocumentNumber = if_abap_behv=>mk-on
                                               %control-DocumentDate = if_abap_behv=>mk-on
                                               %control-Company_Code = if_abap_behv=>mk-on
                                               %control-EwaybillNumber = if_abap_behv=>mk-on
                                               %control-EwaybillGenerated = if_abap_behv=>mk-on
                                               %control-EwaybillValidUpto = if_abap_behv=>mk-on
                                               %control-EwaybillError = if_abap_behv=>mk-on
                                               %control-EwayFail = if_abap_behv=>mk-on
                                               %control-EwaybillDistance = if_abap_behv=>mk-on ) ).
                reported-zmm_c_challan = VALUE #( (
                                                         %msg = new_message( id = 'EWB'
                                                                             number = '1'
                                                                             severity = if_abap_behv_message=>severity-information
                                                                             v1 = 'E-Way Bill Retrived Sucessfully'
                                                                            )
                                    ) ).
              CATCH cx_sy_itab_line_not_found.
            ENDTRY.
          ENDIF.
        ELSE.
          /ui2/cl_json=>deserialize( EXPORTING json = lv_response
                                     CHANGING data = lt_error_log ).
          DATA(lt_errors) = VALUE string_table(
                                               FOR wa_error IN lt_error_log
                                               FOR wa_error_detail IN wa_error-errors
                                               ( wa_error_detail-message ) ).
          lv_error = concat_lines_of( table = lt_errors sep = ' | ' ).
          lt_update_log = VALUE #( FOR wa_einv_log IN lt_einv_log ( documentnumber = wa_einv_log-document_number
                                             documentdate = wa_einv_log-document_date
                                             company_code = wa_einv_log-company_code
                                             EwayFail = 'X'
                                             EwaybillError = lv_error
                                             %control-DocumentNumber = if_abap_behv=>mk-on
                                             %control-DocumentDate = if_abap_behv=>mk-on
                                             %control-Company_Code = if_abap_behv=>mk-on
                                             %control-EwayFail = if_abap_behv=>mk-on
                                             %control-EwaybillError = if_abap_behv=>mk-on ) ).
          reported-zmm_c_challan = VALUE #( ( %msg = new_message_with_text( text = lv_error
                                                                           severity = if_abap_behv_message=>severity-error ) )  ).
        ENDIF.
        IF lt_update_log IS NOT INITIAL.
          MODIFY ENTITIES OF zmm_c_challan IN LOCAL MODE
            ENTITY zmm_c_challan
            UPDATE FROM lt_update_log
            FAILED DATA(lt_failed)
            REPORTED DATA(lt_reported)
            MAPPED DATA(lt_mapped).
        ENDIF.
      ELSE.
        reported-zmm_c_challan = VALUE #( ( %msg = new_message( id = 'ZSD_MSG_CYG'
                                                                number = '002'
                                                                severity = if_abap_behv_message=>severity-error
                                                                v1 = keys[ 1 ]-DocumentNumber ) )  ) .
      ENDIF.
    ENDIF.
  ENDMETHOD.

  METHOD download_pdf.
*    DATA: lt_final_temp TYPE zsd_tt_ewb_status,
*          lt_form_a     TYPE zsd_tt_ewb_part_a,
*          lt_form_qr    TYPE zsd_tt_ewb_part_a,
*          lt_form_ewb   TYPE zsd_tt_ewb_part_a,
*          lt_form_irn   TYPE zsd_tt_ewb_part_a,
*          lt_form_b     TYPE zsd_tt_ewb_part_b.
*    DATA: lv_fm_name TYPE rs38l_fnam,
*          wa_control TYPE ssfctrlop,
*          wa_output  TYPE ssfcrescl.
*    lv_fm_name = '/1BCDWB/SF00000097'.
*    wa_control-no_dialog = abap_true.
*    wa_control-preview   = abap_false.
*    wa_control-getotf    = abap_true.
*    CALL FUNCTION lv_fm_name
*      EXPORTING
*        control_parameters = wa_control
*        user_settings      = 'X'
*      IMPORTING
*        job_output_info    = wa_output
*      TABLES
*        gt_data            = lt_final_temp
*        gt_form_qr         = lt_form_qr
*        gt_form_ewb        = lt_form_ewb
*        gt_form_irn        = lt_form_irn
*        gt_form_a          = lt_form_a
*        gt_form_b          = lt_form_b
*      EXCEPTIONS
*        formatting_error   = 1
*        internal_error     = 2
*        send_error         = 3
*        user_canceled      = 4
*        OTHERS             = 5.
*    DATA: lt_otf        TYPE STANDARD TABLE OF itcoo,
*          lt_lines      TYPE STANDARD TABLE OF tline,
*          lv_pdf        TYPE xstring,
*          lv_pdf_base64 TYPE string.
*    lt_otf = wa_output-otfdata.
*    CALL FUNCTION 'CONVERT_OTF'
*      EXPORTING
*        format                = 'PDF'
*      IMPORTING
*        bin_file              = lv_pdf
*      TABLES
*        otf                   = lt_otf
*        lines                 = lt_lines
*      EXCEPTIONS
*        err_max_linewidth     = 1
*        err_format            = 2
*        err_conv_not_possible = 3
*        err_bad_otf           = 4
*        OTHERS                = 5.
*    IF sy-subrc <> 0.
*      RETURN.
*    ENDIF.
*    lv_pdf_base64 = cl_http_utility=>encode_x_base64( lv_pdf ).
*    result = VALUE #( (
*           %tky = keys[ 1 ]-%tky
*        %param-FileName = |{ keys[ 1 ]-DocumentNumber }.pdf|
*       %param-mimeType = 'application/pdf'
*          %param-pdf_data = lv_pdf_base64
*       ) ).
  ENDMETHOD.
ENDCLASS.
