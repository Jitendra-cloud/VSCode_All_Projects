@EndUserText.label: 'Action Param for Uploading Excel'
define root abstract entity ZA_EXCELUPLOADPARAM
{
  mimeType : abap.string(0);
  fileName : abap.string(0);
  pdf_data : abap.string(9999999);

}
