@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'CDS View for Challan Documents'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.query.implementedBy: 'ABAP:ZCL_INVOICE'
@Metadata.allowExtensions: true
define root view entity ZMM_C_CHALLAN
  as select from zsd_t_einv_log
{
  key document_number         as DocumentNumber,
  key document_date           as DocumentDate,
  key company_code            as Company_Code,
      fiscal_year             as FiscalYear,
      location_gstin          as LocationGstin,
      billfromgstin           as Billfromgstin,
      billfromname            as Billfromlegalname,
      billfromadd1            as Billfromaddress1,
      billfromadd2            as Billfromaddress2,
      billfrompincode         as Billfrompincode,
      billfromcity            as Billfromcity,
      billtogstin             as Billtogstin,
      billtoname              as Billtolegalname,
      billtoadd1              as Billtoaddress1,
      billtoadd2              as Billtoaddress2,
      billtopincode           as Billtopincode,
      billtocity              as Billtocity,
      dispatchfromgstin       as Dispatchfromgstin,
      dispatchfromname        as Dispatchfromname,
      dispatchfromadd1        as Dispatchfromadd1,
      dispatchfromadd2        as Dispatchfromadd2,
      dispatchfrompincode     as Dispatchfrompincode,
      dispatchfromcity        as Dispatchfromcity,
      shiptogstin             as Shiptogstin,
      shiptoname              as Shiptoname,
      shiptoadd1              as Shiptoadd1,
      shiptoadd2              as Shiptoadd2,
      shiptopincode           as Shiptopincode,
      shiptocity              as Shiptocity,
      referencedocumentnumber as Referencedocumentnumber,
      documenttype            as Documenttype,
      pending                 as Pending,
      fail                    as Fail,
      success                 as Success,
      cancel                  as Cancel,
      cancel_date             as CancelDate,
      cancel_by               as CancelBy,
      cancel_time             as CancelTime,
      entry_date              as EntryDate,
      entry_time              as EntryTime,
      einv_module             as EinvModule,
      einv_error              as EinvError,
      irn                     as Irn,
      buss_place              as BussPlace,
      ack_no                  as AckNo,
      ack_date                as AckDate,
      qrcode                  as Qrcode,
      signed_qrcode           as SignedQrcode,
      signed_inv              as SignedInv,
      ewaybill_number         as EwaybillNumber,
      ewaybill_valid_upto     as EwaybillValidUpto,
      ewaybill_generated      as EwaybillGenerated,
      ewaybill_error          as EwaybillError,
      ewaybill_distance       as EwaybillDistance,
      //      ewb_status              as EwaybillStatus,
      eway_gen                as EwayGen,
      eway_fail               as EwayFail,
      eway_cancel             as EwayCancel,
      eway_cancel_date        as EwayCancelDate,
      eway_cancel_by          as EwayCancelBy,
      eway_cancel_time        as EwayCancelTime,
      documentvalue,
      taxablevalue,
      cgstamount,
      sgstamount,
      igstamount,

      case
      when eway_cancel = 'X' then 'E-Way Bill Cancelled'
      when eway_fail = 'X' then 'Error!'
      when ewaybill_number        = ''  then 'E-Way Bill Pending'
      else 'E-Way Bill Generated'
      end                     as ewb_status,

      @UI.hidden: true
      case
      when eway_cancel = 'X' then 1
      when eway_fail = 'X' then 1
      when ewaybill_number  = ''  then 2
      else 3
      end                     as ewb_icon,

      plant                   as Plant,
      transporter_id          as TransporterId,
      transporter_name        as TransporterName,
      transport_mode          as TransportMode,
      transporter_doc_num     as TransporterDocNum,
      transporter_doc_date    as TransporterDocDate,
      vehicle_number          as VehicleNumber,
      vehicle_type            as VehicleType
}
