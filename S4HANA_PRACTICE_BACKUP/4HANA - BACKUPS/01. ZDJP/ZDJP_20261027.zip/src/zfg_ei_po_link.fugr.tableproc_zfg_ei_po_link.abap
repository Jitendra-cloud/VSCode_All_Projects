*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_EI_PO_LINK
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_EI_PO_LINK      .

  PERFORM TABLEPROC.

ENDFUNCTION.
