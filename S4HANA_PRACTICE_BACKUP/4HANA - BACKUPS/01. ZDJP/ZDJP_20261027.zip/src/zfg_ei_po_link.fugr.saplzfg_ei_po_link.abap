*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_EI_PO_LINKTOP.                " Global Declarations
  INCLUDE LZFG_EI_PO_LINKUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_EI_PO_LINKF...                " Subroutines
* INCLUDE LZFG_EI_PO_LINKO...                " PBO-Modules
* INCLUDE LZFG_EI_PO_LINKI...                " PAI-Modules
* INCLUDE LZFG_EI_PO_LINKE...                " Events
* INCLUDE LZFG_EI_PO_LINKP...                " Local class implement.
* INCLUDE LZFG_EI_PO_LINKT99.                " ABAP Unit tests
  INCLUDE LZFG_EI_PO_LINKF00                      . " subprograms
  INCLUDE LZFG_EI_PO_LINKI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
