FUNCTION-POOL ZFG_EI_PO_LINK             MESSAGE-ID SV.

* INCLUDE LZFG_EI_PO_LINKD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_EI_PO_LINKT00                      . "view rel. data dcl.
