CLASS zcl_js_consuming_api DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.

  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS zcl_js_consuming_api IMPLEMENTATION.

  METHOD if_oo_adt_classrun~main.

    DATA: lv_url         TYPE string,
          "lo_http_client TYPE REF TO if_web_http_client,
          lo_http_client TYPE REF TO if_http_client,
          emailid        TYPE string.

    TYPES: BEGIN OF ty_metadata,
             id   TYPE string,
             uri  TYPE string,
             type TYPE string,
           END OF ty_metadata,

           BEGIN OF ty_address_email,
             __metadata                     TYPE ty_metadata,
             addressid                      TYPE string,
             person                         TYPE string,
             ordinalnumber                  TYPE string,
             isdefaultemailaddress          TYPE string,
             emailaddress                   TYPE string,
             searchemailaddress             TYPE string,
             addresscommunicationremarktext TYPE string,
           END OF ty_address_email,

           BEGIN OF ty_root,
             d TYPE ty_address_email,
           END OF ty_root.

    DATA : lv_root TYPE ty_root.



    lv_url = |https://s4h2023.sapdemo.com:44303/sap/opu/odata/sap/API_BUSINESS_PARTNER/| &&
             |A_BusinessPartner?$top=5&$format=json|.

*    lv_url = |https://124.123.22.43:44303/sap/opu/odata/sap/API_BUSINESS_PARTNER/| &&
*             |A_BusinessPartner?$top=5&$format=json|.

    TRY.
        "lo_http_client = cl_web_http_client_manager=>create_by_http_destination( i_destination = cl_http_destination_provider=>create_by_url( i_url = lv_url ) ).

        CALL METHOD cl_http_client=>create_by_url
          EXPORTING
            url                = lv_url
          IMPORTING
            client             = lo_http_client
          EXCEPTIONS
            argument_not_found = 1
            plugin_not_active  = 2
            internal_error     = 3
            OTHERS             = 4.

        "DATA(lo_request) = lo_http_client->get_http_request( ).

        lo_http_client->request->set_header_field( name  = 'Accept'
                                                   value = 'application/json' ).

        lo_http_client->request->set_method( if_http_request=>co_request_method_get ).

        lo_http_client->request->set_authorization( username = 'S23A31' password = 'hana@1234' ).

        lo_http_client->send( EXPORTING timeout = 60 ).

        lo_http_client->receive( ).




        DATA: lv_status_code TYPE i,
              lv_status_text TYPE string.

        lo_http_client->response->get_status( IMPORTING code   = lv_status_code reason = lv_status_text ).

        DATA(lv_response) = lo_http_client->response->get_cdata( ).

        out->write( |HTTP Status: { lv_status_code }| ).
        out->write( |Reason: { lv_status_text }| ).

        out->write( lv_response ).

      CATCH cx_web_http_client_error
                cx_web_message_error
                INTO DATA(lx_error).

        out->write( lx_error->get_text( ) ).

    ENDTRY.

  ENDMETHOD.
ENDCLASS.
