@Metadata.ignorePropagatedAnnotations: true
@EndUserText.label: 'BookSupplement Interface Projection View'
@AccessControl.authorizationCheck: #NOT_REQUIRED
define view entity ZJS_I_BookingSupplement_D
  as projection on ZJS_R_BookingSupplement_D
{
  key BookSupplUUID,
      TravelUUID,
      BookingUUID,
      BookingSupplementID,
      SupplementID,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      BookSupplPrice,
      CurrencyCode,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      LocalLastChangedAt,
      /* Associations */
      _Booking : redirected to parent ZJS_I_Booking_D,
      _Product,
      _SupplementText,
      _Travel  : redirected to ZJS_I_Travel_D
}
