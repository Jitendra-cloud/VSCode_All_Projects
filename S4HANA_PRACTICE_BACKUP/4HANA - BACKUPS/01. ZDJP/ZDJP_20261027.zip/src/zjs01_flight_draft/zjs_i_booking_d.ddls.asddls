@Metadata.ignorePropagatedAnnotations: true
@EndUserText.label: 'Booking Interface Projection View '
@AccessControl.authorizationCheck: #NOT_REQUIRED
define view entity ZJS_I_Booking_D
  as projection on ZJS_R_Booking_D
{
  key BookingUUID,
      TravelUUID,
      BookingID,
      BookingDate,
      CustomerID,
      AirlineID,
      ConnectionID,
      FlightDate,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      FlightPrice,
      CurrencyCode,
      BookingStatus,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      LocalLastChangedAt,
      /* Associations */
      _BookingStatus,
      _BookingSupplement : redirected to composition child ZJS_I_BookingSupplement_D,
      _Carrier,
      _Connection,
      _Customer,
      _Travel            : redirected to parent ZJS_I_Travel_D
}
