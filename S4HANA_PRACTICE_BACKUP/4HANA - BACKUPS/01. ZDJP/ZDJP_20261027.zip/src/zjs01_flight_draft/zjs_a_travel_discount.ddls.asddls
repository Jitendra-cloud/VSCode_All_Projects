@EndUserText.label: 'Abstract Entity for Deducting Discount'
define abstract entity ZJS_A_Travel_Discount
{
  discount_percent : abap.int1;
}
