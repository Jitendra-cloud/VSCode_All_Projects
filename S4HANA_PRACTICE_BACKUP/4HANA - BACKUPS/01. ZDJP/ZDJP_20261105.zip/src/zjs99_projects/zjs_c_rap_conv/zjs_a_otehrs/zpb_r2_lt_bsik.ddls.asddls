@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'lt_bsik'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R2_LT_BSIK
  as select from    bsak_view            as b
    inner join      ZPB_R2_MT_ACC_DATA_1 as a on  b.bukrs = a.Bukrs
                                              and b.belnr = a.Belnr
                                              and b.gjahr = a.Gjahr

    left outer join t001                 as t on b.bukrs = t.bukrs
{
  key b.bukrs,
  key b.belnr,
  key b.gjahr,
  key b.buzei,
      b.zlspr,
      b.zterm,
      b.augbl,
      @Semantics.amount.currencyCode: 'waers'
      b.dmbtr,

      t.waers
}
where
  b.zlspr <> 'Y'
