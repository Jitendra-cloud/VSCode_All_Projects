@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'MT_ACC_DATA'
@Metadata.ignorePropagatedAnnotations: false
define view entity ZPB_R_MT_ACC_DATA_FILTERED
  as select from ZPB_R2_MT_ACC_DATA_1
{
  key Bukrs,
  key Belnr,
  key Gjahr,
      bldat,
      budat,
      cpudt,
      xblnr,
      bktxt,
      awtyp,
      awkey,
      awsys,
      blart,
      glvor,
      buzei,
      buzid,
      augdt,
      dmbtr,
      zfbdt,
      zbd1t,
      zbd2t,
      zbd3t,
      koart,
      shkzg,
      lifnr,
      rebzg,
      zuonr,
      sgtxt,
      mwskz,
      zlspr,
      umskz,
      prctr,
      gsber,
      kostl,
      bupla,
      secco,
      hsn_sac,
      gst_part,
      augbl,
      zterm,
      hwaer
}

where
  koart = 'K'
