CLASS zcl_ve_exit DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    INTERFACES if_sadl_exit .
    INTERFACES if_sadl_exit_calc_element_read .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS zcl_ve_exit IMPLEMENTATION.
  METHOD if_sadl_exit_calc_element_read~calculate.

    data(a) = 1.

  ENDMETHOD.

  METHOD if_sadl_exit_calc_element_read~get_calculation_info.

*    LOOP AT it_requested_calc_elements INTO DATA(ls_req).
*
*      CASE ls_req.
*        WHEN 'ATTACHMENTS'.
*          APPEND 'PAYMENTRUNDATE' TO et_requested_orig_elements.
*          APPEND 'PAYMENTRUNID' TO et_requested_orig_elements.
*      ENDCASE.
*
*    ENDLOOP.


  ENDMETHOD.

ENDCLASS.
