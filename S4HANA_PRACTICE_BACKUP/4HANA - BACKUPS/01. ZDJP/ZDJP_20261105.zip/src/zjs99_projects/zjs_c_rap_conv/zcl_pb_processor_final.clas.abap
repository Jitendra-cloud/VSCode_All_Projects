CLASS zcl_pb_processor_final DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.

    CONSTANTS:
      BEGIN OF mcs_msg_type,
        success     TYPE syst-msgty VALUE 'S',
        information TYPE syst-msgty VALUE 'I',
        warning     TYPE syst-msgty VALUE 'W',
        abend       TYPE syst-msgty VALUE 'A',
        error       TYPE syst-msgty VALUE 'E',
        unknown     TYPE syst-msgty VALUE 'X',
      END OF mcs_msg_type.

    METHODS constructor
      IMPORTING
        iv_p_pbf    TYPE abap_boolean
        iv_p_jv     TYPE abap_boolean
        iv_p_dbf    TYPE abap_boolean
        iv_p_daf    TYPE abap_boolean
        iv_p_dbf_cl TYPE abap_boolean
        iv_p_dbf_op TYPE abap_boolean
        iv_p_daf_cl TYPE abap_boolean
        iv_p_daf_op TYPE abap_boolean
        iv_p_block  TYPE abap_boolean OPTIONAL
        iv_p_split  TYPE abap_boolean OPTIONAL
        iv_p_deb_n  TYPE abap_boolean OPTIONAL.

    METHODS unblock
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS process
      CHANGING
        cs_data             TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_processed) TYPE abap_bool..

  PROTECTED SECTION.

    DATA: ms_data TYPE zcy_str_2a_pay_block,

          BEGIN OF ms_jv_applicability,
            blocked    TYPE abap_bool,
            split      TYPE abap_bool,
            debit_note TYPE abap_bool,
          END OF ms_jv_applicability,

          BEGIN OF ms_doc_clearing_state,
            cleared TYPE abap_bool,
            open    TYPE abap_bool,
          END OF ms_doc_clearing_state,

          BEGIN OF ms_processing_options,
            wait_for_filing   TYPE abap_bool,
            jv_applicability  LIKE ms_jv_applicability,
            due_before_filing LIKE ms_doc_clearing_state,
            due_after_filing  LIKE ms_doc_clearing_state,
          END OF ms_processing_options.

    METHODS update_db
      IMPORTING
        is_data           LIKE ms_data
      RETURNING
        VALUE(rv_updated) TYPE abap_bool.

  PRIVATE SECTION.

    DATA: ms_acc_data TYPE zpb_r2_mt_acc_data_1,

          mt_acc_data TYPE SORTED TABLE OF zpb_r2_mt_acc_data_1
              WITH NON-UNIQUE KEY bukrs belnr gjahr buzei
              WITH NON-UNIQUE SORTED KEY sec_key
                COMPONENTS bukrs belnr gjahr koart,

          BEGIN OF ms_tax_data,
            bukrs TYPE bset-bukrs,
            belnr TYPE bset-belnr,
            gjahr TYPE bset-gjahr,
            buzei TYPE bset-buzei,
            mwskz TYPE bset-mwskz,
            txgrp TYPE bset-txgrp,
            taxps TYPE bset-taxps,
            ktosl TYPE bset-ktosl,
            kschl TYPE bset-kschl,
            kbetr TYPE bset-kbetr,
            hwbas TYPE bset-hwbas,
            hwste TYPE bset-hwste,
            shkzg TYPE bset-shkzg,
            hkont TYPE bset-hkont,
          END OF ms_tax_data,

          mt_tax_data   LIKE SORTED TABLE OF ms_tax_data
            WITH UNIQUE KEY primary_key COMPONENTS bukrs belnr gjahr buzei
            WITH NON-UNIQUE SORTED KEY sec_key COMPONENTS bukrs belnr gjahr,

          mt_acc_data_k TYPE STANDARD TABLE OF zpb_r2_mt_acc_data_1
                          WITH EMPTY KEY,

          ms_bsik       TYPE zpb_r2_lt_bsik,
          lt_bsik       TYPE STANDARD TABLE OF zpb_r2_lt_bsik WITH EMPTY KEY,
          lt_tvarc      TYPE STANDARD TABLE OF tvarvc.

    TYPES:
      BEGIN OF msty_message,
        number TYPE bapiret2-number,
        id     TYPE bapiret2-id,
      END OF msty_message.


    CONSTANTS:
      BEGIN OF mcs_doc_status,
        unprocessed             TYPE zcy_t_2a_pay_blk-status VALUE '',
        blocked                 TYPE zcy_t_2a_pay_blk-status VALUE 'B',
        split                   TYPE zcy_t_2a_pay_blk-status VALUE 'S',
        released                TYPE zcy_t_2a_pay_blk-status VALUE 'R',
        ireleased               TYPE zcy_t_2a_pay_blk-status VALUE 'I',
        matched                 TYPE zcy_t_2a_pay_blk-status VALUE 'M',
        exempted                TYPE zcy_t_2a_pay_blk-status VALUE 'X',
        waiting_for_filing_date TYPE zcy_t_2a_pay_blk-status VALUE 'W',
        debit_note_posted       TYPE zcy_t_2a_pay_blk-status VALUE 'D',
      END OF mcs_doc_status,

      BEGIN OF mcs_vendor_block_type,
        exempted TYPE zcy_t_2a_pay_blk-vendor_block_type VALUE 'X',
        block    TYPE zcy_t_2a_pay_blk-vendor_block_type VALUE 'B',
        split    TYPE zcy_t_2a_pay_blk-vendor_block_type VALUE 'S',
      END OF mcs_vendor_block_type,

      BEGIN OF mcs_yes_no,
        yes TYPE zcy_t_2a_pay_blk-due_date_before_filing VALUE 'Y',
        no  TYPE zcy_t_2a_pay_blk-due_date_before_filing VALUE 'N',
      END OF mcs_yes_no,

      BEGIN OF mcs_acc_type,
        vendor   TYPE bseg-koart VALUE 'K',
        customer TYPE bseg-koart VALUE 'D',
        gl       TYPE bseg-koart VALUE 'S',
      END OF mcs_acc_type.

    DATA:
      lt_grc  TYPE STANDARD TABLE OF zgrc_control,
      ls_grc  TYPE zgrc_control,
      grc     TYPE i,
      CO_date TYPE sy-datum.

    DATA:
      mrt_matched    TYPE RANGE OF zpb_i_2a_pay_block_7-reconciliationsection,
      mrt_mismatched TYPE RANGE OF zpb_i_2a_pay_block_7-reconciliationsection,
      mrt_exempted   TYPE RANGE OF zpb_i_2a_pay_block_7-reconciliationsection,
      lv_mess        TYPE c LENGTH 200.

    DATA:
      mv_p_pbf    TYPE abap_boolean,
      mv_p_jv     TYPE abap_boolean,
      mv_p_dbf    TYPE abap_boolean,
      mv_p_daf    TYPE abap_boolean,
      mv_p_dbf_cl TYPE abap_boolean,
      mv_p_dbf_op TYPE abap_boolean,
      mv_p_daf_cl TYPE abap_boolean,
      mv_p_daf_op TYPE abap_boolean,
      mv_p_block  TYPE abap_boolean,
      mv_p_split  TYPE abap_boolean,
      mv_p_deb_n  TYPE abap_boolean.

    METHODS unblock_document
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS process_unprocessed
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS process_blocked
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS process_dbf
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS process_daf
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS release_document
      CHANGING
        cs_data            TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_released) TYPE abap_boolean.

    METHODS process_daf_open
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS process_dbf_open
      CHANGING
        cs_data TYPE zpb_i_2a_pay_block_7.

    METHODS block_open_document
      CHANGING
        cs_data           TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_blocked) TYPE abap_boolean.

    METHODS toggle_payment_block
      IMPORTING
        iv_doc_num        TYPE bkpf-belnr
        iv_comp_code      TYPE bkpf-bukrs
        iv_fis_year       TYPE bkpf-gjahr
      EXPORTING
        ev_message        TYPE string
      RETURNING
        VALUE(rv_toggled) TYPE abap_boolean.

    METHODS fill_reco_status_range.

    METHODS post_debit_note
      CHANGING
        cs_data          TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_posted) TYPE abap_boolean.

    METHODS post_debit_note2
      IMPORTING
        iv_doc_num       TYPE bkpf-belnr
        iv_comp_code     TYPE bkpf-bukrs
        iv_fis_year      TYPE bkpf-gjahr
        iv_vendor        TYPE bseg-lifnr
        iv_gst_amount    LIKE ms_data-fi_tax_value
      EXPORTING
        ev_comp_code     LIKE ms_data-debit_note_comp
        ev_doc_num       LIKE ms_data-debit_note_num
        ev_fis_year      LIKE ms_data-debit_note_year
        ev_message       LIKE ms_data-debit_note_comment
      CHANGING
        cs_data          TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_posted) TYPE abap_bool.

    METHODS perform_grc_check
      IMPORTING
        iv_vendor        TYPE lifnr
      EXPORTING
        ev_score         TYPE zcy_grc_score-gstr1_score
        ev_message       TYPE string
      RETURNING
        VALUE(rv_result) TYPE char1.

    METHODS get_log
      EXPORTING
        ev_date TYPE sydatum
        ev_time TYPE syuzeit
        ev_user TYPE string.

    METHODS post_jv
      CHANGING
        cs_data          TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_posted) TYPE abap_boolean.

    METHODS post_jv2
      IMPORTING
        iv_doc_num       TYPE bkpf-belnr
        iv_comp_code     TYPE bkpf-bukrs
        iv_fis_year      TYPE bkpf-gjahr
        iv_gst_amount    LIKE ms_data-fi_tax_value
      EXPORTING
        ev_comp_code     LIKE ms_data-jv_comp_code
        ev_doc_num       LIKE ms_data-jv_doc_num
        ev_fis_year      LIKE ms_data-jv_year
        ev_message       LIKE ms_data-jv_comment
      CHANGING
        cs_data          TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_posted) TYPE abap_bool.

    METHODS reverse_jv
      CHANGING
        cs_data            TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_reversed) TYPE abap_boolean.

    METHODS reverse_debit_note
      CHANGING
        cs_data            TYPE zpb_i_2a_pay_block_7
      RETURNING
        VALUE(rv_reversed) TYPE abap_boolean.

    METHODS reverse_debit_note2
      IMPORTING
        iv_doc_num         TYPE bkpf-belnr
        iv_comp_code       TYPE bkpf-bukrs
        iv_fis_year        TYPE bkpf-gjahr
      EXPORTING
        ev_comp_code       LIKE ms_data-debit_note_rev_comp
        ev_doc_num         LIKE ms_data-debit_note_rev_num
        ev_fis_year        LIKE ms_data-debit_note_rev_year
        ev_message         LIKE ms_data-debit_note_rev_comment
      RETURNING
        VALUE(rv_reversed) TYPE abap_bool.

    METHODS is_document_open
      IMPORTING
        iv_doc_num     TYPE bkpf-belnr
        iv_comp_code   TYPE bkpf-bukrs
        iv_fis_year    TYPE bkpf-gjahr
      RETURNING
        VALUE(rv_open) TYPE abap_boolean.

    METHODS reverse_document
      IMPORTING
        iv_doc_num         TYPE bkpf-belnr
        iv_comp_code       TYPE bkpf-bukrs
        iv_fis_year        TYPE bkpf-gjahr
      EXPORTING
        ev_reversed_doc    TYPE bkpf-belnr
        ev_fis_year        TYPE bkpf-gjahr
        ev_message         TYPE string
      RETURNING
        VALUE(rv_reversed) TYPE abap_boolean.

    METHODS reverse_document2
      IMPORTING
        iv_doc_num         TYPE bkpf-belnr
        iv_comp_code       TYPE bkpf-bukrs
        iv_fis_year        TYPE bkpf-gjahr
      EXPORTING
        ev_comp_code       TYPE bkpf-bukrs
        ev_doc_num         TYPE bkpf-belnr
        ev_fis_year        TYPE bkpf-gjahr
        ev_message         LIKE ms_data-release_comment
      RETURNING
        VALUE(rv_reversed) TYPE abap_bool.

    METHODS check_document_posted
      IMPORTING
        iv_doc_num       TYPE bkpf-belnr
        iv_comp_code     TYPE bkpf-bukrs
        iv_fis_year      TYPE bkpf-gjahr
      RETURNING
        VALUE(rv_posted) TYPE abap_boolean.

    METHODS get_fiscal_year
      IMPORTING
        iv_bukrs        TYPE bukrs
        iv_budat        TYPE budat
      RETURNING
        VALUE(rv_gjahr) TYPE gjahr.

    METHODS get_fiscal_year2
      IMPORTING
        iv_comp_code          TYPE bkpf-bukrs
        iv_date               TYPE syst-datlo DEFAULT sy-datlo
      RETURNING
        VALUE(rv_fiscal_year) TYPE bkpf-gjahr.

    METHODS process_bapi_return
      IMPORTING
        is_success_msg    TYPE msty_message
        it_return         TYPE bapiret2_t
      EXPORTING
        es_return         TYPE bapiret2
      RETURNING
        VALUE(rv_success) TYPE abap_boolean.

    METHODS is_document_in_bsik
      IMPORTING
        iv_bukrs         TYPE bukrs
        iv_belnr         TYPE belnr_d
        iv_gjahr         TYPE gjahr
      RETURNING
        VALUE(rv_exists) TYPE abap_boolean.

ENDCLASS.

CLASS zcl_pb_processor_final IMPLEMENTATION.

  METHOD constructor.

    mv_p_pbf    = iv_p_pbf.
    mv_p_jv     = iv_p_jv.
    mv_p_dbf    = iv_p_dbf.
    mv_p_daf    = iv_p_daf.
    mv_p_dbf_cl = iv_p_dbf_cl.
    mv_p_dbf_op = iv_p_dbf_op.
    mv_p_daf_cl = iv_p_daf_cl.
    mv_p_daf_op = iv_p_daf_op.

    mv_p_block = iv_p_block.
    mv_p_split = iv_p_split.
    mv_p_deb_n = iv_p_deb_n.

    fill_reco_status_range( ).

  ENDMETHOD.


  METHOD process.

    CLEAR ms_processing_options.
    ms_processing_options = VALUE #( wait_for_filing   = xsdbool( cs_data-p_pbf = abap_false )
                                     jv_applicability  = COND #( WHEN cs_data-p_jv = abap_true
                                                                 THEN VALUE #( blocked    = cs_data-p_block
                                                                               split      = cs_data-p_split
                                                                               debit_note = cs_data-p_deb_n ) )
                                     due_before_filing = COND #( WHEN cs_data-p_dbf = abap_true
                                                                 THEN VALUE #( cleared = cs_data-p_dbf_cl
                                                                               open    = cs_data-p_dbf_op ) )
                                     due_after_filing  = COND #( WHEN cs_data-p_daf = abap_true
                                                                 THEN VALUE #( cleared = cs_data-p_daf_cl
                                                                               open    = cs_data-p_daf_op ) ) ).

    SELECT SINGLE * FROM tvarvc INTO @DATA(lc_date) WHERE name = 'ZCYG_CUTOFF_DATE'.
    IF sy-subrc = 0.
      co_date = lc_date-low.
    ENDIF.

    IF cs_data-Documenttype <> 'CRN' AND cs_data-Custom2 GE co_date.

      DATA lv_user TYPE string.

      get_log( IMPORTING ev_date = cs_data-LastCheckedOn ev_time = cs_data-LastCheckedAt ev_user = lv_user ).
      cs_data-LastCheckedBy = lv_user.

      IF to_upper( cs_data-reconciliationsection ) NOT IN mrt_matched[] AND to_upper( cs_data-reconciliationsection ) NOT IN mrt_mismatched[].
        cs_data-message = 'Reco Status uncategorized, Cannot process'. "TEXT-010.
      ENDIF.

      CASE cs_data-status.
        WHEN mcs_doc_status-unprocessed OR mcs_doc_status-waiting_for_filing_date OR mcs_doc_status-exempted.

          process_unprocessed( CHANGING cs_data = cs_data ).

        WHEN mcs_doc_status-blocked OR mcs_doc_status-split OR mcs_doc_status-debit_note_posted.
          process_blocked( CHANGING cs_data = cs_data ).

        WHEN mcs_doc_status-matched OR mcs_doc_status-released.

        WHEN OTHERS.

      ENDCASE.

*----------------Check-1----------------------------------------------------------
*      derive_status_icon( CHANGING cs_data = <ls_data> ).
*----------------Check-1----------------------------------------------------------

      DATA: ls_data TYPE zcy_str_2a_pay_block.
      ls_data = CORRESPONDING #( cs_data   MAPPING  rec_date        = RecDate
                                                    rec_time        = RecTime
                                                    reco_stat       = Recostat
                                                    status_desc     = Statusdesc
                                                    vendor_name     = VendorName
                                                    block_type_desc = BlockTypeDesc ).

      rv_processed = update_db( EXPORTING is_data = ls_data ).

*----------------Check-2-Need to Print----------------------------------------------------------
      IF sy-subrc = 4.
        MESSAGE TEXT-006 TYPE mcs_msg_type-success   "006=Please select suitable documents for processing
          DISPLAY LIKE mcs_msg_type-error.
      ENDIF.
*----------------Check-2-Need to Print----------------------------------------------------------

    ENDIF.

  ENDMETHOD.


  METHOD process_blocked.

    " Here Release might mean:
    " 1. Unblock in case of B or S
    " 2. Reversal in case of JV(with B or S) and D

    " What if vendor is exempted after doc is blocked/split?
    IF cs_data-vendorblocktype = mcs_doc_status-exempted.
      " Force release the document irrespective of current status?
      DATA(lv_released) = release_document( CHANGING cs_data = cs_data ).
    ELSE.
      " Document follows the normal 'blocked/split/dn posted' flow
      IF to_upper( cs_data-reconciliationsection ) IN mrt_matched[].
        lv_released = release_document( CHANGING cs_data = cs_data ).
        READ TABLE lt_bsik INTO DATA(ls_bsik) WITH KEY bukrs = cs_data-custom9 belnr = cs_data-custom1 gjahr = cs_data-custom4
         BINARY SEARCH.
        IF sy-subrc = 0.
        ELSE.
          reverse_debit_note2(
          EXPORTING
            iv_doc_num   = |{ cs_data-debitnotenum ALPHA = IN }|
            iv_comp_code = cs_data-debitnotecomp
            iv_fis_year  = cs_data-debitnoteyear
          IMPORTING
            ev_comp_code = cs_data-debitnoterevcomp
            ev_doc_num   = cs_data-debitnoterevnum
            ev_fis_year  = cs_data-debitnoterevyear
            ev_message   = cs_data-debitnoterevcomment
          RECEIVING
            rv_reversed  = DATA(rv_released) ).

          IF rv_released = abap_true.
            get_log(
              IMPORTING
                ev_date = cs_data-debitnotereversedon
                ev_time = cs_data-debitnotereversedat
                ev_user = DATA(lv_reversedby) ).

            cs_data-debitnotereversedby = lv_reversedby.

          ELSE.
            cs_data-releasecomment = cs_data-debitnoterevcomment.
          ENDIF.
*          CS_DATA-SPLIT_YEAR = CS_DATA-CUSTOM4.

*         no further action
        ENDIF.
      ENDIF.

    ENDIF.
*    IF ok = '&UNBLOCK1' OR ok = '&BLOCK'.
*      lv_released = release_document( CHANGING cs_data = cs_data ).
*      READ TABLE lt_bsik INTO ls_bsik WITH KEY bukrs = cs_data-custom9  belnr = cs_data-custom1 gjahr = cs_data-custom4
*      BINARY SEARCH.
*      IF sy-subrc = 0.
*
*      ELSE.
*        reverse_debit_note(
*        EXPORTING
*          iv_doc_num   = |{ cs_data-debit_note_num ALPHA = IN }|
*          iv_comp_code = cs_data-debit_note_comp
*          iv_fis_year  = cs_data-debit_note_year
*        IMPORTING
*          ev_comp_code = cs_data-debit_note_rev_comp
*          ev_doc_num   = cs_data-debit_note_rev_num
*          ev_fis_year  = cs_data-debit_note_rev_year
*          ev_message   = cs_data-debit_note_rev_comment
*        RECEIVING
*          rv_reversed  = rv_released ).
*
*        IF rv_released = abap_true.
*          get_log(
*            IMPORTING
*              ev_date = cs_data-debit_note_reversed_on
*              ev_time = cs_data-debit_note_reversed_at
*              ev_user = cs_data-debit_note_reversed_by ).
*        ELSE.
*          cs_data-release_comment = cs_data-debit_note_rev_comment.
*        ENDIF.
*        cs_data-split_year = cs_data-custom4.
*
**         no further action
*      ENDIF.
*    ENDIF.
*
    IF lv_released = abap_true.
      " placeholder
    ENDIF.


  ENDMETHOD.


  METHOD is_document_in_bsik.

    rv_exists = abap_false.

    SELECT SINGLE belnr
      FROM bsak
      WHERE bukrs = @iv_bukrs
        AND belnr = @iv_belnr
        AND gjahr = @iv_gjahr
        AND zlspr <> 'Y'
      INTO @DATA(lv_belnr).

    IF sy-subrc = 0.
      rv_exists = abap_true.
    ENDIF.

  ENDMETHOD.


  METHOD process_daf.

    IF cs_data-clearingdate IS NOT INITIAL.
      " Cleared
      IF ms_processing_options-due_after_filing-cleared = abap_true.
*        PROCESS_DAF_CLEARED( CHANGING CS_DATA = CS_DATA ).
        process_daf_open( CHANGING cs_data = cs_data ).
      ENDIF.
    ELSE.
      " Open
      IF ms_processing_options-due_after_filing-open = abap_true.
        process_daf_open( CHANGING cs_data = cs_data ).
      ENDIF.
    ENDIF.


  ENDMETHOD.


  METHOD process_dbf.

    IF cs_data-clearingdate IS NOT INITIAL.
      IF ms_processing_options-due_before_filing-cleared = abap_true.
        process_dbf_open( CHANGING cs_data = cs_data ).
      ENDIF.
    ELSE.
      IF ms_processing_options-due_before_filing-open = abap_true.
        process_dbf_open( CHANGING cs_data = cs_data ).
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD process_unprocessed.

    IF cs_data-status = mcs_doc_status-exempted.

      IF cs_data-VendorBlockType <> mcs_vendor_block_type-exempted.
        cs_data-status = mcs_doc_status-unprocessed.
      ELSE.
        RETURN.
      ENDIF.

    ENDIF.

    IF cs_data-DueDateBeforeFiling = mcs_yes_no-yes.
      IF cs_data-p_dbf = abap_true.
        process_dbf( CHANGING cs_data = cs_data ).
      ENDIF.
    ELSE.
      IF cs_data-p_daf = abap_true.
        process_daf( CHANGING cs_data = cs_data ).
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD release_document.

    CLEAR rv_released.

    CASE cs_data-status.

      WHEN mcs_doc_status-blocked.

        toggle_payment_block(
          EXPORTING
            iv_doc_num   = |{ CONV bkpf-belnr( cs_data-custom1 ) ALPHA = IN }|
            iv_comp_code = CONV #( cs_data-custom9 )
            iv_fis_year  = CONV #( cs_data-custom4 )
          IMPORTING
            ev_message   = DATA(lv_message)
          RECEIVING
            rv_toggled   = rv_released ).

        cs_data-ReleaseComment = lv_message.

      WHEN mcs_doc_status-split.

        toggle_payment_block(
          EXPORTING
            iv_doc_num   = |{ cs_data-DebitNoteNum ALPHA = IN }|
            iv_comp_code = cs_data-SplitCompCode
            iv_fis_year  = cs_data-splityear
          IMPORTING
            ev_message   = lv_message
          RECEIVING
            rv_toggled   = rv_released ).

        cs_data-ReleaseComment = lv_message.

      WHEN mcs_doc_status-debit_note_posted.

        toggle_payment_block(
          EXPORTING
            iv_doc_num   = |{ cs_data-DebitNoteNum ALPHA = IN }|
            iv_comp_code = cs_data-debitnotecomp
            iv_fis_year  = cs_data-debitnoteyear
          IMPORTING
            ev_message   = lv_message
          RECEIVING
            rv_toggled   = rv_released ).

        cs_data-ReleaseComment = lv_message.

    ENDCASE.

    IF rv_released = abap_true.

      cs_data-status  = mcs_doc_status-released.
      cs_data-message = TEXT-014.

    ELSE.

      cs_data-message = TEXT-013.

    ENDIF.

  ENDMETHOD.


  METHOD fill_reco_status_range.

    CLEAR: mrt_matched[], mrt_mismatched[], mrt_exempted[].

    " #ToDo
    " Fill status ranges
    SELECT 'I' AS sign, 'EQ' AS option, reco_status AS low FROM zcy_t_2a_recstat WHERE category = 'M'
      INTO TABLE @mrt_matched[].

    LOOP AT mrt_matched ASSIGNING FIELD-SYMBOL(<ls_matched>).
      <ls_matched>-low = to_upper( <ls_matched>-low ).
    ENDLOOP.

    SELECT 'I' AS sign, 'EQ' AS option, reco_status AS low FROM zcy_t_2a_recstat WHERE category = 'B'
      INTO TABLE @mrt_mismatched[].

    LOOP AT mrt_mismatched ASSIGNING FIELD-SYMBOL(<ls_mismatched>).
      <ls_mismatched>-low = to_upper( <ls_mismatched>-low ).
    ENDLOOP.

    SELECT 'I' AS sign, 'EQ' AS option, reco_status AS low FROM zcy_t_2a_recstat WHERE category = 'X'
      INTO TABLE @mrt_exempted[].

    LOOP AT mrt_exempted ASSIGNING FIELD-SYMBOL(<ls_exempted>).
      <ls_exempted>-low = to_upper( <ls_exempted>-low ).
    ENDLOOP.

    IF mrt_matched[] IS INITIAL OR mrt_mismatched[] IS INITIAL.

*     RAISE EXCEPTION TYPE LCX_GENERIC
*       MESSAGE ID '00' TYPE MCS_MSG_TYPE-ERROR NUMBER '001'
*       WITH TEXT-009.

      RETURN.

    ENDIF.

  ENDMETHOD.


  METHOD process_dbf_open.

    IF sy-datum >= cs_data-expectedfilingdate OR ms_processing_options-wait_for_filing = abap_false OR cs_data-qblock IS NOT INITIAL.

      IF to_upper( cs_data-reconciliationsection ) IN mrt_mismatched[].
        DATA(lv_blocked) = block_open_document( CHANGING cs_data = cs_data ).
      ENDIF.

      IF to_upper( cs_data-reconciliationsection ) IN mrt_matched[].
        cs_data-status = mcs_doc_status-matched.
      ENDIF.

    ELSE.

      IF to_upper( cs_data-reconciliationsection ) IN mrt_matched[].

        cs_data-status = mcs_doc_status-matched.

      ELSE.

        DATA: due_check TYPE sy-datum.
        due_check = sy-datum + 1.

        IF cs_data-grccheckapplicable = mcs_yes_no-yes.

          DATA: lv_grc_score   TYPE zcy_grc_score-gstr1_score,
                lv_grc_message TYPE string.

          perform_grc_check( EXPORTING iv_vendor  = cs_data-vendor
                             IMPORTING ev_score   = lv_grc_score
                                       ev_message = lv_grc_message
                             RECEIVING rv_result  = cs_data-grccheckresult ).

          cs_data-GrcScore        = lv_grc_score.
          cs_data-GrcCheckComment = lv_grc_message.

          get_log( IMPORTING ev_date = cs_data-grccheckedon
                             ev_time = cs_data-grccheckedat
                             ev_user = DATA(lv_user) ).

          cs_data-grccheckedby = lv_user.
          grc = cs_data-grcscore.
          CLEAR ls_grc.

          READ TABLE lt_grc INTO ls_grc INDEX 1.

          IF ( grc <= ls_grc-grc_block1 OR grc IS INITIAL ) AND cs_data-mindk IS INITIAL.

            lv_blocked = block_open_document( CHANGING cs_data = cs_data ).

          ELSEIF grc > ls_grc-grc_block2 AND grc <= ls_grc-grc_block3.

            cs_data-status = mcs_doc_status-waiting_for_filing_date.

          ELSE.

            cs_data-status = mcs_doc_status-waiting_for_filing_date.

          ENDIF.

        ELSE.

          cs_data-status = mcs_doc_status-waiting_for_filing_date.

        ENDIF.

      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD process_daf_open.

    " Filing date has passed?
    CLEAR:ls_grc.
    IF cs_data-mindk = '6' OR cs_data-mindk  = '7'.
      cs_data-qblock = 'X'.
    ENDIF.
    READ TABLE lt_grc INTO ls_grc INDEX 1.
    IF sy-datlo GE cs_data-expectedfilingdate
*      OR CS_DATA-FILINGDATE IS NOT INITIAL        " already filed
      OR ms_processing_options-wait_for_filing = abap_false OR cs_data-qblock = 'X'.."OR CS_DATA-GRC_SCORE LE LS_GRC-GRC_BLOCK1 OR CS_DATA-QBLOCK = 'X'..
      IF to_upper( cs_data-reconciliationsection ) IN mrt_mismatched[].
        DATA(lv_blocked) = block_open_document( CHANGING cs_data = cs_data ).
      ENDIF.
      IF to_upper( cs_data-reconciliationsection ) IN mrt_matched[].
        cs_data-status = mcs_doc_status-matched.
      ENDIF.
    ELSE.
      " Filing date is in the future
      cs_data-status = mcs_doc_status-waiting_for_filing_date.
    ENDIF.

  ENDMETHOD.


  METHOD block_open_document.

    CLEAR rv_blocked.

    DATA lv_jv_applicable TYPE abap_boolean.

    CASE cs_data-vendorblocktype.

      WHEN mcs_vendor_block_type-exempted.

        cs_data-status = mcs_doc_status-exempted.

      WHEN mcs_vendor_block_type-block.

        toggle_payment_block( EXPORTING iv_doc_num   = |{ CONV bkpf-belnr( cs_data-custom1 ) ALPHA = IN }|
                                        iv_comp_code = CONV #( cs_data-custom9 )
                                        iv_fis_year  = CONV #( cs_data-custom4 )
                              IMPORTING ev_message   = DATA(lv_block_message)
                              RECEIVING rv_toggled   = rv_blocked ).

        cs_data-blockcomment = lv_block_message.

        IF rv_blocked = abap_true.

          cs_data-status = mcs_doc_status-blocked.

          get_log( IMPORTING ev_date = cs_data-blockedon
                             ev_time = cs_data-blockedat
                             ev_user = DATA(lv_user) ).

          cs_data-blockedby = lv_user.
          cs_data-message  = 'Action Completed'.  "Text-014

          IF ms_processing_options-jv_applicability-blocked = abap_true.

            lv_jv_applicable = abap_true.

          ENDIF.

        ELSE.

          cs_data-message = 'Processing Error. Check comment.'.  "Text-013

        ENDIF.

      WHEN mcs_vendor_block_type-split.

*        post_debit_note( CHANGING cs_data = cs_data
*                         RECEIVING rv_posted = DATA(lv_dn_posted) ).

        post_debit_note2(
         EXPORTING
           iv_comp_code  = CONV #( cs_data-custom9 )
           iv_doc_num    = |{ CONV bkpf-belnr( cs_data-custom1 ) ALPHA = IN }|
           iv_fis_year   = CONV #( cs_data-custom4 )
           iv_vendor     = cs_data-vendor
           iv_gst_amount = CONV #( cs_data-fitaxvalue )
         IMPORTING
           ev_comp_code = cs_data-debitnotecomp
           ev_doc_num   = cs_data-debitnotenum
           ev_fis_year  = cs_data-debitnoteyear
           ev_message   = cs_data-debitnotecomment
         CHANGING cs_data = cs_data
         RECEIVING
           rv_posted    = DATA(lv_dn_posted) ).

        IF lv_dn_posted = abap_true.

          cs_data-status = mcs_doc_status-debit_note_posted.

          get_log( IMPORTING ev_date = cs_data-debitnotepostedon
                             ev_time = cs_data-debitnotepostedat
                             ev_user = DATA(lv_debit) ).

          cs_data-debitnotepostedby = lv_debit.
          cs_data-message = 'Action Completed'.  "Text-014

        ENDIF.

      WHEN OTHERS.

        cs_data-message = 'Invalid Vendor block type'.  "Text-008

    ENDCASE.

    IF lv_jv_applicable = abap_true.

*      post_jv( CHANGING cs_data = cs_data
*               RECEIVING rv_posted = DATA(lv_jv_posted) ).

      post_jv2( EXPORTING iv_comp_code  = CONV #( cs_data-custom9 )
                          iv_doc_num    = |{ CONV bkpf-belnr( cs_data-custom1 ) ALPHA = IN }|
                          iv_fis_year   = CONV #( cs_data-custom4 )
                          iv_gst_amount = cs_data-fitaxvalue
                IMPORTING ev_comp_code  = cs_data-jvcompcode
                          ev_doc_num    = cs_data-jvdocnum
                          ev_fis_year   = cs_data-jvyear
                          ev_message    = cs_data-jvcomment
                CHANGING  cs_data       = cs_data
                RECEIVING rv_posted     = DATA(lv_jv_posted) ).


      IF lv_jv_posted = abap_true.

        get_log( IMPORTING ev_date = cs_data-jvpostedon
                           ev_time = cs_data-jvpostedat
                           ev_user = DATA(lv_post) ).

        cs_data-jvpostedby = lv_post.

        IF cs_data-message <> 'Processing Error. Check comment.'.  "Text-013
          cs_data-message = 'Action Completed'.  "Text-014
        ENDIF.

      ELSE.

        cs_data-message = 'Processing Error. Check comment.'.  "Text-013

      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD check_document_posted.

    rv_posted = abap_false.

    DO 10 TIMES.

      CALL FUNCTION 'ENQUE_SLEEP'
        EXPORTING
          seconds        = 1
        EXCEPTIONS
          system_failure = 1
          OTHERS         = 2.

      SELECT SINGLE @abap_true
        FROM bkpf
        WHERE bukrs = @iv_comp_code
          AND belnr = @iv_doc_num
          AND gjahr = @iv_fis_year
        INTO @rv_posted.

      IF rv_posted = abap_true.
        RETURN.
      ENDIF.

    ENDDO.

  ENDMETHOD.


  METHOD get_fiscal_year.

    CLEAR rv_gjahr.

    CALL FUNCTION 'FI_PERIOD_DETERMINE'
      EXPORTING
        i_budat        = iv_budat
        i_bukrs        = iv_bukrs
      IMPORTING
        e_gjahr        = rv_gjahr
      EXCEPTIONS
        fiscal_year    = 1
        period         = 2
        period_version = 3
        posting_period = 4
        special_period = 5
        version        = 6
        posting_date   = 7
        OTHERS         = 8.

    IF sy-subrc <> 0.
      CLEAR rv_gjahr.
    ENDIF.

  ENDMETHOD.


  METHOD is_document_open.

    rv_open = abap_false.

    SELECT SINGLE @abap_true
      FROM bseg
      WHERE bukrs = @iv_comp_code
        AND belnr = @iv_doc_num
        AND gjahr = @iv_fis_year
        AND augbl = @space
      INTO @rv_open.

  ENDMETHOD.


  METHOD toggle_payment_block.

    CONSTANTS: lc_pay_block       TYPE bseg-zlspr VALUE 'Q',
               lc_pay_block_fname TYPE accchg-fdname VALUE 'ZLSPR'.

    DATA: lt_accchg    TYPE STANDARD TABLE OF accchg,
          lv_new_block TYPE bseg-zlspr.

    CLEAR: ev_message, rv_toggled.

    " Read the accounting document line items
    SELECT * FROM bseg WHERE bukrs = @iv_comp_code
                       AND belnr = @iv_doc_num
                       AND gjahr = @iv_fis_year
      INTO TABLE @DATA(lt_acc_items).

    IF lt_acc_items IS INITIAL.

      ev_message = |{ iv_comp_code }-{ iv_doc_num }-{ iv_fis_year } does not exist|.

      RETURN.

    ENDIF.

    " Prefer the special G/L item, as in the legacy method
    READ TABLE lt_acc_items INTO DATA(ls_acc_item) WITH KEY umskz = 'A'.

    " Otherwise select the vendor credit item
    IF sy-subrc <> 0.

      READ TABLE lt_acc_items INTO ls_acc_item WITH KEY koart = 'K' shkzg = 'H'.

    ENDIF.

    IF ls_acc_item IS INITIAL.

      ev_message = |{ iv_comp_code }-{ iv_doc_num }-{ iv_fis_year } - Cannot find suitable item for payment block|.

      RETURN.

    ENDIF.

    " Toggle payment block Q
    IF ls_acc_item-zlspr = lc_pay_block.
      CLEAR lv_new_block.
    ELSE.
      lv_new_block = lc_pay_block.
    ENDIF.

    lt_accchg = VALUE #( ( fdname = 'ZLSPR'
                           oldval = ls_acc_item-zlspr
                           newval = lv_new_block ) ).

    CALL FUNCTION 'FI_DOCUMENT_CHANGE'
      EXPORTING
        i_obzei              = ls_acc_item-buzei
        i_bukrs              = ls_acc_item-bukrs
        i_belnr              = ls_acc_item-belnr
        i_gjahr              = ls_acc_item-gjahr
      TABLES
        t_accchg             = lt_accchg
      EXCEPTIONS
        no_reference         = 1
        no_document          = 2
        many_documents       = 3
        wrong_input          = 4
        overwrite_creditcard = 5
        error_message        = 6
        OTHERS               = 7.

    IF sy-subrc <> 0.

      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
              INTO ev_message.

      RETURN.

    ENDIF.

    rv_toggled = abap_true.

  ENDMETHOD.


  METHOD post_debit_note.


  ENDMETHOD.


  METHOD process_bapi_return.

    CLEAR:
      es_return,
      rv_success.

    IF it_return IS NOT INITIAL.
      TRY.
          es_return = it_return[ type   = mcs_msg_type-success
                                 id     = is_success_msg-id
                                 number = is_success_msg-number ].

          rv_success = abap_true.
        CATCH cx_sy_itab_line_not_found ##no_handler.
          TRY.
              es_return = it_return[ type = mcs_msg_type-abend ].
            CATCH cx_sy_itab_line_not_found ##no_handler.
              TRY.
                  es_return = it_return[ type = mcs_msg_type-error ].

                  " In case of more than 1 error message read the last message
                  DATA(lt_return) = it_return[].
                  DELETE lt_return WHERE type <> mcs_msg_type-error.

                  IF lines( lt_return ) > 1.
                    " last line of the table
                    es_return =
                      VALUE #( lt_return[ lines( lt_return ) ] OPTIONAL ).
                  ENDIF.
                CATCH cx_sy_itab_line_not_found ##no_handler.
                  TRY.
                      es_return = it_return[ type = mcs_msg_type-unknown ].
                    CATCH cx_sy_itab_line_not_found ##no_handler.
                      es_return = it_return[ 1 ].
                  ENDTRY.
              ENDTRY.
          ENDTRY.
      ENDTRY.
    ENDIF.

  ENDMETHOD.


  METHOD reverse_debit_note.

    CLEAR rv_reversed.

    DATA lv_message TYPE string.

    IF is_document_open(
         iv_doc_num   = CONV #( cs_data-debitnotenum )
         iv_comp_code = CONV #( cs_data-debitnotecomp )
         iv_fis_year  = CONV #( cs_data-debitnoteyear ) ).

      rv_reversed = reverse_document(
        EXPORTING
          iv_doc_num   = CONV #( cs_data-debitnotenum )
          iv_comp_code = CONV #( cs_data-debitnotecomp )
          iv_fis_year  = CONV #( cs_data-debitnoteyear )
        IMPORTING
          ev_reversed_doc = cs_data-debitnoterevnum
          ev_fis_year     = cs_data-debitnoterevyear
          ev_message      = lv_message ).

      cs_data-debitnoterevcomment = lv_message.

      IF rv_reversed = abap_true.
        cs_data-debitnoterevcomp = cs_data-debitnotecomp.
      ENDIF.

    ELSE.

      cs_data-debitnoterevcomment =
        'Document is cleared; reversal is not possible'.

    ENDIF.

  ENDMETHOD.


  METHOD reverse_document.

    CONSTANTS lc_rev_reason TYPE bapiacrev-reason_rev VALUE '04'.

    DATA:
      lv_post_date TYPE bkpf-budat,
      lt_bdc_msg   TYPE STANDARD TABLE OF bdcmsgcoll,
      lt_return    TYPE STANDARD TABLE OF bapiret2.

    CLEAR:
      ev_reversed_doc,
      ev_fis_year,
      ev_message,
      rv_reversed,
      lv_post_date,
      lt_bdc_msg,
      lt_return.

    " Reverse the FI document using the existing FB08 wrapper
    CALL FUNCTION 'ZCY_FI_FM_CALL_FB08'
      EXPORTING
        i_bukrs       = iv_comp_code
        i_belnr       = iv_doc_num
        i_gjahr       = iv_fis_year
        i_stgrd       = lc_rev_reason
        i_no_auth     = abap_true
      IMPORTING
        e_budat       = lv_post_date
      TABLES
        et_messtab    = lt_bdc_msg
      EXCEPTIONS
        not_possible  = 1
        error_message = 2
        OTHERS        = 3.

    IF sy-subrc <> 0.

      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
              INTO ev_message.

      RETURN.

    ENDIF.

    IF lt_bdc_msg IS INITIAL.
      ev_message = 'FB08 returned no messages; reversal not confirmed'.
      RETURN.
    ENDIF.

    CALL FUNCTION 'CONVERT_BDCMSGCOLL_TO_BAPIRET2'
      TABLES
        imt_bdcmsgcoll = lt_bdc_msg
        ext_return     = lt_return.

    " Check whether the reversal success message is present
    READ TABLE lt_return INTO DATA(ls_success)
      WITH KEY type   = 'S'
               id     = '312'
               number = 'F5'.

    IF sy-subrc = 0.

      rv_reversed = abap_true.

      ev_reversed_doc = CONV bkpf-belnr(
        |{ CONV belnr_d( ls_success-message_v1 ) ALPHA = IN }|
      ).

      ev_fis_year = get_fiscal_year(
        iv_bukrs = iv_comp_code
        iv_budat = lv_post_date ).

    ELSE.

      READ TABLE lt_return INTO DATA(ls_error)
        WITH KEY type = 'E'.

      IF sy-subrc = 0.
        ev_message = ls_error-message.
      ELSE.
        ev_message = 'Reversal success could not be confirmed'.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD reverse_jv.

    rv_reversed = abap_false.

    CLEAR:
      cs_data-jvrevdocnum,
      cs_data-jvrevyear,
      cs_data-jvrevcomment.

    " Check whether the JV document exists and is open
    IF cs_data-jvdocnum IS INITIAL.

      cs_data-jvrevcomment = 'JV document number is missing'.
      RETURN.

    ENDIF.

    IF is_document_open(
         iv_doc_num   = CONV #( cs_data-jvdocnum )
         iv_comp_code = cs_data-jvcompcode
         iv_fis_year  = cs_data-jvyear ) = abap_true.

      " Open document: reverse using FB08
      reverse_document(
        EXPORTING
          iv_doc_num   = CONV #( cs_data-jvdocnum )
          iv_comp_code = cs_data-jvcompcode
          iv_fis_year  = cs_data-jvyear
        IMPORTING
          ev_reversed_doc = cs_data-jvrevdocnum
          ev_fis_year     = cs_data-jvrevyear
          ev_message      = DATA(lv_message)
        RECEIVING
          rv_reversed     = rv_reversed ).

      cs_data-jvrevcomment = lv_message.

      IF rv_reversed = abap_true.
        cs_data-jvrevcompcode = cs_data-jvcompcode.
      ENDIF.

    ELSE.

      " Cleared JV reversal is not implemented in the legacy source
      cs_data-jvrevcomment =
        'JV is cleared; reversal is not implemented'.

    ENDIF.

  ENDMETHOD.


  METHOD post_jv.



  ENDMETHOD.


  METHOD get_log.

    CLEAR:
      ev_date,
      ev_time,
      ev_user.

    GET TIME.

    ev_date = sy-datlo.
    ev_time = sy-timlo.

    SELECT SINGLE name_text
      FROM v_usr_name
      WHERE bname = @sy-uname
      INTO @DATA(lv_name).

    ev_user = COND string(
      WHEN lv_name IS NOT INITIAL
      THEN |{ sy-uname } - { lv_name }|
      ELSE sy-uname
    ).

  ENDMETHOD.


  METHOD perform_grc_check.

    CLEAR:
      ev_score,
      ev_message,
      rv_result.
    DATA: grc1 TYPE i.
    DATA: grc3 TYPE i.
    SELECT SINGLE * FROM zcy_grc_score INTO @DATA(lt_grc) WHERE vendor = @iv_vendor.
    IF sy-subrc = 0.
      grc1 = lt_grc-gstr1_score.
      grc3 = lt_grc-gstr3b_score.
      IF grc1 LE grc3.
        ev_score = lt_grc-gstr1_score.
      ELSE.
        ev_score = lt_grc-gstr3b_score.
      ENDIF.

    ELSE.
      rv_result = 'F'.
    ENDIF.
    CLEAR:grc1,grc3.
    ev_message = TEXT-012.


  ENDMETHOD.


  METHOD unblock_document.

    DATA:
      lv_document_open     TYPE abap_boolean,
      lv_debit_note_posted TYPE abap_boolean,
      lv_jv_posted         TYPE abap_boolean,
      lv_user              TYPE string.

    CLEAR:
      cs_data-message,
      lv_document_open,
      lv_debit_note_posted,
      lv_jv_posted.

    "------------------------------------------------------------
    " Process only documents having status I (IRELEASED)
    "------------------------------------------------------------
    IF cs_data-status <> mcs_doc_status-ireleased.

      cs_data-message = 'Document status is not IRELEASED'.
      RETURN.

    ENDIF.

    "------------------------------------------------------------
    " Legacy PROCESS_DOCUMENTS_BLK1:
    " Check whether the debit-note document is still open
    "------------------------------------------------------------
    lv_document_open = is_document_open(
      iv_doc_num   = |{ CONV bkpf-belnr( cs_data-debitnotenum ) ALPHA = IN }|
      iv_comp_code = cs_data-debitnotecomp
      iv_fis_year  = cs_data-debitnoteyear
    ).

    IF lv_document_open = abap_true.

      " The debit note is open.
      " Continue through the existing blocked-document logic.
      process_blocked(
        CHANGING
          cs_data = cs_data
      ).

      RETURN.

    ENDIF.

    "------------------------------------------------------------
    " Debit note is cleared:
    " Port of legacy BLOCK_CLEARED_DOCUMENT_BK
    "------------------------------------------------------------
    CASE cs_data-vendorblocktype.

      WHEN mcs_vendor_block_type-exempted.

        cs_data-status  = mcs_doc_status-exempted.
        cs_data-message = 'Vendor is exempted from payment block'.

      WHEN mcs_vendor_block_type-block
        OR mcs_vendor_block_type-split.

        " Post the debit note using the existing processor method
        post_debit_note(
          CHANGING
            cs_data = cs_data
          RECEIVING
            rv_posted = lv_debit_note_posted
        ).

        IF lv_debit_note_posted = abap_true.

          cs_data-status = mcs_doc_status-debit_note_posted.

          get_log(
            IMPORTING
              ev_date = cs_data-debitnotepostedon
              ev_time = cs_data-debitnotepostedat
              ev_user = lv_user
          ).

          cs_data-debitnotepostedby = lv_user.
          cs_data-message = 'Debit note posted successfully'.

          " Post JV only when both options are enabled.
          " Confirm these flags match your original configuration.
          IF mv_p_jv = abap_true
             AND mv_p_deb_n = abap_true.

            post_jv(
              CHANGING
                cs_data = cs_data
              RECEIVING
                rv_posted = lv_jv_posted
            ).

            IF lv_jv_posted = abap_true.

              get_log(
                IMPORTING
                  ev_date = cs_data-jvpostedon
                  ev_time = cs_data-jvpostedat
                  ev_user = lv_user
              ).

              cs_data-jvpostedby = lv_user.
              cs_data-message = 'Debit note and JV posted successfully'.

            ELSE.

              cs_data-message = 'Debit note posted, but JV posting failed'.

            ENDIF.

          ENDIF.

        ELSE.

          cs_data-message = 'Debit note posting failed'.

        ENDIF.

      WHEN OTHERS.

        cs_data-message = 'Vendor block type is not valid for unblock'.

    ENDCASE.

  ENDMETHOD.


  METHOD unblock.

    unblock_document( CHANGING cs_data = cs_data ).

  ENDMETHOD.

  METHOD update_db.
    CLEAR rv_updated.

    IF is_data IS NOT INITIAL.
      DATA(ls_2a_pay_blk) = CORRESPONDING zcy_t_2a_pay_blk( is_data ).
      MODIFY zcy_t_2a_pay_blk FROM ls_2a_pay_blk.
      IF sy-dbcnt <> 0.
        rv_updated = abap_true.
      ENDIF.
    ENDIF.

  ENDMETHOD.

  METHOD post_jv2.

    CLEAR mt_acc_data.
    SELECT * FROM zpb_r2_mt_acc_data_1 WHERE bukrs = @cs_data-Custom9 AND belnr = @cs_data-Custom1 AND gjahr = @cs_data-Custom4
      INTO TABLE @mt_acc_data.

    "#ToDo
    CONSTANTS:
      lc_obj_type     TYPE bapiache08-obj_type VALUE 'BKPFF',
      lc_obj_key      TYPE bapiache08-obj_key  VALUE '$',
      lc_doc_type     TYPE bapiache08-doc_type VALUE 'SA',
      lc_currency     TYPE bapiaccr08-currency VALUE 'INR',
      lcs_success_msg TYPE msty_message        VALUE '605RW',

      BEGIN OF lcs_tax_type,
        interstate    TYPE bset-ktosl VALUE 'JII',
        intra_central TYPE bset-ktosl VALUE 'JIC',
        intra_state   TYPE bset-ktosl VALUE 'JIS',
      END OF lcs_tax_type,

      BEGIN OF lcs_gl,
        igst_debit TYPE bapiacgl08-gl_account VALUE '0000340843',
        cgst_debit TYPE bapiacgl08-gl_account VALUE '0000340841',
        sgst_debit TYPE bapiacgl08-gl_account VALUE '0000340842',
      END OF lcs_gl.

    DATA:
      ls_header TYPE bapiache08,
      lt_gl     TYPE STANDARD TABLE OF bapiacgl08,
      lt_amount TYPE STANDARD TABLE OF bapiaccr08,
      lt_return TYPE STANDARD TABLE OF bapiret2,
      lv_item   TYPE bapiacgl08-itemno_acc.

    CLEAR:
      ev_comp_code,
      ev_doc_num,
      ev_fis_year,
      ev_message,
      rv_posted,
      ls_header,
      lt_gl,
      lt_amount,
      lt_return.


    DATA(ls_acc_data) = VALUE #( mt_acc_data[ KEY sec_key
                                                bukrs = iv_comp_code
                                                belnr = iv_doc_num
                                                gjahr = iv_fis_year
                                                koart = mcs_acc_type-vendor ] OPTIONAL ).

    IF ls_acc_data IS NOT INITIAL.
      DATA(lt_acc_item) = FILTER #( mt_acc_data USING KEY primary_key
                                      WHERE bukrs = iv_comp_code
                                        AND belnr = iv_doc_num
                                        AND gjahr = iv_fis_year ).

      DATA(lt_tax_item) = FILTER #( mt_tax_data USING KEY sec_key
                                      WHERE bukrs = iv_comp_code
                                        AND belnr = iv_doc_num
                                        AND gjahr = iv_fis_year ).

      LOOP AT lt_acc_item INTO DATA(ls_acc_item).
        IF ls_acc_item-prctr IS NOT INITIAL.
          DATA(lv_profit_center) = ls_acc_item-prctr.
          CLEAR ls_acc_item.
          EXIT.
        ENDIF.
        CLEAR ls_acc_item.
      ENDLOOP.

      DATA(lv_tax_type) = VALUE #( lt_tax_item[ 1 ]-ktosl OPTIONAL ).

      ls_header = VALUE #( obj_type   = lc_obj_type
                           obj_key    = lc_obj_key
                           obj_sys    = ls_acc_data-awsys
                           username   = sy-uname
                           comp_code  = iv_comp_code
                           header_txt = |{ iv_doc_num }{ iv_fis_year }|
                           ref_doc_no = ls_acc_data-xblnr
                           doc_date   = ls_acc_data-bldat
                           doc_type   = lc_doc_type
                           pstng_date = sy-datlo ).

      IF lv_tax_type = lcs_tax_type-interstate.
        CLEAR lv_item.
        lt_gl = VALUE #( pstng_date = sy-datlo
                         comp_code  = iv_comp_code
                         doc_type   = lc_doc_type
                         alloc_nmbr = ls_acc_data-zuonr
                         profit_ctr = lv_profit_center
                         item_text  = TEXT-011
                           ( itemno_acc = |{ CONV posnr_acc( lv_item + '10' ) ALPHA = IN }|
                             gl_account = lcs_gl-igst_debit )
                           ( itemno_acc = |{ CONV posnr_acc( lv_item + '20' ) ALPHA = IN }|
                             gl_account = VALUE #( lt_tax_item[ ktosl = lcs_tax_type-interstate ]-hkont OPTIONAL ) ) ). "#EC CI_SORTSEQ

        CLEAR lv_item.
        lt_amount = VALUE #( currency = lc_currency
                               ( itemno_acc = |{ CONV posnr_acc( lv_item + '10' ) ALPHA = IN }|
                                 amt_doccur = iv_gst_amount )
                               ( itemno_acc = |{ CONV posnr_acc( lv_item + '20' ) ALPHA = IN }|
                                 amt_doccur = ( iv_gst_amount * -1 ) ) ).
      ENDIF.

      IF lv_tax_type = lcs_tax_type-intra_central
              OR lv_tax_type = lcs_tax_type-intra_state.

        CLEAR lv_item.
        lt_gl = VALUE #( pstng_date = sy-datlo
                         comp_code  = iv_comp_code
                         doc_type   = lc_doc_type
                         alloc_nmbr = ls_acc_data-zuonr
                         profit_ctr = lv_profit_center
                         item_text  = TEXT-011
                           ( itemno_acc = |{ CONV posnr_acc( lv_item + '10' ) ALPHA = IN }| gl_account = lcs_gl-cgst_debit )
                           ( itemno_acc = |{ CONV posnr_acc( lv_item + '20' ) ALPHA = IN }| gl_account = VALUE #( lt_tax_item[ ktosl = lcs_tax_type-intra_central ]-hkont OPTIONAL ) ) "#EC CI_SORTSEQ
                           ( itemno_acc = |{ CONV posnr_acc( lv_item + '30' ) ALPHA = IN }| gl_account = lcs_gl-sgst_debit )
                           ( itemno_acc = |{ CONV posnr_acc( lv_item + '40' ) ALPHA = IN }| gl_account = VALUE #( lt_tax_item[ ktosl = lcs_tax_type-intra_state ]-hkont OPTIONAL ) ) ). "#EC CI_SORTSEQ

        CLEAR lv_item.
        lt_amount = VALUE #( currency = lc_currency
                               ( itemno_acc = |{ CONV posnr_acc( lv_item + '10' ) ALPHA = IN }| amt_doccur = ( iv_gst_amount / 2 ) )
                               ( itemno_acc = |{ CONV posnr_acc( lv_item + '20' ) ALPHA = IN }| amt_doccur = ( ( iv_gst_amount / 2 ) * -1 ) )
                               ( itemno_acc = |{ CONV posnr_acc( lv_item + '30' ) ALPHA = IN }| amt_doccur = ( iv_gst_amount / 2 ) )
                               ( itemno_acc = |{ CONV posnr_acc( lv_item + '40' ) ALPHA = IN }| amt_doccur = ( ( iv_gst_amount / 2 ) * -1 ) ) ).
      ENDIF.

      DATA(lv_posted_key) = VALUE bapiache02-obj_key( ).

      CALL FUNCTION 'BAPI_ACC_GL_POSTING_POST'
        EXPORTING
          documentheader = ls_header
        IMPORTING
          obj_key        = lv_posted_key
        TABLES
          accountgl      = lt_gl
          currencyamount = lt_amount
          return         = lt_return.

      process_bapi_return(
        EXPORTING
          is_success_msg = lcs_success_msg
          it_return      = lt_return
        IMPORTING
          es_return      = DATA(ls_return)
        RECEIVING
          rv_success     = rv_posted ).

      IF rv_posted = abap_true.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = abap_true.

        ev_doc_num   = |{ lv_posted_key+0(10) ALPHA = IN }|.
        ev_comp_code = lv_posted_key+10(4).
        ev_fis_year  = lv_posted_key+14(4).

        DATA(lv_posted) = check_document_posted(
                            EXPORTING
                              iv_comp_code = ev_comp_code
                              iv_doc_num   = ev_doc_num
                              iv_fis_year  = ev_fis_year ).
      ELSE.
        ev_message = ls_return-message.
      ENDIF.
    ELSE.
      ev_message = |{ iv_comp_code }-{ iv_doc_num }-{ iv_fis_year } does not exist|.
    ENDIF.


  ENDMETHOD.

  METHOD post_debit_note2.

    CLEAR mt_acc_data.
    CLEAR lt_bsik.
    CLEAR lt_tvarc.

    SELECT * FROM zpb_r2_mt_acc_data_1 WHERE bukrs = @cs_data-Custom9 AND belnr = @cs_data-Custom1 AND gjahr = @cs_data-Custom4
      INTO TABLE @mt_acc_data.

    SELECT * FROM zpb_r2_lt_bsik WHERE bukrs = @iv_comp_code AND belnr = @iv_doc_num AND gjahr = @iv_fis_year
      INTO TABLE @lt_bsik.

    SELECT * FROM tvarvc INTO TABLE lt_tvarc WHERE name = 'ZCY_PAY_TERM' .

    SORT lt_bsik BY bukrs belnr gjahr buzei.

    "#ToDo
    CONSTANTS:
      lc_obj_type     TYPE bapiache09-obj_type   VALUE 'BKPFF',
      lc_obj_key      TYPE bapiache09-obj_key    VALUE '$',
      lc_doc_type     TYPE bapiache09-doc_type   VALUE 'DS',
      lc_gl_account   TYPE bapiacgl09-gl_account VALUE '0000602000',      " #ClientSpecific
      lc_curr_type    TYPE bapiaccr09-curr_type  VALUE '00',
      lc_currency     TYPE bapiaccr09-currency   VALUE 'INR',
      lc_ext_struct   TYPE bapiparex-structure   VALUE '',      " #ClientSpecific
      lcs_success_msg TYPE msty_message          VALUE '605RW'.

    DATA:
      ls_header        TYPE bapiache09,
      lt_gl            TYPE STANDARD TABLE OF bapiacgl09,
      lt_acc_pay       TYPE STANDARD TABLE OF bapiacap09,
      lt_amount        TYPE STANDARD TABLE OF bapiaccr09,
      lt_ext           TYPE STANDARD TABLE OF bapiparex,
      ls_ext           TYPE  bapiparex,
      ls_one           TYPE bapiacpa09,
      lt_return        TYPE STANDARD TABLE OF bapiret2,
      lv_item          TYPE bapiacgl08-itemno_acc,
      lv_profit_center TYPE bseg-prctr.

    CLEAR:
      ev_comp_code,
      ev_doc_num,
      ev_fis_year,
      ev_message,
      rv_posted,
      ls_header,
      ls_one,
      lt_gl,
      lt_acc_pay,
      lt_amount,
      lt_ext,
      lt_return,
      lv_profit_center.

    "REFRESH:mt_acc_data_k[].

    DATA(ls_acc_data) = VALUE #( mt_acc_data[ KEY sec_key
                                                bukrs = iv_comp_code
                                                belnr = iv_doc_num
                                                gjahr = iv_fis_year
                                                koart = mcs_acc_type-vendor ] OPTIONAL ).

    IF ls_acc_data IS NOT INITIAL.
      DATA(lt_acc_item) = FILTER #( mt_acc_data USING KEY primary_key
                                      WHERE bukrs = iv_comp_code
                                        AND belnr = iv_doc_num
                                        AND gjahr = iv_fis_year ).
      mt_acc_data_k = FILTER #( mt_acc_data USING KEY primary_key
                                      WHERE bukrs = iv_comp_code
                                        AND belnr = iv_doc_num
                                        AND gjahr = iv_fis_year ).

      SORT mt_acc_data_k BY bukrs belnr gjahr  dmbtr .

      LOOP AT mt_acc_data_k INTO DATA(ls_acc_item).
        IF ls_acc_item-koart = mcs_acc_type-vendor.
          DATA(lv_assignment) = ls_acc_item-zuonr.
          DATA(lv_bus_plc)    = ls_acc_item-bupla.
          DATA(lv_sect_code)  = ls_acc_item-secco.

*          IF LS_ACC_ITEM-ZLSPR = 'C'..
          READ TABLE lt_tvarc INTO DATA(ls_tvarc) WITH KEY low =  ls_acc_item-zterm.
          IF sy-subrc = 0 AND ls_acc_item-zlspr = 'C'.
            DATA(lv_not_link) = 'X'.
          ELSE.
            DATA(lv_buzei)  = ls_acc_item-buzei.
          ENDIF.

          DATA(zterm) = ls_acc_data-zterm.
        ENDIF.
        IF ls_acc_item-bktxt IS NOT INITIAL.

          DATA(bktxt) = ls_acc_item-bktxt.

        ENDIF.

        IF ls_acc_item-gsber IS NOT INITIAL.

          DATA(gsber) = ls_acc_item-gsber.

        ENDIF.

        IF ls_acc_item-prctr IS NOT INITIAL.

          lv_profit_center = ls_acc_item-prctr.

        ENDIF.

        CLEAR ls_acc_item.

      ENDLOOP.

      READ TABLE lt_bsik INTO DATA(ls_bsik1) WITH KEY bukrs = iv_comp_code belnr = iv_doc_num gjahr = iv_fis_year BINARY SEARCH.
      IF sy-subrc = 0.
        lv_not_link = 'X'.
      ENDIF.

      ls_header = VALUE #( obj_type   = lc_obj_type
                           obj_key    = lc_obj_key
                           obj_sys    = ls_acc_data-awsys
                           bus_act    = ls_acc_data-glvor
                           username   = sy-uname
                           header_txt = bktxt
                           comp_code  = iv_comp_code
                           doc_date   = ls_acc_data-bldat
                           pstng_date = sy-datlo
                           doc_type   = lc_doc_type
                           ref_doc_no = ls_acc_data-xblnr ).

      CLEAR lv_item.

      DATA: msg TYPE string.
      msg = 'GST Hold due to Mismatch/Non Compliance'.

      lt_acc_pay = VALUE #( ( itemno_acc    = |{ CONV posnr_acc( lv_item + '10' ) ALPHA = IN }|
                              vendor_no     = iv_vendor
                              alloc_nmbr    = lv_assignment
                              businessplace = lv_bus_plc
                              bus_area      = gsber
                              profit_ctr    = lv_profit_center
                              item_text     = msg
                              sectioncode   = lv_sect_code
                              pmnttrms      = zterm
                              pmnt_block    = 'Q'
                              comp_code     = iv_comp_code )
                            ( itemno_acc    = |{ CONV posnr_acc( lv_item + '20' ) ALPHA = IN }|
                              vendor_no     = iv_vendor
                              alloc_nmbr    = lv_assignment
                              businessplace = lv_bus_plc
                              bus_area      = gsber
                              profit_ctr    = lv_profit_center
                              item_text     = msg
                              sectioncode   = lv_sect_code
                              pmnt_block    = 'Q'
                              pmnttrms      = zterm
                              comp_code     = iv_comp_code ) ).

      lt_amount = VALUE #( ( itemno_acc = |{ CONV posnr_acc( lv_item + '10' ) ALPHA = IN }|
                             curr_type  = lc_curr_type
                             amt_doccur =  iv_gst_amount
                             currency   = lc_currency )
                           ( itemno_acc = |{ CONV posnr_acc( lv_item + '20' ) ALPHA = IN }|
                             curr_type  = lc_curr_type
                             amt_doccur = ( iv_gst_amount * -1 )
                             currency   = lc_currency ) ).
*
      SELECT SINGLE name1,name2,pstlz,ort01,stcd3,regio,bankn,land1 FROM bsec INTO @DATA(ls_one_ven)
          WHERE belnr = @iv_doc_num AND gjahr = @iv_fis_year AND bukrs = @iv_comp_code AND xcpdk = 'X'.

      IF sy-subrc = 0.

        ls_one-name         = ls_one_ven-name1.
        ls_one-name_2       = ls_one_ven-name2.
        ls_one-postl_code   = ls_one_ven-pstlz.
        ls_one-city         = ls_one_ven-ort01.
        ls_one-tax_no_3     = ls_one_ven-stcd3.
        ls_one-region       = ls_one_ven-regio.
        ls_one-country      = ls_one_ven-land1.

      ENDIF.

      IF lv_not_link = 'X'.

      ELSE.

        DATA(lv_posted_key) = VALUE bapiache09-obj_key( ).
        CLEAR: ls_ext.
        REFRESH : lt_ext[].
        ls_ext-structure = 'ZCY_REBZG'.
        ls_ext-valuepart1 = ls_acc_data-belnr.
        ls_ext-valuepart2 = ls_acc_data-gjahr.
        ls_ext-valuepart3 = lv_buzei.
        APPEND ls_ext TO lt_ext.

      ENDIF.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_POST'
        EXPORTING
          documentheader = ls_header
          customercpd    = ls_one
        IMPORTING
          obj_key        = lv_posted_key
        TABLES
          accountgl      = lt_gl
          accountpayable = lt_acc_pay
          currencyamount = lt_amount
          extension2     = lt_ext
          return         = lt_return.

      process_bapi_return( EXPORTING is_success_msg = lcs_success_msg
                                     it_return      = lt_return
                           IMPORTING es_return      = DATA(ls_return)
                           RECEIVING rv_success     = rv_posted ).

      IF rv_posted = abap_true.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = abap_true.

        ev_doc_num   = |{ lv_posted_key+0(10) ALPHA = IN }|.
        ev_comp_code = lv_posted_key+10(4).
        ev_fis_year  = lv_posted_key+14(4).

        DATA(lv_posted) = check_document_posted( EXPORTING iv_comp_code = ev_comp_code
                                                           iv_doc_num   = ev_doc_num
                                                           iv_fis_year  = ev_fis_year ).

        DATA lt_accchg TYPE STANDARD TABLE OF accchg.
        CLEAR lt_accchg.
        "" Default Key need to be replace with blank on debit item
        SELECT SINGLE zlspr FROM bseg INTO @DATA(blk) WHERE belnr =  @ev_doc_num AND bukrs =  @ev_comp_code
          AND gjahr = @ev_fis_year AND shkzg = 'S'.

        IF blk IS NOT INITIAL AND sy-subrc = 0.
          lt_accchg = VALUE #( ( fdname = 'ZLSPR'
                                 oldval = blk
                                 newval = ' ' ) ).

          CALL FUNCTION 'FI_DOCUMENT_CHANGE'
            EXPORTING
              i_obzei              = '001'
              i_bukrs              = ev_comp_code
              i_belnr              = ev_doc_num
              i_gjahr              = ev_fis_year
            TABLES
              t_accchg             = lt_accchg
            EXCEPTIONS
              no_reference         = 1
              no_document          = 2
              many_documents       = 3
              wrong_input          = 4
              overwrite_creditcard = 5
              error_message        = 6
              OTHERS               = 7.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO ev_message.
          ELSE.

          ENDIF.
        ENDIF.


      ELSE.
        ev_message = ls_return-message.
      ENDIF.
    ELSE.
      ev_message = |{ iv_comp_code }-{ iv_doc_num }-{ iv_fis_year } does not exist|.
    ENDIF.
    CLEAR: blk.
    CLEAR:bktxt.
    CLEAR:lv_not_link.
    CLEAR:zterm.
  ENDMETHOD.

  METHOD reverse_debit_note2.

    CLEAR:
    ev_comp_code,
    ev_doc_num,
    ev_fis_year,
    ev_message,
    rv_reversed.

    IF is_document_open(
         EXPORTING
           iv_doc_num   = iv_doc_num
           iv_comp_code = iv_comp_code
           iv_fis_year  = iv_fis_year ).

      reverse_document2(
        EXPORTING
          iv_doc_num   = iv_doc_num
          iv_comp_code = iv_comp_code
          iv_fis_year  = iv_fis_year
        IMPORTING
          ev_comp_code = ev_comp_code
          ev_doc_num   = ev_doc_num
          ev_fis_year  = ev_fis_year
          ev_message   = ev_message
        RECEIVING
          rv_reversed  = rv_reversed ).
    ELSE.
      ev_message = TEXT-012.
    ENDIF.

    IF rv_reversed = abap_true.

    ENDIF.


  ENDMETHOD.

  METHOD reverse_document2.

    CONSTANTS:
*      lc_obj_type     type bapiacrev-obj_type   value 'BKPFF',
*      lc_obj_key      type bapiacrev-obj_key    value '$',
      lc_rev_reason   TYPE bapiacrev-reason_rev VALUE '04',   " #Client_Specific
*      lcs_success_msg type msty_message         value '605RW'.
      lcs_success_msg TYPE msty_message         VALUE '312F5',
      lc_mem_id       TYPE c LENGTH 10          VALUE 'FBRA'.

    DATA:
      lv_comp_code TYPE bkpf-bukrs,
      lv_doc_num   TYPE bkpf-belnr,
      lv_fis_year  TYPE bkpf-gjahr,
      lv_post_date TYPE bkpf-budat,
      ls_rfdt      TYPE rfdt,
      lt_bdc_msg   TYPE STANDARD TABLE OF bdcmsgcoll,
      lt_return    TYPE STANDARD TABLE OF bapiret2.

    CLEAR:
      ev_comp_code,
      ev_doc_num,
      ev_fis_year,
      ev_message,
      rv_reversed,
      lv_comp_code,
      lv_doc_num,
      lv_fis_year,
      lv_post_date,
      ls_rfdt,
      lt_bdc_msg,
      lt_return.

    " since we are only want the acc header data, pick the GL item as
    " JV document does not have a vendor item
    " GL item is present in all relevant documents
    TRY.
        DATA(ls_acc_data) = VALUE #( mt_acc_data[ KEY sec_key
                                                    bukrs = iv_comp_code
                                                    belnr = iv_doc_num
                                                    gjahr = iv_fis_year
                                                    koart = mcs_acc_type-gl ] ).
      CATCH cx_sy_itab_line_not_found ##no_handler.
        ls_acc_data = VALUE #( mt_acc_data[ KEY sec_key
                                              bukrs = iv_comp_code
                                              belnr = iv_doc_num
                                              gjahr = iv_fis_year
                                              koart = mcs_acc_type-vendor ] ).
    ENDTRY.

    IF ls_acc_data IS NOT INITIAL.
      " Reversal BAPI only works for documents previously created through a BAPI
*      data(ls_reversal) = value bapiacrev( obj_type   = lc_obj_type
*                                           obj_key    = lc_obj_key
*                                           obj_sys    = ls_acc_data-awsys
*                                           obj_key_r  = ls_acc_data-awkey
*                                           reason_rev = lc_rev_reason
*                                           pstng_date = sy-datlo ).
*
*      data(lv_reversed_key) = value bkpf-awkey( ).
*      clear lt_return.
*
*      call function 'BAPI_ACC_DOCUMENT_REV_POST'
*        exporting
*          reversal = ls_reversal
*          bus_act  = ls_acc_data-glvor
*        importing
*          obj_key  = lv_reversed_key
*        tables
*          return   = lt_return.

      CALL FUNCTION 'ZCY_FI_FM_CALL_FB08'
        EXPORTING
          i_bukrs       = iv_comp_code
          i_belnr       = iv_doc_num
          i_gjahr       = iv_fis_year
          i_stgrd       = lc_rev_reason
          i_no_auth     = abap_true
        IMPORTING
          e_budat       = lv_post_date
        TABLES
          et_messtab    = lt_bdc_msg
        EXCEPTIONS
          not_possible  = 1
          error_message = 2
          OTHERS        = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE mcs_msg_type-error NUMBER sy-msgno
          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO ev_message.

        RETURN.
      ELSE.
        IF lt_bdc_msg IS NOT INITIAL.
          CALL FUNCTION 'CONVERT_BDCMSGCOLL_TO_BAPIRET2'
            TABLES
              imt_bdcmsgcoll = lt_bdc_msg
              ext_return     = lt_return.

          process_bapi_return(
            EXPORTING
              is_success_msg = lcs_success_msg
              it_return      = lt_return
            IMPORTING
              es_return      = DATA(ls_return)
            RECEIVING
              rv_success     = rv_reversed ).

          IF rv_reversed = abap_true.
*            call function 'BAPI_TRANSACTION_COMMIT'
*              exporting
*                wait = abap_true.

*            ev_doc_num   = |{ lv_reversed_key+0(10) alpha = in }|.
*            ev_comp_code = lv_reversed_key+10(4).
*            ev_fis_year  = lv_reversed_key+14(4).

            ev_comp_code = iv_comp_code.
            ev_doc_num   = |{ CONV bkpf-belnr( condense( ls_return-message_v1 ) ) ALPHA = IN }|.

            ev_fis_year  = get_fiscal_year2(
                             EXPORTING
                               iv_comp_code = iv_comp_code
                               iv_date      = lv_post_date ).

            DATA(lv_posted) = check_document_posted(
                                EXPORTING
                                  iv_comp_code = ev_comp_code
                                  iv_doc_num   = ev_doc_num
                                  iv_fis_year  = ev_fis_year ).
          ELSE.
            ev_message = ls_return-message.
          ENDIF.
        ENDIF.
      ENDIF.
    ELSE.
      ev_message = |{ iv_comp_code }-{ iv_doc_num }-{ iv_fis_year } does not exist|.
    ENDIF.

  ENDMETHOD.

  METHOD get_fiscal_year2.
    CLEAR rv_fiscal_year.

    CALL FUNCTION 'FI_PERIOD_DETERMINE'
      EXPORTING
        i_budat        = iv_date
        i_bukrs        = iv_comp_code
      IMPORTING
        e_gjahr        = rv_fiscal_year
      EXCEPTIONS
        fiscal_year    = 1
        period         = 2
        period_version = 3
        posting_period = 4
        special_period = 5
        version        = 6
        posting_date   = 7
        OTHERS         = 8.
    IF sy-subrc <> 0.
      " error handling
    ENDIF.
  ENDMETHOD.

ENDCLASS.

