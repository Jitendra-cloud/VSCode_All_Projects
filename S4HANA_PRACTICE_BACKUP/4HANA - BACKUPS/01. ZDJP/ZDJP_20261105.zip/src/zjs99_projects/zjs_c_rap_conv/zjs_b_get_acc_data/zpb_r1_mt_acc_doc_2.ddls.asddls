@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'MT_ACC_DOC'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R1_MT_ACC_DOC_2
  as select from ZPB_R1_MT_ACC_DOC_1
{
  MtAccDoc1_BUKRS as BUKRS,
  MtAccDoc1_BELNR as BELNR,
  MtAccDoc1_GJAHR as GJAHR
}

union

select from ZPB_R1_MT_ACC_DOC_1
{
  MtAccDoc2_BUKRS as BUKRS,
  MtAccDoc2BELNR  as BELNR,
  MtAccDoc2GJAHR  as GJAHR
}

union

select from ZPB_R1_MT_ACC_DOC_1
{
  MtAccDoc3BUKRS as BUKRS,
  MtAccDoc3BELNR as BELNR,
  MtAccDoc3GJAHR as GJAHR
}

union

select from ZPB_R1_MT_ACC_DOC_1
{
  MtAccDoc4BUKRS as BUKRS,
  MtAccDoc4BELNR as BELNR,
  MtAccDoc4GJAHR as GJAHR
}

union

select from ZPB_R1_MT_ACC_DOC_1
{
  MtAccDoc5BUKRS as BUKRS,
  MtAccDoc5BELNR as BELNR,
  MtAccDoc5GJAHR as GJAHR
}

union

select from ZPB_R1_MT_ACC_DOC_1
{
  MtAccDoc6BUKRS as BUKRS,
  MtAccDoc6BELNR as BELNR,
  MtAccDoc6GJAHR as GJAHR
}
