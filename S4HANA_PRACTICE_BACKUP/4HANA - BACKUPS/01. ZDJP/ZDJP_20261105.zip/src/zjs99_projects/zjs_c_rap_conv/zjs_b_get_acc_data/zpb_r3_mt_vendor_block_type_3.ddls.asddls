@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Combined Vendor Block Type'
@Metadata.ignorePropagatedAnnotations: true

define view entity ZPB_R3_MT_VENDOR_BLOCK_TYPE_3
  as select from ZPB_R3_MT_VENDOR_BLOCK_TYPE_1
{
  key vendor,
      vendor_block_type,
      grc_check_applicable
}

union

select from ZPB_R3_MT_VENDOR_BLOCK_TYPE_2
{
  key vendor,
      vendor_block_type,
      grc_check_applicable
}
