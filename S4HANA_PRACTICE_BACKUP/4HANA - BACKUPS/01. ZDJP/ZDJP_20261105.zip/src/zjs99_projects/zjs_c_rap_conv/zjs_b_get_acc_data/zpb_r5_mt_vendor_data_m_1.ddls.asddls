@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ZPB_R_MT_VENDOR_DATA_M'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R5_MT_VENDOR_DATA_M_1
  as select from ZPB_R_MT_ACC_DATA_FILTERED as a
    inner join   lfb1                       as b on b.bukrs   = a.Bukrs
                                                 and( b.lifnr = a.lifnr or b.lifnr = a.gst_part )
{
  key a.Bukrs,
  key a.Belnr,
  key a.Gjahr,

      b.lifnr as VENDOR,
      b.mindk as MINDK
}
