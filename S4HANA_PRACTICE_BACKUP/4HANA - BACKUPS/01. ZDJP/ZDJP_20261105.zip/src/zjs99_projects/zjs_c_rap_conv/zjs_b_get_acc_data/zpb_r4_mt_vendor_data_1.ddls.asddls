@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ZPB_R_MT_VENDOR_DATA'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R4_MT_VENDOR_DATA_1
  as select from    ZPB_R_MT_ACC_DATA_FILTERED as a
    left outer join lfa1                       as v on v.lifnr = a.lifnr
                                                    or v.lifnr = a.gst_part

    left outer join t016t                      as t on v.brsch = t.brsch
{
  v.lifnr as VENDOR,
  v.name1 as NAME,
  v.stcd3 as STCD3,
  v.brsch,
  t.brtxt
}
