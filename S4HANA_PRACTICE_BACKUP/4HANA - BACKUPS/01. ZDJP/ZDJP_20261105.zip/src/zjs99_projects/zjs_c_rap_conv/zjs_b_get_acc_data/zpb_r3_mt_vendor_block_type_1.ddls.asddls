@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Direct Vendor Block Type'
@Metadata.ignorePropagatedAnnotations: true

define view entity ZPB_R3_MT_VENDOR_BLOCK_TYPE_1
  as select from ZPB_R2_MT_ACC_DATA_1 as a
    inner join   zcy_t_2a_blk_typ     as b on b.vendor = a.lifnr
                                           or b.vendor = a.gst_part
{
  key b.vendor               as vendor,
      b.vendor_block_type    as vendor_block_type,
      b.grc_check_applicable as grc_check_applicable
}
