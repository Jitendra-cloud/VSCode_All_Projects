@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'MT_ACC_DOC'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R1_MT_ACC_DOC_1
  as select from ZPB_I_2A_PAY_BLOCK_0
{
  // MT_ACC_DATA ------------------------------------------------

  substring( Custom9, 1, 4 )                      as MtAccDoc1_BUKRS,
  lpad( substring( Custom1, 1, 10 ), 10, '0' )    as MtAccDoc1_BELNR,
  substring( Custom4, 1, 4 )                      as MtAccDoc1_GJAHR,

//---------------------------------------------SplitGSTDocNum------------------------------------------
  case when SplitGstDocNum is not null and SplitGstDocNum <> '' then SplitCompCode
       else '' end                                as MtAccDoc2_BUKRS,
  case when SplitGstDocNum is not null and SplitGstDocNum <> '' then SplitGstDocNum
        else '' end                               as MtAccDoc2BELNR,
  case when SplitGstDocNum is not null and SplitGstDocNum <> '' then SplitYear
        else cast( '0000' as abap.numc( 4 ) ) end as MtAccDoc2GJAHR,

//---------------------------------------------JVDocNum------------------------------------------
  case when JvDocNum is not null and JvDocNum <> '' then JvCompCode
       else '' end                                as MtAccDoc3BUKRS,
  case when JvDocNum is not null and JvDocNum <> '' then JvDocNum
       else '' end                                as MtAccDoc3BELNR,
  case when JvDocNum is not null and JvDocNum <> '' then JvYear
       else cast( '0000' as abap.numc( 4 ) ) end  as MtAccDoc3GJAHR,

//---------------------------------------------JVRevDocNum------------------------------------------
  case when JvRevDocNum is not null and JvRevDocNum <> '' then JvRevCompCode
       else '' end                                as MtAccDoc4BUKRS,
  case when JvRevDocNum is not null and JvRevDocNum <> '' then JvRevDocNum
       else '' end                                as MtAccDoc4BELNR,
  case when JvRevDocNum is not null and JvRevDocNum <> '' then JvRevYear
       else cast( '0000' as abap.numc( 4 ) ) end  as MtAccDoc4GJAHR,

//---------------------------------------------DebitNoteNum------------------------------------------
  case when DebitNoteNum is not null and DebitNoteNum <> '' then DebitNoteComp
       else '' end                                as MtAccDoc5BUKRS,
  case when DebitNoteNum is not null and DebitNoteNum <> '' then DebitNoteNum
       else '' end                                as MtAccDoc5BELNR,
  case when DebitNoteNum is not null and DebitNoteNum <> '' then DebitNoteYear
       else cast( '0000' as abap.numc( 4 ) ) end  as MtAccDoc5GJAHR,

//---------------------------------------------DebitNoteRevNum------------------------------------------
  case when DebitNoteRevNum is not null and DebitNoteRevNum <> '' then DebitNoteRevComp
       else '' end                                as MtAccDoc6BUKRS,
  case when DebitNoteRevNum is not null and DebitNoteRevNum <> '' then DebitNoteRevNum
      else '' end                                 as MtAccDoc6BELNR,
  case when DebitNoteRevNum is not null and DebitNoteRevNum <> '' then DebitNoteRevYear
      else cast( '0000' as abap.numc( 4 ) ) end   as MtAccDoc6GJAHR

}
