@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Final MT_ACC_DOC'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R1_MT_ACC_DOC_3
  as select distinct from ZPB_R1_MT_ACC_DOC_2
{
  BUKRS,
  BELNR,
  GJAHR
}
