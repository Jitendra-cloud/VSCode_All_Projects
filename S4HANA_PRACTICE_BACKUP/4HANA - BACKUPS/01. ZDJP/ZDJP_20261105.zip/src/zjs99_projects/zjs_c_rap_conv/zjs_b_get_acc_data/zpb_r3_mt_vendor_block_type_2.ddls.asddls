@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Vendor Group Block Type'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZPB_R3_MT_VENDOR_BLOCK_TYPE_2
  as select from    zcy_t_2a_blk_typ              as b
    inner join      lfa1                          as c on b.vendor = c.ktokk

    left outer join ZPB_R3_MT_VENDOR_BLOCK_TYPE_1 as d on c.lifnr = d.vendor
{
  key c.lifnr                as vendor,
      b.vendor_block_type    as vendor_block_type,
      b.grc_check_applicable as grc_check_applicable
}
where
  d.vendor is null
