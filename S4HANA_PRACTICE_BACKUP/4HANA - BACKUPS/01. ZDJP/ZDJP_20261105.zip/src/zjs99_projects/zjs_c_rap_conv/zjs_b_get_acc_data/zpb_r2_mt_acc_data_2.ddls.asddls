@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'MT_ACC_DATA'
@Metadata.ignorePropagatedAnnotations: false
define view entity ZPB_R2_MT_ACC_DATA_2
  as select from ZPB_R2_MT_ACC_DATA_1
{
  key Bukrs,
  key Belnr,
  key Gjahr,
      @Semantics.amount.currencyCode: 'hwaer'
      sum( dmbtr ) as dmbtr,
      blart,
      lifnr,
      gst_part,
      augbl,
      augdt,
      hwaer
}

where
  koart = 'K'

group by
  Bukrs,
  Belnr,
  Gjahr,
  blart,
  lifnr,
  gst_part,
  augbl,
  augdt,
  hwaer
