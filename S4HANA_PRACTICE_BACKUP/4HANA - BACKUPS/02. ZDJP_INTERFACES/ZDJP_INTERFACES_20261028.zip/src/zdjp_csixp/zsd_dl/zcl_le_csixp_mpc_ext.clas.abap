class ZCL_LE_CSIXP_MPC_EXT definition
  public
  inheriting from ZCL_LE_CSIXP_MPC
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_LE_CSIXP_MPC_EXT IMPLEMENTATION.
ENDCLASS.
