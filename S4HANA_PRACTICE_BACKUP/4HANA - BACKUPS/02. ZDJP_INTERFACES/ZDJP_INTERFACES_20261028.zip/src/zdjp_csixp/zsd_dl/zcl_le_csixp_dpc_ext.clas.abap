class ZCL_LE_CSIXP_DPC_EXT definition
  public
  inheriting from ZCL_LE_CSIXP_DPC
  create public .

public section.

  constants GC_TIME type T value `000000` ##NO_TEXT.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CHANGESET_BEGIN
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CHANGESET_END
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CHANGESET_PROCESS
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~EXECUTE_ACTION
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_EXPANDED_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_EXPANDED_ENTITYSET
    redefinition .
  PROTECTED SECTION.

    DATA mv_changeset_active TYPE abap_bool .

    METHODS shipdetailset_get_entity
        REDEFINITION .
    METHODS shipdetailset_get_entityset
        REDEFINITION .
  PRIVATE SECTION.

    METHODS persist_notification_data .
    METHODS add_to_where_clause
      IMPORTING
        !iv_where_clause           TYPE string
        !iv_add_filter_field_name  TYPE string
        !iv_add_filter_field_value TYPE data
      RETURNING
        VALUE(rv_where_clause)     TYPE string .
    METHODS get_osql_orderby_clause
      IMPORTING
        !io_tech_request_context TYPE REF TO /iwbep/if_mgw_req_entityset
      RETURNING
        VALUE(rv_orderby_clause) TYPE string .
    METHODS resolve_navigation_path
      IMPORTING
        !io_tech_request_ctx_entity    TYPE REF TO /iwbep/if_mgw_req_entity OPTIONAL
        !io_tech_request_ctx_entityset TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
      EXPORTING
        !er_result                     TYPE data
        !es_response_context           TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context .
    METHODS throw_generic_error .
    METHODS shipdetail_action
      IMPORTING
        !io_tech_request_context TYPE REF TO /iwbep/if_mgw_req_func_import
      EXPORTING
        !er_entity               TYPE zcl_le_csixp_mpc=>ts_shipdetail .
    METHODS shipdetail_get_entity
      IMPORTING
        !iv_document_no  TYPE tknum
      RETURNING
        VALUE(er_entity) TYPE zcl_le_csixp_mpc=>ts_shipdetail
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS shipdetail_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_le_csixp_mpc=>tt_shipdetail
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS shipdetail_conv_prop_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
ENDCLASS.



CLASS ZCL_LE_CSIXP_DPC_EXT IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~changeset_begin.
*    super->/iwbep/if_mgw_appl_srv_runtime~changeset_begin(
*      EXPORTING
*        it_operation_info = it_operation_info
**      CHANGING
**        cv_defer_mode     = cv_defer_mode
*                                          ).

    IF lines( it_operation_info ) > 1.
      mv_changeset_active = abap_true.
    ENDIF.

    "use changeset at once
    LOOP AT it_operation_info
      ASSIGNING FIELD-SYMBOL(<fs_operation_info>).
      IF <fs_operation_info>-content_id IS NOT INITIAL OR
         <fs_operation_info>-content_id_ref IS NOT INITIAL.
        cv_defer_mode = abap_true.
        EXIT.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~changeset_end.
*    super->/iwbep/if_mgw_appl_srv_runtime~changeset_end( ).

    mv_changeset_active = abap_false.
    persist_notification_data( ).
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~changeset_process.
*    super->/iwbep/if_mgw_appl_srv_runtime~changeset_process(
*      EXPORTING
*        it_changeset_request  = it_changeset_request
*      CHANGING
*        ct_changeset_response = ct_changeset_response ).

    DATA:
      ls_shipdetail         TYPE zcl_le_csixp_mpc=>ts_shipdetail,
      ls_changeset_response TYPE /iwbep/if_mgw_appl_types=>ty_s_changeset_response,

      lt_key_tab            TYPE /iwbep/t_mgw_name_value_pair,
      lt_navigation_path    TYPE /iwbep/t_mgw_navigation_path.

    FIELD-SYMBOLS:
      <fs_shipdetail> TYPE zcl_le_csixp_mpc=>ts_shipdetail.

    LOOP AT it_changeset_request
      ASSIGNING FIELD-SYMBOL(<fs_changeset_request>).
      CASE CAST /iwbep/if_mgw_req_entity_c( <fs_changeset_request>-request_context )->get_entity_type_name( ).
        WHEN zcl_le_csixp_mpc=>gc_shipdetail.
          DATA(lo_tech_request_context) =
            CAST /iwbep/if_mgw_req_entity_c( <fs_changeset_request>-request_context ).

          " Set response data
          copy_data_to_ref(
            EXPORTING
              is_data = ls_shipdetail
            CHANGING
              cr_data = ls_changeset_response-entity_data ).

          ls_changeset_response-operation_no = <fs_changeset_request>-operation_no.
          INSERT ls_changeset_response INTO TABLE ct_changeset_response.
        WHEN OTHERS.
      ENDCASE.
    ENDLOOP.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_deep_entity.
    CLEAR er_deep_entity.

    CASE io_tech_request_context->get_entity_set_name( ).
      WHEN 'POHeadSet'.

      WHEN OTHERS.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `907` ).
        MESSAGE e907(zmm). "Just for where-used list

*        TRY.
*            super->/iwbep/if_mgw_appl_srv_runtime~create_deep_entity(
*              EXPORTING
*                iv_entity_name          = iv_entity_name
*                iv_entity_set_name      = iv_entity_set_name
*                iv_source_name          = iv_source_name
*                io_data_provider        = io_data_provider
*                it_key_tab              = it_key_tab
*                it_navigation_path      = it_navigation_path
*                io_expand               = io_expand
*                io_tech_request_context = io_tech_request_context
*              IMPORTING
*                er_deep_entity          = er_deep_entity ).
*          CATCH /iwbep/cx_mgw_busi_exception. " Business Exception
*          CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception
*        ENDTRY.
    ENDCASE.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~execute_action.
*    super->/iwbep/if_mgw_appl_srv_runtime~execute_action(
*      EXPORTING
*        iv_action_name          = iv_action_name
*        it_parameter            = it_parameter
*        io_tech_request_context = io_tech_request_context
*      IMPORTING
*        er_data                 = er_data ).

    DATA:
*      ls_string              TYPE zcl_qm_cognite_mpc=>ct_longtext,
      ls_entity_shipdetail TYPE zcl_le_csixp_mpc=>ts_shipdetail.

    CASE iv_action_name.
      WHEN 'RegenerateAllData'.
*        action_regeneratealldata(
*          EXPORTING
*            io_tech_request_context = io_tech_request_context
*          IMPORTING
*            er_string               = ls_string ).

*        copy_data_to_ref(
*          EXPORTING
*            is_data = ls_string
*          CHANGING
*            cr_data = er_data ).
      WHEN 'PO_Cancel' OR 'PO_Confirm' OR
           'PO_GoodsReceiptCreated' OR 'PO_InvoiceCreated'.
*        notification_action(
*          EXPORTING
*            io_tech_request_context = io_tech_request_context
*          IMPORTING
*            er_entity               = ls_entity_notification ).
*
*        copy_data_to_ref(
*          EXPORTING
*            is_data = ls_entity_notification
*          CHANGING
*            cr_data = er_data ).
      WHEN OTHERS.
        TRY.
            super->/iwbep/if_mgw_appl_srv_runtime~execute_action(
              EXPORTING
                iv_action_name          = iv_action_name
                it_parameter            = it_parameter
                io_tech_request_context = io_tech_request_context
              IMPORTING
                er_data                 = er_data ).
          CATCH /iwbep/cx_mgw_busi_exception
                /iwbep/cx_mgw_tech_exception.
        ENDTRY.
    ENDCASE.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_expanded_entity.
    TRY.
        super->/iwbep/if_mgw_appl_srv_runtime~get_expanded_entity(
          EXPORTING
            iv_entity_name           = iv_entity_name
            iv_entity_set_name       = iv_entity_set_name
            iv_source_name           = iv_source_name
            it_key_tab               = it_key_tab
            it_navigation_path       = it_navigation_path
            io_expand                = io_expand
            io_tech_request_context  = io_tech_request_context
          IMPORTING
            er_entity                = er_entity
            es_response_context      = es_response_context
            et_expanded_clauses      = et_expanded_clauses
            et_expanded_tech_clauses = et_expanded_tech_clauses ).
      CATCH /iwbep/cx_mgw_busi_exception
            /iwbep/cx_mgw_tech_exception.
    ENDTRY.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_expanded_entityset.
    TRY.
        super->/iwbep/if_mgw_appl_srv_runtime~get_expanded_entityset(
          EXPORTING
            iv_entity_name           = iv_entity_name
            iv_entity_set_name       = iv_entity_set_name
            iv_source_name           = iv_source_name
            it_filter_select_options = it_filter_select_options
            it_order                 = it_order
            is_paging                = is_paging
            it_navigation_path       = it_navigation_path
            it_key_tab               = it_key_tab
            iv_filter_string         = iv_filter_string
            iv_search_string         = iv_search_string
            io_expand                = io_expand
            io_tech_request_context  = io_tech_request_context
          IMPORTING
            er_entityset             = er_entityset
            et_expanded_clauses      = et_expanded_clauses
            et_expanded_tech_clauses = et_expanded_tech_clauses
            es_response_context      = es_response_context ).
      CATCH /iwbep/cx_mgw_busi_exception
            /iwbep/cx_mgw_tech_exception.
    ENDTRY.
  ENDMETHOD.


  METHOD add_to_where_clause.
    DATA:
      lv_field_value       TYPE string,
      lv_additional_filter TYPE string.

    lv_field_value = cl_abap_dyn_prg=>quote( iv_add_filter_field_value ).
    CONCATENATE iv_add_filter_field_name '=' lv_field_value INTO lv_additional_filter SEPARATED BY space.

    IF iv_add_filter_field_name IS INITIAL.
      rv_where_clause = iv_where_clause.
    ELSE.
      IF iv_where_clause IS INITIAL.
        rv_where_clause = lv_additional_filter.
      ELSE.
        CONCATENATE '(' iv_where_clause ') and' lv_additional_filter INTO rv_where_clause SEPARATED BY space.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD get_osql_orderby_clause.
    DATA:
      lv_property TYPE string,
      lv_asc_desc TYPE string.

    CLEAR rv_orderby_clause.
    LOOP AT io_tech_request_context->get_orderby( )
      ASSIGNING FIELD-SYMBOL(<fs_orderby>).
      CLEAR lv_property.
      IF <fs_orderby>-property IS NOT INITIAL.
        lv_property = <fs_orderby>-property.
      ELSEIF <fs_orderby>-property_path IS NOT INITIAL.
        lv_property = <fs_orderby>-property_path.
      ENDIF.

      IF <fs_orderby>-order = 'desc'.
        lv_asc_desc = 'DESCENDING'.
      ELSE.
        lv_asc_desc = 'ASCENDING'.
      ENDIF.

      IF lv_property IS NOT INITIAL.
        CONCATENATE rv_orderby_clause lv_property lv_asc_desc
          INTO rv_orderby_clause SEPARATED BY space.
      ENDIF.
    ENDLOOP.
    CONDENSE rv_orderby_clause.
  ENDMETHOD.


  METHOD persist_notification_data.
  ENDMETHOD.


  METHOD resolve_navigation_path.
    DATA:
      lt_nav_path           TYPE /iwbep/t_mgw_tech_navi,

      ls_entity_shipdetail  TYPE zcl_le_csixp_mpc=>ts_shipdetail,

      lv_source_entity_type TYPE /iwbep/mgw_tech_name,
      lv_collection_found   TYPE abap_bool,

      lv_shipmentdocno      TYPE tknum.

    FIELD-SYMBOLS
      <fs_key_values> TYPE any.

    CLEAR:
      er_result, es_response_context.

    IF io_tech_request_ctx_entity IS BOUND.
      lt_nav_path = io_tech_request_ctx_entity->get_navigation_path( ).
    ELSEIF io_tech_request_ctx_entityset IS BOUND.
      lt_nav_path = io_tech_request_ctx_entityset->get_navigation_path( ).
    ELSE.
      throw_generic_error( ).
    ENDIF.

    lv_collection_found = abap_false.

    LOOP AT lt_nav_path
      ASSIGNING FIELD-SYMBOL(<fs_nav_path>).
*   The first entry is the starting point. The key is retrieved using get_converted_source_keys method.
      IF sy-tabix = 1.
        CASE <fs_nav_path>-source_entity_type.
          WHEN zcl_le_csixp_mpc=>gc_shipdetail.
            ASSIGN ls_entity_shipdetail TO <fs_key_values>.
        ENDCASE.

        IF io_tech_request_ctx_entity IS BOUND.
          io_tech_request_ctx_entity->get_converted_source_keys(
            IMPORTING
              es_key_values = <fs_key_values> ).
        ELSE.
          io_tech_request_ctx_entityset->get_converted_source_keys(
            IMPORTING
              es_key_values = <fs_key_values> ).
        ENDIF.

        CASE <fs_nav_path>-source_entity_type.
          WHEN zcl_le_csixp_mpc=>gc_shipdetail.
            TRY.
                ls_entity_shipdetail = shipdetail_get_entity( iv_document_no = ls_entity_shipdetail-tknum ).
              CATCH /iwbep/cx_mgw_busi_exception " Business Exception
                    /iwbep/cx_mgw_tech_exception. " Technical Exception
            ENDTRY.
        ENDCASE.
        lv_source_entity_type = <fs_nav_path>-source_entity_type.
      ENDIF.

      CASE lv_source_entity_type.
        WHEN zcl_le_csixp_mpc=>gc_shipdetail.

      ENDCASE.
      lv_source_entity_type = <fs_nav_path>-target_entity_type.
    ENDLOOP.

    IF lv_collection_found = abap_false.
      CASE <fs_nav_path>-target_entity_type.
        WHEN zcl_le_csixp_mpc=>gc_shipdetail.
          er_result = ls_entity_shipdetail.
      ENDCASE.
    ENDIF.

  ENDMETHOD.


  METHOD shipdetailset_get_entity.
*    TRY.
*        super->shipdetailset_get_entity(
*          EXPORTING
*            iv_entity_name          = iv_entity_name
*            iv_entity_set_name      = iv_entity_set_name
*            iv_source_name          = iv_source_name
*            it_key_tab              = it_key_tab
*            io_request_object       = io_request_object
*            io_tech_request_context = io_tech_request_context
*            it_navigation_path      = it_navigation_path
*          IMPORTING
*            er_entity               = er_entity
*            es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception.
*    ENDTRY.

    DATA
      ls_converted_keys         TYPE zcl_le_csixp_mpc=>ts_shipdetail.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = shipdetail_get_entity( iv_document_no = ls_converted_keys-tknum ).
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD shipdetailset_get_entityset.
*    TRY.
*        super->shipdetailset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception.
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      shipdetail_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD shipdetail_action.
    TYPES:
      BEGIN OF ts_import_parameter,
        salesdocno TYPE vbeln_va,
      END OF ts_import_parameter.

    DATA:
      ls_parameter_values TYPE ts_import_parameter,

      lv_operation        TYPE scx_attrname.

    io_tech_request_context->get_converted_parameters(
      IMPORTING
        es_parameter_values = ls_parameter_values ).

    CLEAR: er_entity.
*    TRY.
**     Convert Notification Number into internal GUID.
*        lv_operation = 'Notification No - Check'.
*
**     Does the PO exist?
*        SELECT SINGLE @abap_true
*          FROM qmel
*          INTO @DATA(lv_bool)
*          WHERE qmnum = @ls_parameter_values-notificationno.
*        IF lv_bool = abap_off.
*          RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
*            EXPORTING
*              textid = VALUE scx_t100key( msgid = `ZMM`
*                                          msgno = `908`
*                                          attr1 = ls_parameter_values-notificationno ).
*          MESSAGE e908(zmm).   "Just for where-used list
*        ENDIF.
*
**     Read the Purchase Order
*        lv_operation = 'Notification - Retrieve'.
*        SELECT SINGLE s~qmnum,
*                      s~qmart,
*                      s~artpr,
*                      s~priok
*          FROM qmel AS s
*          INTO @DATA(ls_qmel)
*          WHERE qmnum = @ls_parameter_values-notificationno.
*        IF sy-subrc <> 0.
**          handle_epm_messages( lr_msg_buf ).
*        ENDIF.
*
*        CASE io_tech_request_context->get_function_import_name( ).
*          WHEN 'Notif_Cancel'.
*            lv_operation = 'Notification - Action-Cancel'.
**            lr_epm_so->action_cancel(
**              EXPORTING
**                it_node_keys      = lt_node_keys_so
**                ii_message_buffer = lr_msg_buf ).
*
*          WHEN 'Notif_Confirm'.
*            lv_operation = 'Notification - Action-Confirm'.
**            lr_epm_so->action_confirm(
**              EXPORTING
**                it_node_keys      = lt_node_keys_so
**                ii_message_buffer = lr_msg_buf ).
*
*          WHEN 'Notif_GoodsIssueCreated'.
*            lv_operation = 'Notification - Action-Goods-Issue-Created'.
**            lr_epm_so->action_goods_issue_created(
**              EXPORTING
**                it_node_keys      = lt_node_keys_so
**                ii_message_buffer = lr_msg_buf ).
*
*          WHEN 'Notif_InvoiceCreated'.
*            lv_operation = 'Notification - Action-Invoice-Created'.
**            lr_epm_so->action_invoice_created(
**              EXPORTING
**                it_node_keys      = lt_node_keys_so
**                ii_message_buffer = lr_msg_buf ).
*
*          WHEN OTHERS.
*            throw_generic_error( ).
*        ENDCASE.
**        handle_epm_messages( lr_msg_buf ).
*
*        persist_notification_data( ).
*        TRY.
*            er_entity = notification_get_entity( iv_notification_no = ls_parameter_values-notificationno ).
*          CATCH /iwbep/cx_mgw_busi_exception " Business Exception
*                /iwbep/cx_mgw_tech_exception. " Technical Exception
*        ENDTRY.
*      CATCH cx_epm_api_exception cx_epm_system_exception.
**        handle_epm_exception( lv_epm_operation ).
*    ENDTRY.
  ENDMETHOD.


  METHOD shipdetail_conv_prop_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF `TKNUM` IN rv_string WITH `v~TKNUM`.
    REPLACE ALL OCCURRENCES OF `VBELN` IN rv_string WITH `a~VBELN`.
    REPLACE ALL OCCURRENCES OF `POSNR` IN rv_string WITH `b~POSNR`.
    REPLACE ALL OCCURRENCES OF `ETENR` IN rv_string WITH `c~ETENR`.
    REPLACE ALL OCCURRENCES OF `NAME1` IN rv_string WITH `e~NAME1`.
*    REPLACE ALL OCCURRENCES OF `KUNAG` IN rv_string WITH `KUNAG`.
*    REPLACE ALL OCCURRENCES OF `NAME2` IN rv_string WITH `NAME2`.
*    REPLACE ALL OCCURRENCES OF `BNAME` IN rv_string WITH `BNAME`.
    REPLACE ALL OCCURRENCES OF `BSTNK` IN rv_string WITH `a~BSTNK`.
    REPLACE ALL OCCURRENCES OF `MATNR` IN rv_string WITH `b~MATNR`.
    REPLACE ALL OCCURRENCES OF `ARKTX` IN rv_string WITH `b~ARKTX`.
    REPLACE ALL OCCURRENCES OF `ZZSLBWT` IN rv_string WITH `m~ZZSLBWT`.
    REPLACE ALL OCCURRENCES OF `KDMAT` IN rv_string WITH `b~KDMAT`.
    REPLACE ALL OCCURRENCES OF `KWMENG` IN rv_string WITH `b~KWMENG`.
    REPLACE ALL OCCURRENCES OF `VRKME` IN rv_string WITH `b~VRKME`.
*    REPLACE ALL OCCURRENCES OF `ORGORQTY` IN rv_string WITH `ORGORQTY`.
    REPLACE ALL OCCURRENCES OF `BRGEW` IN rv_string WITH `m~BRGEW`.
    REPLACE ALL OCCURRENCES OF `ORUNIT` IN rv_string WITH `b~ORUNIT`.
    REPLACE ALL OCCURRENCES OF `ORDUOM` IN rv_string WITH `b~ORDUOM`.
    REPLACE ALL OCCURRENCES OF `BMENG` IN rv_string WITH `c~BMENG`.
    REPLACE ALL OCCURRENCES OF `VSTEL` IN rv_string WITH `b~VSTEL`.
    REPLACE ALL OCCURRENCES OF `EDATU` IN rv_string WITH `c~EDATU`.
    REPLACE ALL OCCURRENCES OF `MBDAT` IN rv_string WITH `k~MBDAT`.
*    REPLACE ALL OCCURRENCES OF `EDATU2` IN rv_string WITH `EDATU2`.
    REPLACE ALL OCCURRENCES OF `ZZVSBED` IN rv_string WITH `b~ZZVSBED`.
    REPLACE ALL OCCURRENCES OF `LDC` IN rv_string WITH `b~ZZ_LDC`.
*    REPLACE ALL OCCURRENCES OF `PRDQTY` IN rv_string WITH `PRDQTY`.
*    REPLACE ALL OCCURRENCES OF `TKNUM2` IN rv_string WITH `TKNUM2`.
    REPLACE ALL OCCURRENCES OF `VBELN_VF` IN rv_string WITH `j~VBELN_VF`.
    REPLACE ALL OCCURRENCES OF `WERKS` IN rv_string WITH `b~WERKS`.
    REPLACE ALL OCCURRENCES OF `VDATU` IN rv_string WITH `a~VDATU`.
*    REPLACE ALL OCCURRENCES OF `DALEN` IN rv_string WITH `DALEN`.
*    REPLACE ALL OCCURRENCES OF `DATEN2` IN rv_string WITH `DATEN2`.
*    REPLACE ALL OCCURRENCES OF `BDDSC` IN rv_string WITH `BDDSC`.
    REPLACE ALL OCCURRENCES OF `SPONO` IN rv_string WITH `n~SPONO`.
    REPLACE ALL OCCURRENCES OF `SPOIT` IN rv_string WITH `i~SPOIT`.
    REPLACE ALL OCCURRENCES OF `STDIS` IN rv_string WITH `v~STDIS`.
    REPLACE ALL OCCURRENCES OF `DAREG` IN rv_string WITH `v~DAREG`.
    REPLACE ALL OCCURRENCES OF `UALBG` IN rv_string WITH `v~UALBG`.
    REPLACE ALL OCCURRENCES OF `UALEN` IN rv_string WITH `v~UALEN`.
    REPLACE ALL OCCURRENCES OF `UATBG` IN rv_string WITH `v~UATBG`.
    REPLACE ALL OCCURRENCES OF `DATEN` IN rv_string WITH `v~DATEN`.
    REPLACE ALL OCCURRENCES OF `UATEN` IN rv_string WITH `v~UATEN`.

  ENDMETHOD.


  METHOD shipdetail_get_entity.
  ENDMETHOD.


  METHOD shipdetail_get_entityset.
    DATA:
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_count           TYPE i,
      lv_offset          TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string,
      ls_paging          TYPE /iwbep/s_mgw_paging,
      lt_values          TYPE TABLE OF conf_out INITIAL SIZE 0,
      lv_rdd             TYPE vbep-edatu,
      lv_flagg           TYPE c.

    CLEAR:
      et_entityset[], es_response_context.

    IF io_tech_request_context IS BOUND.
      lv_where_clause   = shipdetail_conv_prop_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = shipdetail_conv_prop_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      ls_paging-top  = io_tech_request_context->get_top( ).
      ls_paging-skip = io_tech_request_context->get_skip( ).
      IF ( ls_paging-top > 0 ).
        lv_maxrows = ls_paging-top + ls_paging-skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter/OrderBy on Short Text plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS `QMTXT`.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS `QMTXT`.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause =
      add_to_where_clause( iv_where_clause           = lv_where_clause
                           iv_add_filter_field_name  = iv_add_filter_field_name
                           iv_add_filter_field_value = iv_add_filter_field_value ).

*    lv_where_clause =
*      convert_date_time( iv_where_clause = lv_where_clause ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL AND lv_where_clause IS NOT INITIAL.
      lv_orderby_clause = 'a~VBELN, b~POSNR, c~ETENR'.
    ENDIF.

* Filter/OrderBy on Short Text plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS `QMTXT`.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS `QMTXT`.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    TRY.
        SELECT DISTINCT a~vbeln,
               a~vdatu,
               a~bstnk,
               a~kunnr,

               b~posnr,
               b~matnr,
               b~arktx,
               b~zmeng,
               b~zieme,
               b~kdmat,
               b~kwmeng,
               b~vrkme,
               b~werks,
               b~vstel,
               b~cuobj,
               b~zz_ldc,
               b~zz_order_units,
               b~zz_order_units_u,
               b~zzvsbed,

               c~etenr,
               c~edatu,
               c~wmeng,
               c~bmeng,

               e~name1,

*               f~kunnr as kunag,

*               g~name1 as name2,

*               i~name1 as name3,

               j~vbeln AS vbeln_vf,

               k~mbdat,

               l~ebelp,
               l~aedat,

               m~brgew,
               m~zzslbwt,

               n~ebeln,

               v~tknum,
               v~stdis,
               v~dareg,
               v~uplbg,
               v~ualbg,
               v~dalen,
               v~ualen,
               v~uatbg,
               v~daten,
               v~uaten

*               '' as prodqty,

*               '' as branddesc,

               FROM vbak AS a
                INNER JOIN vbap AS b
                  ON b~vbeln = a~vbeln
                INNER JOIN vbep AS c
                  ON c~vbeln = a~vbeln
                 AND c~posnr = b~posnr
                LEFT OUTER JOIN mara AS m
                  ON m~matnr = b~matnr
*                LEFT OUTER JOIN vbpa AS d
*                  ON d~vbeln = a~vbeln
*                 AND d~posnr = '000000'
*                 AND d~parvw = 'AG'
*                LEFT OUTER JOIN vbpa AS d
*                  ON d~vbeln = a~vbeln
*                 AND d~posnr = '000000'
*                 AND d~parvw = 'ZQ'
                LEFT OUTER JOIN kna1 AS e
                  ON e~kunnr = a~kunnr
                LEFT OUTER JOIN vbpa AS f
                  ON f~vbeln = a~vbeln
                 AND f~posnr = '000000'
                 AND f~parvw = 'WE'
                LEFT OUTER JOIN kna1 AS g
                  ON g~kunnr = f~kunnr
                LEFT OUTER JOIN vbpa AS h
                  ON h~vbeln = a~vbeln
                 AND h~posnr = '000000'
                 AND h~parvw = 'ZE'
                LEFT OUTER JOIN kna1 AS i
                  ON i~kunnr = h~kunnr
                LEFT OUTER JOIN vbfa AS j
                  ON j~vbelv = a~vbeln
                 AND j~posnv = b~posnr
                 AND j~vbtyp_n = 'M'
                LEFT OUTER JOIN lips AS k
                  ON k~vgbel = a~vbeln
                 AND k~vgpos = b~posnr
                LEFT OUTER JOIN ekkn AS l
                  ON l~vbeln = a~vbeln
                 AND l~vbelp = b~posnr
                LEFT OUTER JOIN ekko AS n
                  ON n~ebeln = l~ebeln
                LEFT OUTER JOIN vttp AS p
                  ON p~vbeln = k~vbeln
                LEFT OUTER JOIN vttk AS v
                  ON v~tknum = p~tknum
                INTO TABLE @DATA(lt_rslt)
                UP TO @lv_maxrows ROWS
                WHERE (lv_where_clause).
*                ORDER BY (lv_orderby_clause).
        IF ( sy-dbcnt > ls_paging-skip ).

          LOOP AT lt_rslt
            ASSIGNING FIELD-SYMBOL(<lfs_rslt>).
            APPEND INITIAL LINE TO et_entityset
              ASSIGNING FIELD-SYMBOL(<fs_entityset>).
            <fs_entityset>-tknum = <lfs_rslt>-tknum.
            <fs_entityset>-vbeln = <lfs_rslt>-vbeln.
            <fs_entityset>-posnr = <lfs_rslt>-posnr.
            <fs_entityset>-etenr = <lfs_rslt>-etenr.
            <fs_entityset>-name1 = <lfs_rslt>-name1.
            SELECT SINGLE kunnr
              FROM vbpa
              INTO @<fs_entityset>-kunag
              WHERE vbeln = @<lfs_rslt>-vbeln
                AND parvw = 'WE'.
            IF sy-subrc = 0.
              SELECT SINGLE name1
                FROM kna1
                INTO @<fs_entityset>-name2
                WHERE kunnr = @<fs_entityset>-kunag.
            ENDIF.

            SELECT SINGLE kunnr
              FROM vbpa
              INTO @DATA(lv_kunnr)
              WHERE vbeln = @<lfs_rslt>-vbeln
                AND parvw = 'ZE'.
            IF sy-subrc = 0.
              SELECT SINGLE name1
                FROM kna1
                INTO @<fs_entityset>-bname
                WHERE kunnr = @lv_kunnr.
            ENDIF.

            <fs_entityset>-bstnk = <lfs_rslt>-bstnk.
            <fs_entityset>-matnr = <lfs_rslt>-matnr.
            <fs_entityset>-arktx = <lfs_rslt>-arktx.
            <fs_entityset>-kdmat = <lfs_rslt>-kdmat.
            <fs_entityset>-vrkme = <lfs_rslt>-vrkme.
            <fs_entityset>-kwmeng = <lfs_rslt>-kwmeng.
            <fs_entityset>-orgorqty = <lfs_rslt>-kwmeng.
            <fs_entityset>-zzslbwt = <lfs_rslt>-zzslbwt.
            <fs_entityset>-brgew = <lfs_rslt>-brgew.
            <fs_entityset>-orunit = <lfs_rslt>-zz_order_units.
            <fs_entityset>-orduom = <lfs_rslt>-zz_order_units_u.
            <fs_entityset>-bmeng = <lfs_rslt>-bmeng.
            <fs_entityset>-vstel = <lfs_rslt>-vstel.
            IF <lfs_rslt>-wmeng > 0.  " AND lines( lt_rslt[ vbeln = <lfs_rslt>-vbeln
              "                     posnr = <lfs_rslt>-posnr ] ) > 1.
              CONVERT DATE <lfs_rslt>-edatu
                TIME gc_time
                  INTO TIME STAMP <fs_entityset>-edatu
                    TIME ZONE sy-zonlo.
            ENDIF.

            CONVERT DATE <lfs_rslt>-mbdat
              TIME gc_time
                INTO TIME STAMP <fs_entityset>-mbdat
                  TIME ZONE sy-zonlo.
            IF <lfs_rslt>-bmeng > 0.
              CONVERT DATE <lfs_rslt>-edatu
                TIME gc_time
                  INTO TIME STAMP <fs_entityset>-edatu2
                    TIME ZONE sy-zonlo.
            ENDIF.
            <fs_entityset>-zzvsbed = <lfs_rslt>-zzvsbed.
            CONVERT DATE <lfs_rslt>-zz_ldc
              TIME gc_time
                INTO TIME STAMP <fs_entityset>-ldc
                  TIME ZONE sy-zonlo.
*            <fs_entityset>-prdqty = <lfs_rslt>-.
            <fs_entityset>-tknum2 = <lfs_rslt>-tknum.
            <fs_entityset>-vbeln_vf = <lfs_rslt>-vbeln_vf.
            <fs_entityset>-werks = <lfs_rslt>-werks.

            CONVERT DATE <lfs_rslt>-vdatu
              TIME gc_time
                INTO TIME STAMP <fs_entityset>-vdatu
                  TIME ZONE sy-zonlo.
            CONVERT DATE <lfs_rslt>-dalen
              TIME gc_time
                INTO TIME STAMP <fs_entityset>-dalen
                  TIME ZONE sy-zonlo.
            CONVERT DATE <lfs_rslt>-dalen
              TIME gc_time
                INTO TIME STAMP <fs_entityset>-daten2
                  TIME ZONE sy-zonlo.

            IF <lfs_rslt>-cuobj IS NOT INITIAL.
              CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
                EXPORTING
                  instance           = <lfs_rslt>-cuobj
                TABLES
                  configuration      = lt_values
                EXCEPTIONS
                  instance_not_found = 1
                  OTHERS             = 2.
              IF sy-subrc = 0.
                <fs_entityset>-bddsc =
                  VALUE #( lt_values[ atnam = 'WP_BRAND_TAXONOMY' ]-atwtb OPTIONAL ).
              ENDIF.
            ENDIF.

            <fs_entityset>-spono = <lfs_rslt>-ebeln.
            <fs_entityset>-spoit = <lfs_rslt>-ebelp.
            <fs_entityset>-stdis = <lfs_rslt>-stdis.
            CONVERT DATE <lfs_rslt>-dareg
              TIME gc_time
                INTO TIME STAMP <fs_entityset>-dareg
                  TIME ZONE sy-zonlo.
            <fs_entityset>-ualbg = <lfs_rslt>-uplbg.
            <fs_entityset>-ualen = <lfs_rslt>-ualen.
            <fs_entityset>-uatbg = <lfs_rslt>-uatbg.
            CONVERT DATE <lfs_rslt>-daten
              TIME gc_time
                INTO TIME STAMP <fs_entityset>-daten
                  TIME ZONE sy-zonlo.
            <fs_entityset>-uaten = <lfs_rslt>-uatbg.
          ENDLOOP.

          /iwbep/cl_mgw_data_util=>paging(
            EXPORTING
              is_paging = ls_paging                 " paging structure
            CHANGING
              ct_data   = et_entityset ).

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount EQ abap_true ) AND ( ls_paging-top = 0 AND ls_paging-skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.
      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `POHeadSet` ).
        MESSAGE e906(zmm) ##MG_MISSING.   "Just for where-used list
    ENDTRY.          .
  ENDMETHOD.


  METHOD throw_generic_error.
    DATA
      lv_dummy TYPE string.

    RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
      EXPORTING
        textid = VALUE scx_t100key( msgid = `ZMM`
                                    msgno = `901` ).
    MESSAGE e901(zmm) INTO lv_dummy.
  ENDMETHOD.
ENDCLASS.
