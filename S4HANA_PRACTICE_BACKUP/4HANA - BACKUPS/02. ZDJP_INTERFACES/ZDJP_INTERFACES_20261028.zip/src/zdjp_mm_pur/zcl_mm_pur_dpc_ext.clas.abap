CLASS zcl_mm_pur_dpc_ext DEFINITION
  PUBLIC
  INHERITING FROM zcl_mm_pur_dpc
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      tt_dd07v TYPE STANDARD TABLE OF dd07v WITH DEFAULT KEY .

    CONSTANTS gc_time TYPE t VALUE `120000` ##NO_TEXT.
*    CONSTANTS cv_plant TYPE string VALUE 'Plant' ##NO_TEXT.
*    CONSTANTS cv_partner TYPE string VALUE 'Partner' ##NO_TEXT.
*    CONSTANTS cv_material TYPE string VALUE 'Material' ##NO_TEXT.
*    CONSTANTS cv_pohead TYPE string VALUE 'POHead' ##NO_TEXT.
*    CONSTANTS cv_poitem TYPE string VALUE 'POItem' ##NO_TEXT.
*    CONSTANTS cv_poschedule TYPE string VALUE 'POSchedule' ##NO_TEXT.
*    CONSTANTS cv_grhead TYPE string VALUE 'GRHead' ##NO_TEXT.
*    CONSTANTS cv_gritem TYPE string VALUE 'GRItem' ##NO_TEXT.

    METHODS /iwbep/if_mgw_appl_srv_runtime~changeset_begin
        REDEFINITION .
    METHODS /iwbep/if_mgw_appl_srv_runtime~changeset_end
        REDEFINITION .
    METHODS /iwbep/if_mgw_appl_srv_runtime~changeset_process
        REDEFINITION .
    METHODS /iwbep/if_mgw_appl_srv_runtime~create_deep_entity
        REDEFINITION .
    METHODS /iwbep/if_mgw_appl_srv_runtime~execute_action
        REDEFINITION .
    METHODS /iwbep/if_mgw_appl_srv_runtime~get_expanded_entity
        REDEFINITION .
    METHODS /iwbep/if_mgw_appl_srv_runtime~get_expanded_entityset
        REDEFINITION .
  PROTECTED SECTION.

    DATA mv_changeset_active TYPE abap_bool VALUE abap_false ##NO_TEXT.
    DATA mt_dd07v_lifecycle TYPE tt_dd07v .

    METHODS grheadset_get_entity
        REDEFINITION .
    METHODS grheadset_get_entityset
        REDEFINITION .
    METHODS gritemset_get_entityset
        REDEFINITION .
    METHODS materialset_get_entity
        REDEFINITION .
    METHODS materialset_get_entityset
        REDEFINITION .
    METHODS partnerset_get_entity
        REDEFINITION .
    METHODS partnerset_get_entityset
        REDEFINITION .
    METHODS plantset_get_entity
        REDEFINITION .
    METHODS plantset_get_entityset
        REDEFINITION .
    METHODS poheadset_get_entity
        REDEFINITION .
    METHODS poheadset_get_entityset
        REDEFINITION .
    METHODS poitemset_get_entity
        REDEFINITION .
    METHODS poitemset_get_entityset
        REDEFINITION .
    METHODS poitemset_update_entity
        REDEFINITION .
    METHODS poscheduleset_get_entity
        REDEFINITION .
    METHODS poscheduleset_get_entityset
        REDEFINITION .
    METHODS poscheduleset_update_entity
        REDEFINITION .
    METHODS gritemset_get_entity
        REDEFINITION .
  PRIVATE SECTION.

    METHODS add_to_where_clause
      IMPORTING
        !iv_where_clause           TYPE string
        !iv_add_filter_field_name  TYPE string
        !iv_add_filter_field_value TYPE data
      RETURNING
        VALUE(rv_where_clause)     TYPE string .
    METHODS get_osql_orderby_clause
      IMPORTING
        !io_tech_request_context TYPE REF TO /iwbep/if_mgw_req_entityset
      RETURNING
        VALUE(rv_orderby_clause) TYPE string .
    METHODS resolve_navigation_path
      IMPORTING
        !io_tech_request_ctx_entity    TYPE REF TO /iwbep/if_mgw_req_entity OPTIONAL
        !io_tech_request_ctx_entityset TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
      EXPORTING
        !er_result                     TYPE data
        !es_response_context           TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context .
    METHODS throw_generic_error
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS action_po_actions
      IMPORTING
        !io_tech_request_context TYPE REF TO /iwbep/if_mgw_req_func_import
      EXPORTING
        !er_entity               TYPE zcl_mm_pur_mpc=>ts_pohead .
    METHODS plant_get_entity
      IMPORTING
        !iv_plantcode    TYPE werks_d
      RETURNING
        VALUE(er_entity) TYPE zcl_mm_pur_mpc=>ts_plant
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS plant_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_plant
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context .
    METHODS plant_conv_properties_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
    METHODS partner_get_entity
      IMPORTING
        !iv_partnerno    TYPE lifnr
      RETURNING
        VALUE(er_entity) TYPE zcl_mm_pur_mpc=>ts_partner
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS partner_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_partner
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context .
    METHODS partner_conv_properties_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
    METHODS material_get_entity
      IMPORTING
        !iv_materialno   TYPE matnr
      RETURNING
        VALUE(er_entity) TYPE zcl_mm_pur_mpc=>ts_material
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS material_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_material
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context .
    METHODS material_conv_proper_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
    METHODS po_head_get_entity
      IMPORTING
        !iv_po           TYPE ebeln
      RETURNING
        VALUE(er_entity) TYPE zcl_mm_pur_mpc=>ts_pohead
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS po_head_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_pohead
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS po_head_conv_properties_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
    METHODS po_item_get_entity
      IMPORTING
        !iv_po           TYPE ebeln
        !iv_po_item      TYPE ebelp
      RETURNING
        VALUE(er_entity) TYPE zcl_mm_pur_mpc=>ts_poitem
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS po_item_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_poitem
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS po_item_conv_properties_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
    METHODS po_item_sch_get_entity
      IMPORTING
        !iv_po            TYPE ebeln
        !iv_po_item       TYPE ebelp
        !iv_po_item_schln TYPE etenr
      RETURNING
        VALUE(er_entity)  TYPE zcl_mm_pur_mpc=>ts_poschedule
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS po_item_sch_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_poschedule
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS po_item_sch_conv_proper_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
    METHODS deep_insert_po_items_schedules
      IMPORTING
        !io_data_provider TYPE REF TO /iwbep/if_mgw_entry_provider
      EXPORTING
        !es_po_poit_posch TYPE zcl_mm_pur_mpc_ext=>ts_po_poit_posch .
    METHODS persist_po_data
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS poitem_update_int
      IMPORTING
        !is_entity TYPE zcl_mm_pur_mpc=>ts_poitem
      EXPORTING
        !er_entity TYPE zcl_mm_pur_mpc=>ts_poitem
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS poschedule_update_int
      IMPORTING
        !is_entity TYPE zcl_mm_pur_mpc=>ts_poschedule
      EXPORTING
        !er_entity TYPE zcl_mm_pur_mpc=>ts_poschedule
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS gr_get_entity
      IMPORTING
        !iv_gr           TYPE mblnr
        !iv_year         TYPE mjahr
      RETURNING
        VALUE(er_entity) TYPE zcl_mm_pur_mpc=>ts_grhead
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS gr_item_get_entity
      IMPORTING
        !iv_gr           TYPE mblnr
        !iv_year         TYPE mjahr
        !iv_gr_item      TYPE mblpo
      RETURNING
        VALUE(er_entity) TYPE zcl_mm_pur_mpc=>ts_gritem
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS gr_item_conv_proper_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
    METHODS gr_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_grhead
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS gr_item_get_entityset
      IMPORTING
        !io_tech_request_context   TYPE REF TO /iwbep/if_mgw_req_entityset OPTIONAL
        !iv_add_filter_field_name  TYPE string OPTIONAL
        !iv_add_filter_field_value TYPE data OPTIONAL
      EXPORTING
        !et_entityset              TYPE zcl_mm_pur_mpc=>tt_gritem
        !es_response_context       TYPE /iwbep/if_mgw_appl_srv_runtime=>ty_s_mgw_response_context
      RAISING
        /iwbep/cx_mgw_busi_exception
        /iwbep/cx_mgw_tech_exception .
    METHODS gr_conv_proper_to_sql
      IMPORTING
        !iv_string       TYPE string
      RETURNING
        VALUE(rv_string) TYPE string .
ENDCLASS.



CLASS ZCL_MM_PUR_DPC_EXT IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~changeset_begin.
*    TRY.
*        super->/iwbep/if_mgw_appl_srv_runtime~changeset_begin(
*          EXPORTING
*            it_operation_info = it_operation_info
*          CHANGING
*            cv_defer_mode     = cv_defer_mode ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

* mv_changeset_actvie suppresses the immediate commit work of changes. In case a changeset only
* consists of 1 operation we can still do a commit work.
    IF lines( it_operation_info ) > 1.
      mv_changeset_active = abap_true.
    ENDIF.

    "use changeset at once
    LOOP AT it_operation_info
      ASSIGNING FIELD-SYMBOL(<fs_operation_info>).
      IF <fs_operation_info>-content_id IS NOT INITIAL OR
         <fs_operation_info>-content_id_ref IS NOT INITIAL.
        cv_defer_mode = abap_true.
        EXIT.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~changeset_end.
*    TRY.
*        super->/iwbep/if_mgw_appl_srv_runtime~changeset_end( ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    mv_changeset_active = abap_false.
    persist_po_data( ).
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~changeset_process.
*    TRY.
*        super->/iwbep/if_mgw_appl_srv_runtime~changeset_process(
*          EXPORTING
*            it_changeset_request  = it_changeset_request
*          CHANGING
*            ct_changeset_response = ct_changeset_response ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA:
      ls_po                 TYPE zcl_mm_pur_mpc=>ts_pohead,
      ls_item               TYPE zcl_mm_pur_mpc=>ts_poitem,
      ls_schedule           TYPE zcl_mm_pur_mpc=>ts_poschedule,
      ls_new_item           TYPE zcl_mm_pur_mpc=>ts_poitem,
      ls_new_schedule       TYPE zcl_mm_pur_mpc=>ts_poschedule,
      ls_changeset_response TYPE /iwbep/if_mgw_appl_types=>ty_s_changeset_response,

      lt_key_tab            TYPE /iwbep/t_mgw_name_value_pair,
      lt_navigation_path    TYPE /iwbep/t_mgw_navigation_path.

    FIELD-SYMBOLS:
      <fs_po>       TYPE zcl_mm_pur_mpc=>ts_pohead,
      <fs_item>     TYPE zcl_mm_pur_mpc=>ts_poitem,
      <fs_schedule> TYPE zcl_mm_pur_mpc=>ts_poschedule.

    LOOP AT it_changeset_request
      ASSIGNING FIELD-SYMBOL(<fs_changeset_request>).
      CASE CAST /iwbep/if_mgw_req_entity_c( <fs_changeset_request>-request_context )->get_entity_type_name( ).
        WHEN 'POHead'.
          DATA(lo_tech_request_context) =
            CAST /iwbep/if_mgw_req_entity_c( <fs_changeset_request>-request_context ).

*          "create the Purchase Order
*          poheadset_create_entity(
*            EXPORTING
*              iv_entity_name     = lo_tech_request_context->get_entity_type_name( )
*              iv_entity_set_name = lo_tech_request_context->get_entity_set_name( )
*              iv_source_name     = lo_tech_request_context->get_source_entity_type_name( )
*              it_key_tab         = lt_key_tab
*              io_tech_request_context = lo_tech_request_context
*              it_navigation_path = lt_navigation_path
*              io_data_provider   = ls_changeset_request-entry_provider
*            IMPORTING
*             er_entity            = ls_po ).

          " Set response data
          copy_data_to_ref(
             EXPORTING
               is_data = ls_po
             CHANGING
               cr_data = ls_changeset_response-entity_data ).

          ls_changeset_response-operation_no = <fs_changeset_request>-operation_no.
          INSERT ls_changeset_response INTO TABLE ct_changeset_response.
        WHEN 'POItem'.
          <fs_changeset_request>-entry_provider->read_entry_data(
                                                   IMPORTING
                                                     es_data = ls_item ).

          IF <fs_changeset_request>-content_id IS NOT INITIAL.  "id_ref
            ASSIGN it_changeset_request[ content_id = <fs_changeset_request>-content_id ] "id_ref
              TO FIELD-SYMBOL(<fs_changeset_req_parent>).
            IF <fs_changeset_req_parent> IS ASSIGNED. "sy-subrc = 0.
*              ASSIGN ct_changeset_response[ operation_no = <fs_changeset_req_parent>-operation_no ]
*                TO FIELD-SYMBOL(<fs_changeset_resp_parent>).
*              IF <fs_changeset_resp_parent> IS ASSIGNED.
*                ASSIGN <fs_changeset_resp_parent>-entity_data->* TO <fs_po>.
*                IF <fs_po>-ebeln IS NOT INITIAL.
*              ls_item-ebeln = <fs_po>-ebeln.

*                  "create the Purchase Order Item
              poitem_update_int(
                EXPORTING
                  is_entity = ls_item
                IMPORTING
                 er_entity = ls_new_item ).

              copy_data_to_ref(
                 EXPORTING
                   is_data = ls_new_item
                 CHANGING
                   cr_data = ls_changeset_response-entity_data ).

              ls_changeset_response-operation_no = <fs_changeset_request>-operation_no.
              INSERT ls_changeset_response INTO TABLE ct_changeset_response.
*                ENDIF.
*                UNASSIGN <fs_changeset_resp_parent>.
*              ENDIF.
*              UNASSIGN <fs_changeset_req_parent>.
            ENDIF.
          ENDIF.
        WHEN `POSchedule`.
          <fs_changeset_request>-entry_provider->read_entry_data(
                                                   IMPORTING
                                                     es_data = ls_schedule ).

          IF <fs_changeset_request>-content_id IS NOT INITIAL.
            ASSIGN it_changeset_request[ content_id = <fs_changeset_request>-content_id ]
              TO <fs_changeset_req_parent>.
            IF <fs_changeset_req_parent> IS ASSIGNED. "sy-subrc = 0.
*              ASSIGN ct_changeset_response[ operation_no = <fs_changeset_req_parent>-operation_no ]
*                TO <fs_changeset_resp_parent>.
*              IF <fs_changeset_resp_parent> IS ASSIGNED.
*                ASSIGN <fs_changeset_resp_parent>-entity_data->* TO <fs_item>.
*                IF <fs_item>-ebeln IS NOT INITIAL AND <fs_item>-ebelp IS NOT INITIAL.
*              ls_schedule-ebeln = <fs_item>-ebeln.
*              ls_schedule-ebelp = <fs_item>-ebelp.

*                  "create the PO Schedule Line
              poschedule_update_int(
                EXPORTING
                  is_entity = ls_schedule
                IMPORTING
                 er_entity = ls_new_schedule ).

              copy_data_to_ref(
                 EXPORTING
                   is_data = ls_new_item
                 CHANGING
                   cr_data = ls_changeset_response-entity_data ).

              ls_changeset_response-operation_no = <fs_changeset_request>-operation_no.
              INSERT ls_changeset_response INTO TABLE ct_changeset_response.
*                ENDIF.
*                UNASSIGN <fs_changeset_resp_parent>.
*              ENDIF.
*              UNASSIGN <fs_changeset_req_parent>.
            ENDIF.
          ENDIF.
      ENDCASE.
    ENDLOOP.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_deep_entity.
    DATA
      ls_po_poit_posch  TYPE zcl_mm_pur_mpc_ext=>ts_po_poit_posch.

    CLEAR er_deep_entity.
    CASE io_tech_request_context->get_entity_set_name( ).
      WHEN 'POHeadSet'.
        deep_insert_po_items_schedules(
          EXPORTING
            io_data_provider = io_data_provider       " MGW Entry Data Provider
          IMPORTING
            es_po_poit_posch = ls_po_poit_posch ).

        copy_data_to_ref(
          EXPORTING
            is_data = ls_po_poit_posch
          CHANGING
            cr_data = er_deep_entity ).
      WHEN OTHERS.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `907` ).
        MESSAGE e907(zmm). "Just for where-used list

*        super->/iwbep/if_mgw_appl_srv_runtime~create_deep_entity(
*          EXPORTING
*            iv_entity_name          = iv_entity_name
*            iv_entity_set_name      = iv_entity_set_name
*            iv_source_name          = iv_source_name
*            io_data_provider        = io_data_provider
*            it_key_tab              = it_key_tab
*            it_navigation_path      = it_navigation_path
*            io_expand               = io_expand
*            io_tech_request_context = io_tech_request_context
*          IMPORTING
*            er_deep_entity          = er_deep_entity ).
    ENDCASE.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~execute_action.
    DATA:
      ls_string    TYPE zcl_mm_pur_mpc=>ct_longtext,
      ls_entity_po TYPE zcl_mm_pur_mpc=>ts_pohead.

    CASE iv_action_name.
      WHEN 'RegenerateAllData'.
*        action_regeneratealldata(
*          EXPORTING
*            io_tech_request_context = io_tech_request_context
*          IMPORTING
*            er_string               = ls_string ).

        copy_data_to_ref(
          EXPORTING
            is_data = ls_string
          CHANGING
            cr_data = er_data ).
      WHEN 'PO_Cancel' OR 'PO_Confirm' OR
           'PO_GoodsReceiptCreated' OR 'PO_InvoiceCreated'.
        action_po_actions(
          EXPORTING
            io_tech_request_context = io_tech_request_context
          IMPORTING
            er_entity               = ls_entity_po ).

        copy_data_to_ref(
          EXPORTING
            is_data = ls_entity_po
          CHANGING
            cr_data = er_data ).
      WHEN OTHERS.
        TRY.
            super->/iwbep/if_mgw_appl_srv_runtime~execute_action(
              EXPORTING
                iv_action_name          = iv_action_name
                it_parameter            = it_parameter
                io_tech_request_context = io_tech_request_context
              IMPORTING
                er_data                 = er_data ).
          CATCH /iwbep/cx_mgw_busi_exception
                /iwbep/cx_mgw_tech_exception.
        ENDTRY.
    ENDCASE.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_expanded_entity.
    super->/iwbep/if_mgw_appl_srv_runtime~get_expanded_entity(
      EXPORTING
        iv_entity_name           = iv_entity_name
        iv_entity_set_name       = iv_entity_set_name
        iv_source_name           = iv_source_name
        it_key_tab               = it_key_tab
        it_navigation_path       = it_navigation_path
        io_expand                = io_expand
        io_tech_request_context  = io_tech_request_context
      IMPORTING
        er_entity                = er_entity
        es_response_context      = es_response_context
        et_expanded_clauses      = et_expanded_clauses
        et_expanded_tech_clauses = et_expanded_tech_clauses ).
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_expanded_entityset.
    super->/iwbep/if_mgw_appl_srv_runtime~get_expanded_entityset(
      EXPORTING
        iv_entity_name           = iv_entity_name
        iv_entity_set_name       = iv_entity_set_name
        iv_source_name           = iv_source_name
        it_filter_select_options = it_filter_select_options
        it_order                 = it_order
        is_paging                = is_paging
        it_navigation_path       = it_navigation_path
        it_key_tab               = it_key_tab
        iv_filter_string         = iv_filter_string
        iv_search_string         = iv_search_string
        io_expand                = io_expand
        io_tech_request_context  = io_tech_request_context
      IMPORTING
        er_entityset             = er_entityset
        et_expanded_clauses      = et_expanded_clauses
        et_expanded_tech_clauses = et_expanded_tech_clauses
        es_response_context      = es_response_context ).
  ENDMETHOD.


  METHOD action_po_actions.
    TYPES:
      BEGIN OF ts_import_parameter,
        po TYPE ebeln,
      END OF ts_import_parameter.

    DATA:
      ls_parameter_values TYPE ts_import_parameter,

      lv_operation        TYPE scx_attrname.

    io_tech_request_context->get_converted_parameters(
      IMPORTING
        es_parameter_values = ls_parameter_values ).

    CLEAR: er_entity.
    TRY.
*     Convert PO Number into internal GUID.
        lv_operation = 'Purchase Order - Check'.

*     Does the PO exist?
        SELECT SINGLE @abap_true
          FROM ekko
          INTO @DATA(lv_bool)
          WHERE ebeln = @ls_parameter_values-po.
        IF lv_bool = abap_off.
          RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
            EXPORTING
              textid = VALUE scx_t100key( msgid = `ZMM`
                                          msgno = `908`
                                          attr1 = ls_parameter_values-po ).
          MESSAGE e908(zmm).   "Just for where-used list
        ENDIF.

*     Read the Purchase Order
        lv_operation = 'Purchase Order - Retrieve'.
        SELECT SINGLE s~ebeln,
                      s~bsart,
                      s~bedat,
                      s~lifnr,
                      s~aedat,
                      s~frgrl,
                      s~memory,
                      s~memorytype
          FROM ekko AS s
          INTO @DATA(ls_ekko)
          WHERE ebeln = @ls_parameter_values-po.
        IF sy-subrc <> 0.
*          handle_epm_messages( lr_msg_buf ).
        ENDIF.

        CASE io_tech_request_context->get_function_import_name( ).
          WHEN 'PO_Cancel'.
            lv_operation = 'Purchase Order - Action-Cancel'.
*            lr_epm_so->action_cancel(
*              EXPORTING
*                it_node_keys      = lt_node_keys_so
*                ii_message_buffer = lr_msg_buf ).

          WHEN 'PO_Confirm'.
            lv_operation = 'Purchase Order - Action-Confirm'.
*            lr_epm_so->action_confirm(
*              EXPORTING
*                it_node_keys      = lt_node_keys_so
*                ii_message_buffer = lr_msg_buf ).

          WHEN 'PO_GoodsIssueCreated'.
            lv_operation = 'Purchase Order - Action-Goods-Issue-Created'.
*            lr_epm_so->action_goods_issue_created(
*              EXPORTING
*                it_node_keys      = lt_node_keys_so
*                ii_message_buffer = lr_msg_buf ).

          WHEN 'PO_InvoiceCreated'.
            lv_operation = 'Purchase Order - Action-Invoice-Created'.
*            lr_epm_so->action_invoice_created(
*              EXPORTING
*                it_node_keys      = lt_node_keys_so
*                ii_message_buffer = lr_msg_buf ).

          WHEN OTHERS.
            throw_generic_error( ).
        ENDCASE.
*        handle_epm_messages( lr_msg_buf ).

        persist_po_data( ).
        er_entity = po_head_get_entity( iv_po = ls_parameter_values-po ).
*                    CATCH /iwbep/cx_mgw_busi_exception. " Business Exception
*                    CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception

      CATCH cx_epm_api_exception cx_epm_system_exception.
*        handle_epm_exception( lv_epm_operation ).
    ENDTRY.
  ENDMETHOD.


  METHOD add_to_where_clause.
    DATA
      lv_additional_filter TYPE string.

    SPLIT iv_add_filter_field_name AT `,` INTO TABLE DATA(lt_field).
    SPLIT iv_add_filter_field_value AT `,` INTO TABLE DATA(lt_value).

    IF lines( lt_field ) > 1.
      LOOP AT lt_value
        ASSIGNING FIELD-SYMBOL(<fs_value>).
        DATA(lv_field_value) =
          cl_abap_dyn_prg=>quote( val = <fs_value> ).

        ASSIGN lt_field[ sy-tabix ] TO FIELD-SYMBOL(<fs_field>).
        CONCATENATE <fs_field> '=' lv_field_value
          INTO lv_additional_filter SEPARATED BY space.

        IF <fs_field> IS INITIAL.
          rv_where_clause = iv_where_clause.
        ELSE.
          IF iv_where_clause IS INITIAL AND sy-tabix = 1.
            rv_where_clause = lv_additional_filter.
          ELSE.
            IF iv_where_clause IS INITIAL.
              CONCATENATE '(' rv_where_clause ') and' lv_additional_filter INTO rv_where_clause SEPARATED BY space.
            ELSE.
              CONCATENATE '(' iv_where_clause ') and' lv_additional_filter INTO rv_where_clause SEPARATED BY space.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ELSE.
      lv_field_value =
        cl_abap_dyn_prg=>quote( val = iv_add_filter_field_value ).

      CONCATENATE iv_add_filter_field_name '=' lv_field_value
        INTO lv_additional_filter SEPARATED BY space.

      IF iv_add_filter_field_name IS INITIAL.
        rv_where_clause = iv_where_clause.
      ELSE.
        IF iv_where_clause IS INITIAL.
          rv_where_clause = lv_additional_filter.
        ELSE.
          CONCATENATE '(' iv_where_clause ') and' lv_additional_filter INTO rv_where_clause SEPARATED BY space.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD deep_insert_po_items_schedules.
    DATA:
      ls_deep_entity TYPE zcl_mm_pur_mpc_ext=>ts_po_poit_posch,
      ls_po          TYPE zcl_mm_pur_mpc=>ts_pohead,
      ls_item        TYPE zcl_mm_pur_mpc=>ts_poitem,
      ls_schedule    TYPE zcl_mm_pur_mpc=>ts_poschedule,

      lv_operation   TYPE scx_attrname,
      lv_success     TYPE abap_bool.

    io_data_provider->read_entry_data( IMPORTING es_data = ls_deep_entity ).

    CLEAR es_po_poit_posch.
*    TRY.
*        lr_epm_so   ?= cl_epm_service_facade=>get_bo( if_epm_so_header=>gc_bo_name ).
*        lr_epm_soli ?= cl_epm_service_facade=>get_bo( if_epm_so_item=>gc_bo_name ).
*        lr_epm_sl   ?= cl_epm_service_facade=>get_bo( if_epm_so_sl=>gc_bo_name ).
*        lr_msg_buf  ?= cl_epm_service_facade=>get_message_buffer( ).
*
**     Create an empty Sales Order record
*        lv_epm_operation = 'Sales Order - Create'.
*        CALL METHOD lr_epm_so->create
*          EXPORTING
*            ii_message_buffer = lr_msg_buf
*          IMPORTING
*            es_data           = ls_data_so
*            ev_success        = lv_success.
*        handle_epm_messages( lr_msg_buf ).
*
*        IF lv_success EQ abap_true.
*          ls_data_so-currency_code = ls_deep_entity-currency_code.
*
*          lv_epm_operation = 'Sales Order - Set-Note'.
*          CALL METHOD lr_epm_so->set_note
*            EXPORTING
*              iv_node_key       = ls_data_so-node_key
*              iv_text           = ls_deep_entity-note
*              ii_message_buffer = lr_msg_buf
*            IMPORTING
*              ev_success        = lv_success.
*          handle_epm_messages( lr_msg_buf ).
*
*          IF lv_success EQ abap_true.
*            lv_epm_operation = 'Sales Order - Set-Business-Partner-ID'.
*            CALL METHOD lr_epm_so->set_business_partner_id
*              EXPORTING
*                iv_node_key            = ls_data_so-node_key
*                iv_business_partner_id = ls_deep_entity-buyer_id
*                ii_message_buffer      = lr_msg_buf
*              IMPORTING
*                ev_success             = lv_success.
*            handle_epm_messages( lr_msg_buf ).
*
*            IF lv_success EQ abap_true.
*
**           Now process the list of Line Items.
*              LOOP AT ls_deep_entity-tolineitems INTO ls_soli.
*                CLEAR: ls_data_soli, lt_node_keys_soli[], lt_data_sl[].
*
**             Create an empty Sales Order Line Item record
*                lv_epm_operation = 'Sales Order Line Item - Create-By-Parent'.
*                CALL METHOD lr_epm_soli->create_by_parent
*                  EXPORTING
*                    iv_source_node_key = ls_data_so-node_key
*                    ii_message_buffer  = lr_msg_buf
*                  IMPORTING
*                    es_data            = ls_data_soli
*                    ev_success         = lv_success.
*                handle_epm_messages( lr_msg_buf ).
*
*                IF lv_success EQ abap_true.
*                  lv_epm_operation = 'Sales Order Line Item - Set-Product-ID'.
*                  CALL METHOD lr_epm_soli->set_product_id
*                    EXPORTING
*                      iv_node_key       = ls_data_soli-node_key
*                      iv_product_id     = ls_soli-product_id
*                      ii_message_buffer = lr_msg_buf
*                    IMPORTING
*                      ev_success        = lv_success.
*                  handle_epm_messages( lr_msg_buf ).
*
*                  IF lv_success EQ abap_true.
*                    lv_epm_operation = 'Sales Order Line Item - Set-Note'.
*                    CALL METHOD lr_epm_soli->set_note
*                      EXPORTING
*                        iv_node_key       = ls_data_soli-node_key
*                        iv_text           = ls_soli-note
*                        ii_message_buffer = lr_msg_buf
*                      IMPORTING
*                        ev_success        = lv_success.
*                    handle_epm_messages( lr_msg_buf ).
*
*                    IF lv_success EQ abap_true.
*                      APPEND ls_data_soli-node_key TO lt_node_keys_soli.
*
**                   Creation of a line item automatically creates a schedule line. So we need to fetch the new schedule line.
*                      lv_epm_operation = 'Sales Order Line Item - Navigate-To-Schedule-Line'.
*                      CALL METHOD lr_epm_soli->navigate_to_schedule_lines
*                        EXPORTING
*                          it_source_node_keys = lt_node_keys_soli
*                          ii_message_buffer   = lr_msg_buf
*                        IMPORTING
*                          et_data             = lt_data_sl.
*                      handle_epm_messages( lr_msg_buf ).
*
*                      READ TABLE lt_data_sl INDEX 1 ASSIGNING <fs_data_sl>.
*                      IF <fs_data_sl> IS NOT ASSIGNED.
*                        throw_generic_error( ).
*                      ENDIF.
*
*                      <fs_data_sl>-delivery_date = ls_soli-delivery_date.
*                      <fs_data_sl>-quantity      = ls_soli-quantity.
*
*                      lv_epm_operation = 'Sales Order Schedule Line - Update'.
*                      CALL METHOD lr_epm_sl->update
*                        EXPORTING
*                          it_data           = lt_data_sl
*                          ii_message_buffer = lr_msg_buf.
*                      handle_epm_messages( lr_msg_buf ).
*
**                   Keep Item Position to fetch the data after the entire processing
*                      APPEND ls_soli-so_item_pos TO lt_so_item_pos.
*
*                    ELSE.
*                      handle_epm_exec_unsuccessful( 'Sales Order Line Item - Set-Note' ).
*                    ENDIF.
*                  ELSE.
*                    handle_epm_exec_unsuccessful( 'Sales Order Line Item - Set-Product' ).
*                  ENDIF.
*                ELSE.
*                  handle_epm_create_unsuccessful( 'SalesOrderLineItem' ).
*                ENDIF.
*
*              ENDLOOP.
*
*              persist_epm_data( ).
*
*              ls_so = so_get_entity( ls_data_so-so_id ).
*              MOVE-CORRESPONDING ls_so TO es_so_soli.
*
*              LOOP AT lt_so_item_pos INTO lv_item_pos.
*                ls_soli = soli_get_entity( iv_so_id       = ls_data_so-so_id
*                                           iv_so_item_pos = lv_item_pos ).
*                APPEND ls_soli TO es_so_soli-tolineitems.
*              ENDLOOP.
*
*            ELSE.
*              handle_epm_exec_unsuccessful( 'Sales Order - Set-Partner-ID' ).
*            ENDIF.
*
*          ELSE.
*            handle_epm_exec_unsuccessful( 'Sales Order - Set-Note' ).
*          ENDIF.
*        ELSE.
*          handle_epm_create_unsuccessful( 'Sales Order' ).
*        ENDIF.
*
*      CATCH cx_epm_api_exception cx_epm_system_exception.
*        handle_epm_exception( lv_epm_operation ).
*    ENDTRY.
  ENDMETHOD.


  METHOD get_osql_orderby_clause.
    DATA:
      lv_property TYPE string,
      lv_asc_desc TYPE string.

    CLEAR rv_orderby_clause.
    LOOP AT io_tech_request_context->get_orderby( )
      ASSIGNING FIELD-SYMBOL(<fs_orderby>).
      CLEAR lv_property.
      IF <fs_orderby>-property IS NOT INITIAL.
        lv_property = <fs_orderby>-property.
      ELSEIF <fs_orderby>-property_path IS NOT INITIAL.
        lv_property = <fs_orderby>-property_path.
      ENDIF.

      IF <fs_orderby>-order = 'desc'.
        lv_asc_desc = 'DESCENDING'.
      ELSE.
        lv_asc_desc = 'ASCENDING'.
      ENDIF.

      IF lv_property IS NOT INITIAL.
        CONCATENATE rv_orderby_clause lv_property lv_asc_desc
          INTO rv_orderby_clause SEPARATED BY space.
      ENDIF.
    ENDLOOP.
    CONDENSE rv_orderby_clause.
  ENDMETHOD.


  METHOD grheadset_get_entity.
*    TRY.
*        super->grheadset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_grhead.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = gr_get_entity( iv_gr = ls_converted_keys-mblnr
                                 iv_year = CONV mjahr( ls_converted_keys-mjahr ) ).
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD grheadset_get_entityset.
*    TRY.
*        super->grheadset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      gr_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD gritemset_get_entity.
*    TRY.
*        super->gritemset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA:
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_gritem.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = gr_item_get_entity( iv_gr      = ls_converted_keys-ebeln
                                      iv_year    = CONV mjahr( ls_converted_keys-mjahr )
                                      iv_gr_item = CONV mblpo( ls_converted_keys-zeile ) ).
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD gritemset_get_entityset.
*    TRY.
*        super->gritemset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      gr_item_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD gr_conv_proper_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF `MBLNR` IN rv_string WITH `m~MBLNR`.
    REPLACE ALL OCCURRENCES OF `MJAHR` IN rv_string WITH `m~MJAHR`.
    REPLACE ALL OCCURRENCES OF `BUDAT` IN rv_string WITH `m~BUDAT`.
    REPLACE ALL OCCURRENCES OF `XBLNR` IN rv_string WITH `m~XBLNR`.
  ENDMETHOD.


  METHOD gr_get_entity.
    DATA:
      lv_messg TYPE string.

* During changeset processing ($batch) we can not perform a direct select as
* the DB tables are not updated.
    IF mv_changeset_active EQ abap_false.
      SELECT SINGLE
        m~mblnr,
        m~mjahr,
        m~budat,
        m~xblnr
        INTO @DATA(ls_mkpf)  "er_entity
        FROM mkpf AS m
          INNER JOIN ekbe AS o
            ON o~vgabe = `1`
           AND o~gjahr = m~mjahr
           AND o~belnr = m~mblnr
*           AND o~buzei = ''
        WHERE mblnr = @iv_gr
          AND mjahr = @iv_year.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `902`
                                        attr1 = iv_gr ).
        MESSAGE e902(zmm) INTO lv_messg.
      ENDIF.

      er_entity-mblnr = ls_mkpf-mblnr.
      er_entity-mjahr = ls_mkpf-mjahr.
      CONVERT DATE ls_mkpf-budat
        TIME gc_time
        INTO TIME STAMP er_entity-budat
        TIME ZONE sy-zonlo.
      er_entity-xblnr = ls_mkpf-xblnr.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD gr_get_entityset.
    DATA:
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = gr_conv_proper_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = gr_conv_proper_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
*    IF lv_where_clause CS 'NOTE' OR lv_where_clause CS 'DESCRIPTION'.
*      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
*        EXPORTING
*          textid = VALUE scx_t100key( msgid = `ZMM`
*                                      msgno = `904` ).
*      MESSAGE e904(zmm) INTO lv_messg.
*    ENDIF.
*
*    IF lv_orderby_clause CS 'NOTE' OR lv_orderby_clause CS 'DESCRIPTION'.
*      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
*        EXPORTING
*          textid = VALUE scx_t100key( msgid = `ZMM`
*                                      msgno = `905` ).
*      MESSAGE e905(zmm) INTO lv_messg.
*    ENDIF.

    lv_where_clause =
      add_to_where_clause( iv_where_clause           = lv_where_clause
                           iv_add_filter_field_name  = iv_add_filter_field_name
                           iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 'm~MBLNR, m~MJAHR'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
            INTO (lv_count)
            FROM ( mkpf AS m
              INNER JOIN ekbe AS o
                ON o~vgabe = `1`
               AND o~gjahr = m~mjahr
               AND o~belnr = m~mblnr )
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              INTO (lv_count)
              FROM ( mkpf AS m
              INNER JOIN ekbe AS o
                ON o~vgabe = `1`
               AND o~gjahr = m~mjahr
               AND o~belnr = m~mblnr )
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT m~mblnr, m~mjahr, m~budat, m~xblnr
            FROM ( mkpf AS m
              INNER JOIN ekbe AS o
                ON o~vgabe = `1`
               AND o~gjahr = m~mjahr
               AND o~belnr = m~mblnr )
              INTO TABLE @DATA(lt_mkpf)
              UP TO @lv_maxrows ROWS
              WHERE (lv_where_clause).
*              ORDER BY (lv_orderby_clause).
          IF ( sy-dbcnt > lv_skip ).
            LOOP AT lt_mkpf
              ASSIGNING FIELD-SYMBOL(<fs_mkpf>).
              APPEND INITIAL LINE TO et_entityset
                ASSIGNING FIELD-SYMBOL(<fs_entity>).
              <fs_entity>-mblnr = <fs_mkpf>-mblnr.
              <fs_entity>-mjahr = <fs_mkpf>-mjahr.
              CONVERT DATE <fs_mkpf>-budat
                TIME gc_time
                INTO TIME STAMP <fs_entity>-budat
                TIME ZONE sy-zonlo.
              <fs_entity>-xblnr = <fs_mkpf>-xblnr.
            ENDLOOP.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount EQ abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `POHeadSet` ).
        MESSAGE e906(zmm) ##MG_MISSING.   "Just for where-used list
    ENDTRY.
  ENDMETHOD.


  METHOD gr_item_conv_proper_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF `MBLNR` IN rv_string WITH `n~MBLNR`.
    REPLACE ALL OCCURRENCES OF `MJAHR` IN rv_string WITH `n~MJAHR`.
    REPLACE ALL OCCURRENCES OF `ZEILE` IN rv_string WITH `n~ZEILE`.
    REPLACE ALL OCCURRENCES OF `BWART` IN rv_string WITH `n~BWART`.
    REPLACE ALL OCCURRENCES OF `MENGE` IN rv_string WITH `n~MENGE`.
    REPLACE ALL OCCURRENCES OF `MEINS` IN rv_string WITH `n~MEINS`.
    REPLACE ALL OCCURRENCES OF `SHKZG` IN rv_string WITH `n~SHKZG`.
    REPLACE ALL OCCURRENCES OF `MATNR` IN rv_string WITH `n~MATNR`.
    REPLACE ALL OCCURRENCES OF `WERKS` IN rv_string WITH `n~WERKS`.
    REPLACE ALL OCCURRENCES OF `LIFNR` IN rv_string WITH `n~LIFNR`.
    REPLACE ALL OCCURRENCES OF `EBELN` IN rv_string WITH `n~EBELN`.
    REPLACE ALL OCCURRENCES OF `EBELP` IN rv_string WITH `n~EBELP`.
  ENDMETHOD.


  METHOD gr_item_get_entity.
    DATA:
          lv_messg TYPE string.

    IF mv_changeset_active = abap_false.
      SELECT SINGLE n~mblnr, n~mjahr, n~zeile, n~bwart, n~menge,
                    n~meins, n~shkzg, n~matnr, n~werks, n~lifnr,
                    n~ebeln, n~ebelp
        FROM ( mseg AS n
                   INNER JOIN mkpf AS m
                     ON n~mblnr = m~mblnr
                    AND n~mjahr = m~mjahr
                   INNER JOIN ekbe AS h
                     ON n~ebeln = h~ebeln
                    AND n~ebelp = h~ebelp
                    AND h~vgabe = `1`
                    AND n~mjahr = h~gjahr
                    AND n~mblnr = h~belnr
                    AND n~zeile = h~buzei )
        INTO ( @er_entity-mblnr, @er_entity-mjahr, @er_entity-zeile, @er_entity-bwart, @er_entity-menge,
               @er_entity-meins, @er_entity-shkzg, @er_entity-matnr, @er_entity-werks, @er_entity-lifnr,
               @er_entity-ebeln, @er_entity-ebelp )
        WHERE n~mblnr = @iv_gr
          AND n~mjahr = @iv_year
          AND n~zeile = @iv_gr_item.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `903`
                                        attr1 = iv_gr
                                        attr2 = iv_gr_item ).
        MESSAGE e903(zmm) INTO lv_messg.
      ENDIF.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD gr_item_get_entityset.
    DATA:
      ls_entity          TYPE zcl_mm_pur_mpc=>ts_gritem,
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = gr_item_conv_proper_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = gr_item_conv_proper_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS 'MENGE'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS 'MENGE'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause =
      add_to_where_clause( iv_where_clause           = lv_where_clause
                           iv_add_filter_field_name  = iv_add_filter_field_name
                           iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 'n~MBLNR, n~MJAHR, n~ZEILE'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
            INTO (lv_count)
            FROM ( mseg AS n
              INNER JOIN mkpf AS m
                ON n~mblnr = m~mblnr
               AND n~mjahr = m~mjahr
              INNER JOIN ekbe AS o
                ON n~ebeln = o~ebeln
               AND n~ebelp = o~ebelp
               AND o~vgabe = `1`
               AND n~mjahr = o~gjahr
               AND n~mblnr = o~belnr
               AND n~zeile = o~buzei )
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              INTO (lv_count)
              FROM ( mseg AS n
                INNER JOIN mkpf AS m
                  ON n~mblnr = m~mblnr
                 AND n~mjahr = m~mjahr
                INNER JOIN ekbe AS o
                  ON n~ebeln = o~ebeln
                 AND n~ebelp = o~ebelp
                 AND o~vgabe = `1`
                 AND n~mjahr = o~gjahr
                 AND n~mblnr = o~belnr
                 AND n~zeile = o~buzei )
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT n~mblnr, n~mjahr, n~zeile, n~bwart, n~menge,
                 n~meins, n~shkzg, n~matnr, n~werks, n~lifnr,
                 n~ebeln, n~ebelp
            FROM ( mseg AS n
              INNER JOIN mkpf AS m
                ON n~mblnr = m~mblnr
               AND n~mjahr = m~mjahr
              INNER JOIN ekbe AS h
                ON n~ebeln = h~ebeln
               AND n~ebelp = h~ebelp
               AND h~vgabe = `1`
               AND n~mjahr = h~gjahr
               AND n~mblnr = h~belnr
               AND n~zeile = h~buzei )
               INTO TABLE @DATA(lt_mseg)
                    UP TO @lv_maxrows ROWS
                    WHERE (lv_where_clause).
*               ORDER BY (lv_orderby_clause).
          IF ( sy-dbcnt > lv_skip ).
            LOOP AT lt_mseg
              ASSIGNING FIELD-SYMBOL(<fs_mseg>).
              APPEND INITIAL LINE TO et_entityset
                ASSIGNING FIELD-SYMBOL(<fs_entityset>).
              <fs_entityset>-mblnr = <fs_mseg>-mblnr.
              <fs_entityset>-mjahr = <fs_mseg>-mjahr.
              <fs_entityset>-zeile = <fs_mseg>-zeile.
              <fs_entityset>-bwart = <fs_mseg>-bwart.
              <fs_entityset>-menge = <fs_mseg>-menge.
              <fs_entityset>-meins = <fs_mseg>-meins.
              <fs_entityset>-shkzg = <fs_mseg>-shkzg.
              <fs_entityset>-matnr = <fs_mseg>-matnr.
              <fs_entityset>-werks = <fs_mseg>-werks.
              <fs_entityset>-lifnr = <fs_mseg>-lifnr.
              <fs_entityset>-ebeln = <fs_mseg>-ebeln.
              <fs_entityset>-ebelp = <fs_mseg>-ebelp.
            ENDLOOP.
*           APPEND ls_soli_helper TO lt_soli_helper.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `POItemSet` ).
        MESSAGE e906(zmm) INTO lv_messg.
    ENDTRY.
  ENDMETHOD.


  METHOD materialset_get_entity.
*    TRY.
*        super->materialset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_material.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = material_get_entity( iv_materialno = ls_converted_keys-matnr ).
*                  CATCH /iwbep/cx_mgw_busi_exception. " Business Exception
*                  CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD materialset_get_entityset.
*    TRY.
*        super->materialset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      material_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD material_conv_proper_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF 'MATNR' IN rv_string WITH `p~MATNR`.
    REPLACE ALL OCCURRENCES OF 'MAKTX' IN rv_string WITH `x~MAKTX`.
    REPLACE ALL OCCURRENCES OF 'MEINS' IN rv_string WITH `p~MEINS`.
    REPLACE ALL OCCURRENCES OF 'UMREZ' IN rv_string WITH `u~UMREZ`.
    REPLACE ALL OCCURRENCES OF 'UMREN' IN rv_string WITH `u~UMREN`.
  ENDMETHOD.


  METHOD material_get_entity.
    DATA
      lv_operation TYPE scx_attrname.

* During changeset processing ($batch) we can not perform a direct select as
* the DB tables are not updated.
    IF mv_changeset_active EQ abap_false.
      SELECT SINGLE
        p~matnr,
        x~maktx,
        p~meins,
        u~umrez,
        u~umren
        FROM ( ( mara AS p
                   LEFT OUTER JOIN makt AS x
                     ON x~matnr = p~matnr
                    AND x~spras = @sy-langu )
                   LEFT OUTER JOIN marm AS u
                     ON u~matnr = p~matnr
                    AND u~meinh = p~meins )
        INTO ( @er_entity-matnr,
               @er_entity-maktx,
               @er_entity-meins,
               @er_entity-umrez,
               @er_entity-umren )
        WHERE p~matnr = @iv_materialno.
      IF sy-subrc <> 0.
*        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
*          EXPORTING
*            textid = VALUE scx_t100key( msgid = `ZMM`
*                                        msgno = `909`
*                                        attr1 = iv_materialno ).
*        MESSAGE e909(zmm).   "Just for where-used list
      ENDIF.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD material_get_entityset.
    DATA:
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = material_conv_proper_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = material_conv_proper_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS 'MAKTX' OR lv_where_clause CS 'UMREZ' OR lv_where_clause CS 'UMREN'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS 'MAKTX' OR lv_where_clause CS 'UMREZ' OR lv_where_clause CS 'UMREN'..
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause = add_to_where_clause(
                      iv_where_clause           = lv_where_clause
                      iv_add_filter_field_name  = iv_add_filter_field_name
                      iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 'p~MATNR'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
                 FROM ( ( mara AS p
                   LEFT OUTER JOIN makt AS x
                     ON x~matnr = p~matnr
                    AND x~spras = @sy-langu )
                   LEFT OUTER JOIN marm AS u
                     ON u~matnr = p~matnr
                    AND u~meinh = p~meins )
            INTO (@lv_count)
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              FROM ( ( mara AS p
                LEFT OUTER JOIN makt AS x
                  ON x~matnr = p~matnr
                 AND x~spras = @sy-langu )
                LEFT OUTER JOIN marm AS u
                  ON u~matnr = p~matnr
                 AND u~meinh = p~meins )
              INTO (@lv_count)
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT
            p~matnr,
            x~maktx,
            p~meins,
            u~umrez,
            u~umren
            FROM ( ( mara AS p
                LEFT OUTER JOIN makt AS x
                  ON x~matnr = p~matnr
                 AND x~spras = @sy-langu )
                LEFT OUTER JOIN marm AS u
                  ON u~matnr = p~matnr
                 AND u~meinh = p~meins )
            INTO TABLE @et_entityset
            UP TO @lv_maxrows ROWS
            WHERE (lv_where_clause)
            ORDER BY (lv_orderby_clause).
          IF ( sy-dbcnt > lv_skip ).
*            LOOP AT lt_lfa1
*              ASSIGNING FIELD-SYMBOL(<fs_lfa1>).
*              APPEND INITIAL LINE TO et_entityset
*                ASSIGNING FIELD-SYMBOL(<fs_entity>).
*              <fs_entity>-lifnr = <fs_lfa1>-lifnr.
*              <fs_entity>-name1 = <fs_lfa1>-name1.
**              <fs_entity>-waers = <fs_lfa1>-
*              <fs_entity>-land1 = <fs_lfa1>-land1.
*              <fs_entity>-spras = <fs_lfa1>-spras.
*            ENDLOOP.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount EQ abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `PlantSet` ).
        MESSAGE e906(zmm) ##MG_MISSING.   "Just for where-used list
    ENDTRY.
  ENDMETHOD.


  METHOD partnerset_get_entity.
*    TRY.
*        super->partnerset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_partner.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = partner_get_entity( iv_partnerno = ls_converted_keys-lifnr ).
*                  CATCH /iwbep/cx_mgw_busi_exception. " Business Exception
*                  CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception.
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD partnerset_get_entityset.
*    TRY.
*        super->partnerset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      partner_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD partner_conv_properties_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF 'LIFNR' IN rv_string WITH 'b~LIFNR'.
    REPLACE ALL OCCURRENCES OF 'NAME1' IN rv_string WITH 'b~NAME1'.
    REPLACE ALL OCCURRENCES OF 'WAERS' IN rv_string WITH 'f~WAERS'.
    REPLACE ALL OCCURRENCES OF 'LAND1' IN rv_string WITH 'b~LAND1'.
    REPLACE ALL OCCURRENCES OF 'SPRAS' IN rv_string WITH 'b~SPRAS'.
  ENDMETHOD.


  METHOD partner_get_entity.
    DATA
      lv_operation TYPE scx_attrname.

* During changeset processing ($batch) we can not perform a direct select as
* the DB tables are not updated.
    IF mv_changeset_active EQ abap_false.
      SELECT SINGLE
        b~lifnr,
        b~name1,
        f~waers,
        b~land1,
        b~spras
        FROM ( lfa1 AS b
          LEFT OUTER JOIN lfm1 AS f
            ON b~lifnr = f~lifnr )
        INTO ( @er_entity-lifnr,
               @er_entity-name1,
               @er_entity-waers,
               @er_entity-land1,
               @er_entity-spras )
        WHERE b~lifnr = @iv_partnerno.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `909`
                                        attr1 = iv_partnerno ).
        MESSAGE e909(zmm).   "Just for where-used list
      ENDIF.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD partner_get_entityset.
    DATA:
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = partner_conv_properties_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = partner_conv_properties_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS 'NAME1'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS 'NAME1'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause =
      add_to_where_clause( iv_where_clause           = lv_where_clause
                           iv_add_filter_field_name  = iv_add_filter_field_name
                           iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 'b~LIFNR'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
            FROM ( lfa1 AS b
              LEFT OUTER JOIN lfm1 AS f
                ON b~lifnr = f~lifnr )
            INTO (lv_count)
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              FROM ( lfa1 AS b
                LEFT OUTER JOIN lfm1 AS f
                  ON b~lifnr = f~lifnr )
              INTO (lv_count)
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT
            b~lifnr,
            b~name1,
            f~waers,
            b~land1,
            b~spras
            INTO TABLE @et_entityset  "DATA(lt_lfa1)
            FROM ( lfa1 AS b
              LEFT OUTER JOIN lfm1 AS f
                ON f~lifnr = b~lifnr )
            UP TO @lv_maxrows ROWS
            WHERE (lv_where_clause)
            ORDER BY (lv_orderby_clause).
          IF ( sy-dbcnt > lv_skip ).
*            LOOP AT lt_lfa1
*              ASSIGNING FIELD-SYMBOL(<fs_lfa1>).
*              APPEND INITIAL LINE TO et_entityset
*                ASSIGNING FIELD-SYMBOL(<fs_entity>).
*              <fs_entity>-lifnr = <fs_lfa1>-lifnr.
*              <fs_entity>-name1 = <fs_lfa1>-name1.
*              <fs_entity>-waers = <fs_lfa1>-waers.
*              <fs_entity>-land1 = <fs_lfa1>-land1.
*              <fs_entity>-spras = <fs_lfa1>-spras.
*            ENDLOOP.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount EQ abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `PlantSet` ).
        MESSAGE e906(zmm) ##MG_MISSING.   "Just for where-used list
    ENDTRY.
  ENDMETHOD.


  METHOD persist_po_data.
  ENDMETHOD.


  METHOD plantset_get_entity.
*    TRY.
*        super->plantset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_plant.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = plant_get_entity( iv_plantcode = ls_converted_keys-werks ).
*                  CATCH /iwbep/cx_mgw_busi_exception. " Business Exception
*                  CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD plantset_get_entityset.
*    TRY.
*        super->plantset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      plant_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD plant_conv_properties_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF 'WERKS' IN rv_string WITH 'c~WERKS'.
    REPLACE ALL OCCURRENCES OF 'NAME1' IN rv_string WITH 'c~NAME1'.
  ENDMETHOD.


  METHOD plant_get_entity.
    DATA
      lv_operation TYPE scx_attrname.

* During changeset processing ($batch) we can not perform a direct select as
* the DB tables are not updated.
    IF mv_changeset_active EQ abap_false.
      SELECT SINGLE
        c~werks,
        c~name1
        FROM t001w AS c
        INTO @er_entity
        WHERE werks = @iv_plantcode.
      IF sy-subrc <> 0.
*        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
*          EXPORTING
*            textid = VALUE scx_t100key( msgid = `ZMM`
*                                        msgno = `909`
*                                        attr1 = iv_plantcode ).
*        MESSAGE e909(zmm).   "Just for where-used list
      ENDIF.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD plant_get_entityset.
    DATA:
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = plant_conv_properties_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = plant_conv_properties_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS 'NAME1'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS 'NAME1'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause = add_to_where_clause(
                      iv_where_clause           = lv_where_clause
                      iv_add_filter_field_name  = iv_add_filter_field_name
                      iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 'c~WERKS'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
            FROM t001w AS c
            INTO (lv_count) BYPASSING BUFFER
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              FROM t001w AS c
              INTO (lv_count) BYPASSING BUFFER
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT
            c~werks,
            c~name1
            INTO TABLE @et_entityset
            FROM t001w AS c
            UP TO @lv_maxrows ROWS
            WHERE (lv_where_clause)
            ORDER BY (lv_orderby_clause).
          IF ( sy-dbcnt > lv_skip ).
*            LOOP AT lt_t001w
*              ASSIGNING FIELD-SYMBOL(<fs_t001w>).
*              APPEND INITIAL LINE TO et_entityset
*                ASSIGNING FIELD-SYMBOL(<fs_entity>).
*              <fs_entity>-werks = <fs_t001w>-werks.
*              <fs_entity>-name1 = <fs_t001w>-name1.
*            ENDLOOP.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount EQ abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `PlantSet` ).
        MESSAGE e906(zmm) ##MG_MISSING.   "Just for where-used list
    ENDTRY.
  ENDMETHOD.


  METHOD poheadset_get_entity.
*    TRY.
*        super->poheadset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_pohead.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = po_head_get_entity( iv_po = ls_converted_keys-ebeln ).
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD poheadset_get_entityset.
*    TRY.
*        super->poheadset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      po_head_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD poitemset_get_entity.
*    TRY.
*        super->poitemset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA:
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_poitem.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = po_item_get_entity( iv_po      = ls_converted_keys-ebeln
                                      iv_po_item = CONV ebelp( ls_converted_keys-ebelp ) ).
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD poitemset_get_entityset.
*    TRY.
*        super->poitemset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      po_item_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD poitemset_update_entity.
*    super->poitemset_update_entity(
*      EXPORTING
*        iv_entity_name          = iv_entity_name
*        iv_entity_set_name      = iv_entity_set_name
*        iv_source_name          = iv_source_name
*        it_key_tab              = it_key_tab
*        io_tech_request_context = io_tech_request_context
*        it_navigation_path      = it_navigation_path
*        io_data_provider        = io_data_provider
*      IMPORTING
*        er_entity               = er_entity ).

    DATA:
      ls_entity TYPE zcl_mm_pur_mpc=>ts_poitem.

    TRY.
        io_data_provider->read_entry_data(
          IMPORTING
            es_data = ls_entity ).
      CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception
    ENDTRY.

    poitem_update_int(
      EXPORTING
        is_entity = ls_entity
      IMPORTING
        er_entity = er_entity ).
*    CATCH /iwbep/cx_mgw_busi_exception. " Business Exception
*    CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception
  ENDMETHOD.


  METHOD poitem_update_int.
    DATA:
      lt_item   TYPE bapimepoitem_tp,
      lt_itemx  TYPE bapimepoitemx_tp,
      lt_return TYPE bapiret2_t.

    APPEND INITIAL LINE TO lt_item
      ASSIGNING FIELD-SYMBOL(<fs_item>).
    <fs_item>-po_item = is_entity-ebelp.
    <fs_item>-net_price = is_entity-netpr.
    <fs_item>-acknowl_no = is_entity-labnr.

    APPEND INITIAL LINE TO lt_itemx
      ASSIGNING FIELD-SYMBOL(<fs_itemx>).
    <fs_itemx>-po_item = is_entity-ebelp.
    <fs_itemx>-po_itemx = abap_on.
    <fs_itemx>-net_price = abap_on.
    <fs_itemx>-acknowl_no = abap_on.

    CALL FUNCTION 'BAPI_PO_CHANGE'
      EXPORTING
        purchaseorder = is_entity-ebeln
        testrun       = space
      TABLES
        return        = lt_return
        poitem        = lt_item
        poitemx       = lt_itemx.
    IF lines( lt_return ) > 0.
      LOOP AT lt_return
        TRANSPORTING NO FIELDS
          WHERE type NA `EAX`.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = abap_on.
        er_entity = is_entity.
        EXIT.
      ENDLOOP.

      LOOP AT lt_return
        TRANSPORTING NO FIELDS
          WHERE type CA `EAX`.
        mo_context->get_message_container( )->add_messages_from_bapi(
          EXPORTING
            it_bapi_messages          = lt_return                  " Return parameter table
*            iv_error_category         =                  " Error Category
*            iv_determine_leading_msg  =                  " Use no/first/last as leading message
            iv_entity_type            = `POItem`                 " Entity type/name
            it_key_tab                = VALUE /iwbep/t_mgw_name_value_pair( ( name = `OrderNo`
                                                                              value = er_entity-ebeln )
                                                                            ( name = `ItemNo`
                                                                              value = er_entity-ebelp ) )                 " Entity key as name-value pair
            iv_add_to_response_header = abap_false ).      " Flag for adding or not the message to the response header

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid            = /iwbep/cx_mgw_busi_exception=>business_error
*           previous          =
            message_container = mo_context->get_message_container( )
            http_status_code  = /iwbep/cx_mgw_busi_exception=>gcs_http_status_codes-bad_request
*           http_header_parameters =
*           sap_note_id       =
*           msg_code          =
            entity_type       = `POItem`
*           message           =
*           message_unlimited =
*           filter_param      =
*           operation_no      =
          .

      ENDLOOP.
    ENDIF.
  ENDMETHOD.


  METHOD poscheduleset_get_entity.
*    TRY.
*        super->poitemset_get_entity(
*          EXPORTING
*            iv_entity_name     = iv_entity_name
*            iv_entity_set_name = iv_entity_set_name
*            iv_source_name     = iv_source_name
*            it_key_tab         = it_key_tab
**            io_request_object  = io_request_object
**            io_tech_request_context = io_tech_request_context
*            it_navigation_path = it_navigation_path
*      IMPORTING
*           er_entity          = er_entity
*           es_response_context     = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    DATA:
      ls_converted_keys         TYPE zcl_mm_pur_mpc=>ts_poschedule.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      io_tech_request_context->get_converted_keys(
        IMPORTING
          es_key_values = ls_converted_keys ).

      er_entity = po_item_sch_get_entity( iv_po      = ls_converted_keys-ebeln
                                          iv_po_item = CONV ebelp( ls_converted_keys-ebelp )
                                          iv_po_item_schln = CONV etenr( ls_converted_keys-etenr ) ).
    ELSE.
      resolve_navigation_path(
         EXPORTING
           io_tech_request_ctx_entity = io_tech_request_context
         IMPORTING
           er_result                  = er_entity ).
    ENDIF.
  ENDMETHOD.


  METHOD poscheduleset_get_entityset.
*    TRY.
*        super->poscheduleset_get_entityset(
*          EXPORTING
*            iv_entity_name           = iv_entity_name
*            iv_entity_set_name       = iv_entity_set_name
*            iv_source_name           = iv_source_name
*            it_filter_select_options = it_filter_select_options
*            is_paging                = is_paging
*            it_key_tab               = it_key_tab
*            it_navigation_path       = it_navigation_path
*            it_order                 = it_order
*            iv_filter_string         = iv_filter_string
*            iv_search_string         = iv_search_string
*            io_tech_request_context  = io_tech_request_context
*          IMPORTING
*            et_entityset             = et_entityset
*            es_response_context      = es_response_context ).
*      CATCH /iwbep/cx_mgw_busi_exception
*            /iwbep/cx_mgw_tech_exception .
*    ENDTRY.

    IF io_tech_request_context->get_source_entity_set_name( ) IS INITIAL.
      po_item_sch_get_entityset(
        EXPORTING
          io_tech_request_context = io_tech_request_context
        IMPORTING
          et_entityset            = et_entityset
          es_response_context     = es_response_context ).
    ELSE.
      resolve_navigation_path(
        EXPORTING
          io_tech_request_ctx_entityset = io_tech_request_context
        IMPORTING
          er_result                     = et_entityset
          es_response_context           = es_response_context ).
    ENDIF.
  ENDMETHOD.


  METHOD poscheduleset_update_entity.
*    super->poscheduleset_update_entity(
*      EXPORTING
*        iv_entity_name          = iv_entity_name
*        iv_entity_set_name      = iv_entity_set_name
*        iv_source_name          = iv_source_name
*        it_key_tab              = it_key_tab
*        io_tech_request_context = io_tech_request_context
*        it_navigation_path      = it_navigation_path
*        io_data_provider        = io_data_provider
*      IMPORTING
*        er_entity               = er_entity ).

    DATA:
      ls_entity TYPE zcl_mm_pur_mpc=>ts_poschedule.

    TRY.
        io_data_provider->read_entry_data(
          IMPORTING
            es_data = ls_entity ).
      CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception
    ENDTRY.

    poschedule_update_int(
      EXPORTING
        is_entity = ls_entity
      IMPORTING
        er_entity = er_entity ).
*    CATCH /iwbep/cx_mgw_busi_exception. " Business Exception
*    CATCH /iwbep/cx_mgw_tech_exception. " Technical Exception
  ENDMETHOD.


  METHOD poschedule_update_int.
    DATA:
      lt_schedule  TYPE bapimeposchedule_tp,
      lt_schedulex TYPE bapimeposchedulx_tp,
      lt_return    TYPE bapiret2_t.

    APPEND INITIAL LINE TO lt_schedule
      ASSIGNING FIELD-SYMBOL(<fs_schedule>).
    <fs_schedule>-po_item = is_entity-ebelp.
    <fs_schedule>-sched_line = is_entity-etenr.
    CONVERT TIME STAMP is_entity-eindt
      TIME ZONE sy-zonlo
      INTO DATE <fs_schedule>-delivery_date
      TIME DATA(lv_time).

    APPEND INITIAL LINE TO lt_schedulex
      ASSIGNING FIELD-SYMBOL(<fs_schedulex>).
    <fs_schedulex>-po_item = is_entity-ebelp.
    <fs_schedulex>-sched_line = is_entity-etenr.
    <fs_schedulex>-po_itemx = abap_on.
    <fs_schedulex>-sched_linex = abap_on.
    <fs_schedulex>-delivery_date = abap_on.

    CALL FUNCTION 'BAPI_PO_CHANGE'
      EXPORTING
        purchaseorder = is_entity-ebeln
        testrun       = space
      TABLES
        return        = lt_return
        poschedule    = lt_schedule
        poschedulex   = lt_schedulex.
    IF lines( lt_return ) > 0.
      LOOP AT lt_return
        TRANSPORTING NO FIELDS
          WHERE type NA `EAX`.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = abap_on.
        er_entity = is_entity.
        EXIT.
      ENDLOOP.

      LOOP AT lt_return
        TRANSPORTING NO FIELDS
          WHERE type CA `EAX`.
        mo_context->get_message_container( )->add_messages_from_bapi(
          EXPORTING
            it_bapi_messages          = lt_return                  " Return parameter table
*        iv_error_category         =                  " Error Category
*        iv_determine_leading_msg  =                  " Use no/first/last as leading message
            iv_entity_type            = `POSchedule`                 " Entity type/name
            it_key_tab                = VALUE /iwbep/t_mgw_name_value_pair( ( name = `OrderNo`
                                                                              value = er_entity-ebeln )
                                                                            ( name = `ItemNo`
                                                                              value = er_entity-ebelp )
                                                                            ( name = `ScheduleLine`
                                                                              value = er_entity-etenr ) )                 " Entity key as name-value pair
            iv_add_to_response_header = abap_false ).      " Flag for adding or not the message to the response header

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid            = /iwbep/cx_mgw_busi_exception=>business_error
*           previous          =
            message_container = mo_context->get_message_container( )
            http_status_code  = /iwbep/cx_mgw_busi_exception=>gcs_http_status_codes-bad_request
*           http_header_parameters =
*           sap_note_id       =
*           msg_code          =
            entity_type       = `POSchedule`
*           message           =
*           message_unlimited =
*           filter_param      =
*           operation_no      =
          .

      ENDLOOP.
    ENDIF.
  ENDMETHOD.


  METHOD po_head_conv_properties_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF `EBELN` IN rv_string WITH `s~EBELN`.
    REPLACE ALL OCCURRENCES OF `BSART` IN rv_string WITH `s~BSART`.
    REPLACE ALL OCCURRENCES OF `EKGRP` IN rv_string WITH `s~EKGRP`.
    REPLACE ALL OCCURRENCES OF `BEDAT` IN rv_string WITH `s~BEDAT`.
    REPLACE ALL OCCURRENCES OF `LIFNR` IN rv_string WITH `s~LIFNR`.
    REPLACE ALL OCCURRENCES OF `ERNAM` IN rv_string WITH `s~ERNAM`.
    REPLACE ALL OCCURRENCES OF `ERDAT` IN rv_string WITH `s~AEDAT`.
    REPLACE ALL OCCURRENCES OF `FRGRL` IN rv_string WITH `s~FRGRL`.
    REPLACE ALL OCCURRENCES OF `MEMORY` IN rv_string WITH `s~MEMORY`.
    REPLACE ALL OCCURRENCES OF `MEMORYTYPE` IN rv_string WITH `s~MEMORYTYPE`.
  ENDMETHOD.


  METHOD po_head_get_entity.
    DATA:
      lv_messg TYPE string.

* During changeset processing ($batch) we can not perform a direct select as
* the DB tables are not updated.
    IF mv_changeset_active EQ abap_false.
      SELECT SINGLE
        s~ebeln,
        s~bsart,
        s~ekgrp,
        s~bedat,
        s~lifnr,
        s~ernam,
        s~aedat,  "erdat,
        s~frgrl,
        s~memory,
        s~memorytype
        INTO @DATA(ls_ekko)  "er_entity
        FROM ekko AS s
        WHERE ebeln = @iv_po.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `902`
                                        attr1 = iv_po ).
        MESSAGE e902(zmm) INTO lv_messg.
      ENDIF.

      er_entity-ebeln = ls_ekko-ebeln.
      er_entity-bsart = ls_ekko-bsart.
      er_entity-ekgrp = ls_ekko-ekgrp.
      CONVERT DATE ls_ekko-bedat
        TIME gc_time
        INTO TIME STAMP er_entity-bedat
        TIME ZONE sy-zonlo.
      er_entity-ebeln = ls_ekko-ebeln.
      er_entity-lifnr = ls_ekko-lifnr.
      er_entity-ernam = ls_ekko-ernam.
      CONVERT DATE ls_ekko-aedat
        TIME gc_time
        INTO TIME STAMP er_entity-aedat
        TIME ZONE sy-zonlo.
      er_entity-frgrl = ls_ekko-frgrl.
      er_entity-memory = ls_ekko-memory.
      er_entity-memorytype = ls_ekko-memorytype.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD po_head_get_entityset.
    DATA:
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = po_head_conv_properties_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = po_head_conv_properties_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS 'NOTE' OR lv_where_clause CS 'DESCRIPTION'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS 'NOTE' OR lv_orderby_clause CS 'DESCRIPTION'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause = add_to_where_clause(
                      iv_where_clause           = lv_where_clause
                      iv_add_filter_field_name  = iv_add_filter_field_name
                      iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 's~EBELN'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
            INTO (lv_count)
            FROM ekko AS s
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              INTO (lv_count)
              FROM ekko AS s
*                INNER JOIN lfa1 AS b
*                  ON s~lifnr = b~lifnr
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT
            s~ebeln,
            s~bsart,
            s~ekgrp,
            s~bedat,
            s~lifnr,
            s~ernam,
            s~aedat,  "erdat,
            s~frgrl,
            s~memory,
            s~memorytype
            FROM ekko AS s
*              INNER JOIN lfa1 AS b
*                ON s~lifnr = b~lifnr
            INTO TABLE @DATA(lt_ekko)
            UP TO @lv_maxrows ROWS
            WHERE (lv_where_clause)
            ORDER BY (lv_orderby_clause).
          IF ( sy-dbcnt > lv_skip ).
            LOOP AT lt_ekko
              ASSIGNING FIELD-SYMBOL(<fs_ekko>).
              APPEND INITIAL LINE TO et_entityset
                ASSIGNING FIELD-SYMBOL(<fs_entity>).
              <fs_entity>-ebeln = <fs_ekko>-ebeln.
              <fs_entity>-bsart = <fs_ekko>-bsart.
              <fs_entity>-ekgrp = <fs_ekko>-ekgrp.
              CONVERT DATE <fs_ekko>-bedat
                TIME gc_time
                INTO TIME STAMP <fs_entity>-bedat
                TIME ZONE sy-zonlo.
              <fs_entity>-lifnr = <fs_ekko>-lifnr.
              <fs_entity>-ernam = <fs_ekko>-ernam.
              CONVERT DATE <fs_ekko>-aedat
                TIME gc_time
                INTO TIME STAMP <fs_entity>-aedat
                TIME ZONE sy-zonlo.
              <fs_entity>-frgrl = <fs_ekko>-frgrl.
              <fs_entity>-memory = <fs_ekko>-memory.
              <fs_entity>-memorytype = <fs_ekko>-memorytype.
            ENDLOOP.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount EQ abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.

        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `POHeadSet` ).
        MESSAGE e906(zmm) ##MG_MISSING.   "Just for where-used list
    ENDTRY.
  ENDMETHOD.


  METHOD po_item_conv_properties_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF `EBELN` IN rv_string WITH `i~EBELN`.
    REPLACE ALL OCCURRENCES OF `EBELP` IN rv_string WITH `i~EBELP`.
    REPLACE ALL OCCURRENCES OF `MATNR` IN rv_string WITH `i~MATNR`.
    REPLACE ALL OCCURRENCES OF `WERKS` IN rv_string WITH `i~WERKS`.
    REPLACE ALL OCCURRENCES OF `MENGE` IN rv_string WITH `i~MENGE`.
    REPLACE ALL OCCURRENCES OF `MEINS` IN rv_string WITH `i~MEINS`.
    REPLACE ALL OCCURRENCES OF `BPRME` IN rv_string WITH `i~BPRME`.
    REPLACE ALL OCCURRENCES OF `UMREZ` IN rv_string WITH `i~UMREZ`.
    REPLACE ALL OCCURRENCES OF `UMREN` IN rv_string WITH `i~UMREN`.
    REPLACE ALL OCCURRENCES OF `PEINH` IN rv_string WITH `i~PEINH`.
    REPLACE ALL OCCURRENCES OF `NETPR` IN rv_string WITH `i~NETPR`.
    REPLACE ALL OCCURRENCES OF `WAERS` IN rv_string WITH `s~WAERS`.
    REPLACE ALL OCCURRENCES OF `LOEKZ` IN rv_string WITH `i~LOEKZ`.
    REPLACE ALL OCCURRENCES OF `ELIKZ` IN rv_string WITH `i~ELIKZ`.
    REPLACE ALL OCCURRENCES OF `WEPOS` IN rv_string WITH `i~WEPOS`.
    REPLACE ALL OCCURRENCES OF `EREKZ` IN rv_string WITH `i~EREKZ`.
    REPLACE ALL OCCURRENCES OF `WEBRE` IN rv_string WITH `i~WEBRE`.
    REPLACE ALL OCCURRENCES OF `LABNR` IN rv_string WITH `i~LABNR`.
  ENDMETHOD.


  METHOD po_item_get_entity.
    DATA:
      lv_messg TYPE string.

    IF mv_changeset_active = abap_false.
      SELECT SINGLE
        i~ebeln,
        i~ebelp, i~matnr, i~werks, i~menge, i~meins,
        i~bprme, i~umrez, i~umren, i~peinh, i~netpr,  "BSTME(BPRME)
        s~waers, i~loekz, i~elikz, i~wepos, i~erekz,  "WAERS(PEINH)
        i~webre, i~labnr
        FROM ( ekpo AS i
                   INNER JOIN ekko AS s
                     ON i~ebeln = s~ebeln )
        INTO ( @er_entity-ebeln,
               @er_entity-ebelp, @er_entity-matnr, @er_entity-werks, @er_entity-menge, @er_entity-meins,
               @er_entity-bstme, @er_entity-umrez, @er_entity-umren, @er_entity-peinh, @er_entity-netpr,
               @er_entity-waers, @er_entity-loekz, @er_entity-elikz, @er_entity-wepos, @er_entity-erekz,
               @er_entity-webre, @er_entity-labnr )
        WHERE i~ebeln = @iv_po
          AND i~ebelp = @iv_po_item.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `903`
                                        attr1 = iv_po
                                        attr2 = iv_po_item ).
        MESSAGE e903(zmm) INTO lv_messg.
      ENDIF.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD po_item_get_entityset.
    DATA:
      ls_entity          TYPE zcl_mm_pur_mpc=>ts_poitem,
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = po_item_conv_properties_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = po_item_conv_properties_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS 'NOTE' OR lv_where_clause CS 'DELIVERY_DATE' OR lv_where_clause CS 'QUANTITY'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS 'NOTE' OR lv_orderby_clause CS 'DELIVERY_DATE' OR lv_orderby_clause CS 'QUANTITY'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause =
      add_to_where_clause( iv_where_clause           = lv_where_clause
                           iv_add_filter_field_name  = iv_add_filter_field_name
                           iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 'i~EBELN, i~EBELP'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
            INTO (lv_count)
            FROM ( ekpo AS i
                       INNER JOIN ekko AS s
                         ON i~ebeln = s~ebeln )
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              INTO (lv_count)
              FROM ( ekpo AS i
                       INNER JOIN ekko AS s
                         ON i~ebeln = s~ebeln )
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT
            i~ebeln,
            i~ebelp, i~matnr, i~werks, i~menge, i~meins,
            i~bprme, i~umrez, i~umren, i~peinh, i~netpr,  "BSTME(BPRME)
            s~waers, i~loekz, i~elikz, i~wepos, i~erekz,  "WAERS(PEINH,NETPR)
            i~webre, i~labnr
            FROM ( ekpo AS i
                       INNER JOIN ekko AS s
                         ON i~ebeln = s~ebeln )
                    INTO TABLE @DATA(lt_ekpo)
                    UP TO @lv_maxrows ROWS
                    WHERE (lv_where_clause)
                    ORDER BY (lv_orderby_clause).
          IF ( sy-dbcnt > lv_skip ).
            LOOP AT lt_ekpo
              ASSIGNING FIELD-SYMBOL(<fs_ekpo>).
              APPEND INITIAL LINE TO et_entityset
                ASSIGNING FIELD-SYMBOL(<fs_entityset>).
              <fs_entityset>-ebeln = <fs_ekpo>-ebeln.
              <fs_entityset>-ebelp = <fs_ekpo>-ebelp.
              <fs_entityset>-matnr = <fs_ekpo>-matnr.
              <fs_entityset>-werks = <fs_ekpo>-werks.
              <fs_entityset>-menge = <fs_ekpo>-menge.
              <fs_entityset>-meins = <fs_ekpo>-meins.
              <fs_entityset>-bstme = <fs_ekpo>-bprme.
              <fs_entityset>-umrez = <fs_ekpo>-umrez.
              <fs_entityset>-umren = <fs_ekpo>-umren.
              <fs_entityset>-peinh = <fs_ekpo>-peinh.
              <fs_entityset>-netpr = <fs_ekpo>-netpr.
              <fs_entityset>-waers = <fs_ekpo>-waers.
              <fs_entityset>-loekz = <fs_ekpo>-loekz.
              <fs_entityset>-elikz = <fs_ekpo>-elikz.
              <fs_entityset>-wepos = <fs_ekpo>-wepos.
              <fs_entityset>-erekz = <fs_ekpo>-erekz.
              <fs_entityset>-webre = <fs_ekpo>-webre.
              <fs_entityset>-labnr = <fs_ekpo>-labnr.
            ENDLOOP.
*           APPEND ls_soli_helper TO lt_soli_helper.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `POItemSet` ).
        MESSAGE e906(zmm) INTO lv_messg.
    ENDTRY.
  ENDMETHOD.


  METHOD po_item_sch_conv_proper_to_sql.
    rv_string = iv_string.

    REPLACE ALL OCCURRENCES OF `EBELN` IN rv_string WITH `h~EBELN`.
    REPLACE ALL OCCURRENCES OF `EBELP` IN rv_string WITH `h~EBELP`.
    REPLACE ALL OCCURRENCES OF `ETENR` IN rv_string WITH `h~ETENR`.
    REPLACE ALL OCCURRENCES OF `EINDT` IN rv_string WITH `h~EINDT`.
    REPLACE ALL OCCURRENCES OF `MENGE` IN rv_string WITH `h~MENGE`.
    REPLACE ALL OCCURRENCES OF `AMENG` IN rv_string WITH `h~AMENG`.
    REPLACE ALL OCCURRENCES OF `WEMNG` IN rv_string WITH `h~WEMNG`.
    REPLACE ALL OCCURRENCES OF `WAMNG` IN rv_string WITH `h~WAMNG`.
    REPLACE ALL OCCURRENCES OF `MEINS` IN rv_string WITH `i~MEINS`.
  ENDMETHOD.


  METHOD po_item_sch_get_entity.
    DATA:
      lv_messg TYPE string.

* During changeset processing ($batch) we can not perform a direct select as
* the DB tables are not updated.
    IF mv_changeset_active EQ abap_false.
      SELECT SINGLE
        h~ebeln,
        h~ebelp,
        h~etenr, h~eindt, h~menge, h~ameng, h~wemng, h~wamng,
        i~meins
        FROM ( eket AS h
                   INNER JOIN ekpo AS i
                      ON i~ebeln = h~ebeln
                     AND i~ebelp = h~ebelp )
        INTO @DATA(ls_eket)  "er_entity
        WHERE h~ebeln = @iv_po
          AND h~ebelp = @iv_po_item
          AND h~etenr = @iv_po_item_schln.
      IF sy-subrc <> 0.
*        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
*          EXPORTING
*            textid = VALUE scx_t100key( msgid = `ZMM`
*                                        msgno = `902`
*                                        attr1 = iv_po ).
*        MESSAGE e902(zmm) INTO lv_messg.
      ENDIF.

      er_entity-ebeln = ls_eket-ebeln.
      er_entity-ebelp = ls_eket-ebelp.
      er_entity-etenr = ls_eket-etenr.
      CONVERT DATE ls_eket-eindt
        TIME gc_time
        INTO TIME STAMP er_entity-eindt
        TIME ZONE sy-zonlo.
      er_entity-menge = ls_eket-menge.
      er_entity-ameng = ls_eket-ameng.
      er_entity-wemng = ls_eket-wemng.
      er_entity-wamng = ls_eket-wamng.
      er_entity-meins = ls_eket-meins.
    ELSE.
      CLEAR: er_entity.
    ENDIF.
  ENDMETHOD.


  METHOD po_item_sch_get_entityset.
    DATA:
      ls_entity          TYPE zcl_mm_pur_mpc=>ts_poitem,
      lv_where_clause    TYPE string,
      lv_orderby_clause  TYPE string,
      lv_maxrows         TYPE i,
      lv_top             TYPE i,
      lv_skip            TYPE i,
      lv_count           TYPE i,
      lv_has_count       TYPE abap_bool,
      lv_has_inlinecount TYPE abap_bool,
      lv_messg           TYPE string.

    CLEAR:
      et_entityset[], es_response_context.
    IF io_tech_request_context IS BOUND.
      lv_where_clause   = po_item_sch_conv_proper_to_sql( iv_string = io_tech_request_context->get_osql_where_clause_convert( ) ).
      lv_orderby_clause = po_item_sch_conv_proper_to_sql( iv_string = get_osql_orderby_clause( io_tech_request_context = io_tech_request_context ) ).

      lv_top  = io_tech_request_context->get_top( ).
      lv_skip = io_tech_request_context->get_skip( ).
      IF ( lv_top > 0 ).
        lv_maxrows = lv_top + lv_skip.
      ENDIF.

      lv_has_count       = io_tech_request_context->has_count( ).
      lv_has_inlinecount = io_tech_request_context->has_inlinecount( ).
    ELSE.
      lv_has_count       = abap_false.
      lv_has_inlinecount = abap_false.
    ENDIF.

* Filter+OrderBy on Note plus language is not supported (due to fallback logic for texts)
    IF lv_where_clause CS 'NOTE' OR lv_where_clause CS 'DELIVERY_DATE' OR lv_where_clause CS 'QUANTITY'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `904` ).
      MESSAGE e904(zmm) INTO lv_messg.
    ENDIF.

    IF lv_orderby_clause CS 'NOTE' OR lv_orderby_clause CS 'DELIVERY_DATE' OR lv_orderby_clause CS 'QUANTITY'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid = VALUE scx_t100key( msgid = `ZMM`
                                      msgno = `905` ).
      MESSAGE e905(zmm) INTO lv_messg.
    ENDIF.

    lv_where_clause =
      add_to_where_clause( iv_where_clause           = lv_where_clause
                           iv_add_filter_field_name  = iv_add_filter_field_name
                           iv_add_filter_field_value = iv_add_filter_field_value ).

* Default sorting.
    IF lv_orderby_clause IS INITIAL.
      lv_orderby_clause = 'h~EBELN, h~EBELP, h~ETENR'.
    ENDIF.

    TRY.
*     If $count is requested, we just need to count the filtered records
        IF ( lv_has_count = abap_true ).
          SELECT COUNT( * )
            INTO (@lv_count)
            FROM ( eket AS h
                   INNER JOIN ekpo AS i
                      ON i~ebeln = h~ebeln
                     AND i~ebelp = h~ebelp )
            WHERE (lv_where_clause).
          es_response_context-count = lv_count.
        ELSE.
*       Do we need to provide an inlinecount along with client-side paging?
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top > 0 OR lv_skip > 0 ).
            SELECT COUNT( * )
              INTO (@lv_count)
              FROM ( eket AS h
                   INNER JOIN ekpo AS i
                      ON i~ebeln = h~ebeln
                     AND i~ebelp = h~ebelp )
              WHERE (lv_where_clause).
            es_response_context-inlinecount = lv_count.
          ENDIF.

          SELECT
            h~ebeln,
            h~ebelp,
            h~etenr, h~eindt, h~menge, h~ameng, h~wemng, h~wamng,
            i~meins
            FROM ( eket AS h
                   INNER JOIN ekpo AS i
                      ON i~ebeln = h~ebeln
                     AND i~ebelp = h~ebelp )
            INTO TABLE @DATA(lt_eket)
            UP TO @lv_maxrows ROWS
            WHERE (lv_where_clause)
            ORDER BY (lv_orderby_clause).

          IF ( sy-dbcnt > lv_skip ).
            LOOP AT lt_eket
              ASSIGNING FIELD-SYMBOL(<fs_eket>).
              APPEND INITIAL LINE TO et_entityset
                ASSIGNING FIELD-SYMBOL(<fs_entityset>).
              <fs_entityset>-ebeln = <fs_eket>-ebeln.
              <fs_entityset>-ebelp = <fs_eket>-ebelp.
              <fs_entityset>-etenr = <fs_eket>-etenr.
              CONVERT DATE <fs_eket>-eindt
                TIME gc_time
                INTO TIME STAMP <fs_entityset>-eindt
                TIME ZONE sy-zonlo.
              <fs_entityset>-menge = <fs_eket>-menge.
              <fs_entityset>-ameng = <fs_eket>-ameng.
              <fs_entityset>-wemng = <fs_eket>-wemng.
              <fs_entityset>-wamng = <fs_eket>-wamng.
              <fs_entityset>-meins = <fs_eket>-meins.
            ENDLOOP.
          ENDIF.

*       An Inlinecount without client-side paging just needs to count the entries in the return table
          IF ( lv_has_inlinecount = abap_true ) AND ( lv_top = 0 AND lv_skip = 0 ).
            es_response_context-inlinecount = lines( et_entityset ).
          ENDIF.
        ENDIF.

      CATCH cx_sy_dynamic_osql_semantics
            cx_sy_dynamic_osql_syntax
            cx_sy_dynamic_osql_error.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid = VALUE scx_t100key( msgid = `ZMM`
                                        msgno = `906`
                                        attr1 = `POItemSet` ).
        MESSAGE e906(zmm) INTO lv_messg.
    ENDTRY.
  ENDMETHOD.


  METHOD resolve_navigation_path.
    DATA:
      lt_nav_path           TYPE /iwbep/t_mgw_tech_navi,

      ls_entity_plant       TYPE zcl_mm_pur_mpc=>ts_plant,
      ls_entity_material    TYPE zcl_mm_pur_mpc=>ts_material,
      ls_entity_partner     TYPE zcl_mm_pur_mpc=>ts_partner,
      ls_entity_po          TYPE zcl_mm_pur_mpc=>ts_pohead,
      ls_entity_po_item     TYPE zcl_mm_pur_mpc=>ts_poitem,
      ls_entity_po_item_sch TYPE zcl_mm_pur_mpc=>ts_poschedule,
      ls_entity_gr          TYPE zcl_mm_pur_mpc=>ts_grhead,
      ls_entity_gr_item     TYPE zcl_mm_pur_mpc=>ts_gritem,

      lv_source_entity_type TYPE /iwbep/mgw_tech_name,
      lv_collection_found   TYPE abap_bool,

      lv_materialno         TYPE matnr,
      lv_po                 TYPE ebeln,
      lv_po_item            TYPE ebelp,
      lv_po_item_sch        TYPE etenr,
      lv_gr                 TYPE mblnr,
      lv_year               TYPE gjahr,
      lv_gr_item            TYPE mblpo.

    FIELD-SYMBOLS
      <fs_key_values> TYPE any.

    CLEAR:
      er_result, es_response_context.

    IF io_tech_request_ctx_entity IS BOUND.
      lt_nav_path = io_tech_request_ctx_entity->get_navigation_path( ).
    ELSEIF io_tech_request_ctx_entityset IS BOUND.
      lt_nav_path = io_tech_request_ctx_entityset->get_navigation_path( ).
    ELSE.
      throw_generic_error( ).
    ENDIF.

    lv_collection_found = abap_false.

    LOOP AT lt_nav_path
      ASSIGNING FIELD-SYMBOL(<fs_nav_path>).
*   The first entry is the starting point. The key is retrieved using get_converted_source_keys method.
      IF sy-tabix = 1.
        CASE <fs_nav_path>-source_entity_type.
          WHEN zcl_mm_pur_mpc_ext=>gc_plant.
            ASSIGN ls_entity_plant TO <fs_key_values>.
          WHEN zcl_mm_pur_mpc_ext=>gc_material.
            ASSIGN ls_entity_material TO <fs_key_values>.
          WHEN zcl_mm_pur_mpc_ext=>gc_partner.
            ASSIGN ls_entity_partner TO <fs_key_values>.
          WHEN zcl_mm_pur_mpc_ext=>gc_pohead.
            ASSIGN ls_entity_po TO <fs_key_values>.
          WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
            ASSIGN ls_entity_po_item TO <fs_key_values>.
          WHEN zcl_mm_pur_mpc_ext=>gc_poschedule.
            ASSIGN ls_entity_po_item_sch TO <fs_key_values>.
          WHEN zcl_mm_pur_mpc_ext=>gc_grhead.
            ASSIGN ls_entity_gr TO <fs_key_values>.
          WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
            ASSIGN ls_entity_gr_item TO <fs_key_values>.
        ENDCASE.

        IF io_tech_request_ctx_entity IS BOUND.
          io_tech_request_ctx_entity->get_converted_source_keys(
            IMPORTING
              es_key_values = <fs_key_values> ).
        ELSE.
          io_tech_request_ctx_entityset->get_converted_source_keys(
            IMPORTING
              es_key_values = <fs_key_values> ).
        ENDIF.

        CASE <fs_nav_path>-source_entity_type.
          WHEN zcl_mm_pur_mpc_ext=>gc_plant.
            ls_entity_plant = plant_get_entity( iv_plantcode = ls_entity_plant-werks ).
          WHEN zcl_mm_pur_mpc_ext=>gc_material.
            ls_entity_material = material_get_entity( iv_materialno = ls_entity_material-matnr ).
          WHEN zcl_mm_pur_mpc_ext=>gc_partner.
            ls_entity_partner = partner_get_entity( iv_partnerno = ls_entity_partner-lifnr ).
          WHEN zcl_mm_pur_mpc_ext=>gc_pohead.
            ls_entity_po = po_head_get_entity( iv_po = ls_entity_po-ebeln ).
          WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
            ls_entity_po_item = po_item_get_entity( iv_po      = ls_entity_po_item-ebeln
                                                    iv_po_item = CONV ebelp( ls_entity_po_item-ebelp ) ).
          WHEN zcl_mm_pur_mpc_ext=>gc_poschedule.
            ls_entity_po_item_sch = po_item_sch_get_entity( iv_po      = ls_entity_po_item_sch-ebeln
                                                            iv_po_item = CONV ebelp( ls_entity_po_item_sch-ebelp )
                                                            iv_po_item_schln = CONV etenr( ls_entity_po_item_sch-etenr ) ).
          WHEN zcl_mm_pur_mpc_ext=>gc_grhead.
            ls_entity_gr = gr_get_entity( iv_gr   = ls_entity_gr-mblnr
                                          iv_year = CONV mjahr( ls_entity_gr-mjahr ) ).
          WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
            ls_entity_gr_item = gr_item_get_entity( iv_gr      = ls_entity_gr_item-mblnr
                                                    iv_year    = CONV mjahr( ls_entity_gr_item-mjahr )
                                                    iv_gr_item = CONV mblpo( ls_entity_gr_item-zeile ) ).
        ENDCASE.
        lv_source_entity_type = <fs_nav_path>-source_entity_type.
      ENDIF.

      CASE lv_source_entity_type.
        WHEN zcl_mm_pur_mpc_ext=>gc_plant.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_po, lv_po_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING FIELD-SYMBOL(<fs_key>).
                  CASE <fs_key>-name.
                    WHEN `EBELN`.
                      lv_po = <fs_key>-value.
                    WHEN `EBELP`.
                      lv_po_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_po_item = po_item_get_entity( iv_po      = lv_po
                                                        iv_po_item = lv_po_item ).
              ELSE.
                po_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = 'c~WERKS'
                    iv_add_filter_field_value = ls_entity_plant-werks
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
            WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_gr, lv_year, lv_gr_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `MBLNR`.
                      lv_gr = <fs_key>-value.
                    WHEN `MJAHR`.
                      lv_year = <fs_key>-value.
                    WHEN `ZEILE`.
                      lv_gr_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_gr_item = gr_item_get_entity( iv_gr      = lv_gr
                                                        iv_year    = lv_year
                                                        iv_gr_item = lv_gr_item ).
              ELSE.
                gr_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = 'c~WERKS'
                    iv_add_filter_field_value = ls_entity_plant-werks
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
          ENDCASE.
        WHEN zcl_mm_pur_mpc_ext=>gc_material.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_po, lv_po_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `EBELN`.
                      lv_po = <fs_key>-value.
                    WHEN `EBELP`.
                      lv_po_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_po_item = po_item_get_entity( iv_po      = lv_po
                                                        iv_po_item = lv_po_item ).
              ELSE.
                po_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = 'p~MATNR'
                    iv_add_filter_field_value = ls_entity_material-matnr
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
            WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_gr, lv_year, lv_gr_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `MBLNR`.
                      lv_gr = <fs_key>-value.
                    WHEN `MJAHR`.
                      lv_year = <fs_key>-value.
                    WHEN `ZEILE`.
                      lv_gr_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_gr_item = gr_item_get_entity( iv_gr      = lv_gr
                                                        iv_year    = lv_year
                                                        iv_gr_item = lv_gr_item ).
              ELSE.
                gr_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = 'p~MATNR'
                    iv_add_filter_field_value = ls_entity_material-matnr
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
          ENDCASE.
        WHEN zcl_mm_pur_mpc_ext=>gc_partner.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_pohead.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR lv_po.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `EBELN`.
                      lv_po = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_po = po_head_get_entity( iv_po = lv_po ).
              ELSE.
                po_head_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = 'b~LIFNR'
                    iv_add_filter_field_value = ls_entity_partner-lifnr
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
            WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_gr, lv_year, lv_gr_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `MBLNR`.
                      lv_gr = <fs_key>-value.
                    WHEN `MJAHR`.
                      lv_year = <fs_key>-value.
                    WHEN `ZEILE`.
                      lv_gr_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_gr_item = gr_item_get_entity( iv_gr      = lv_gr
                                                        iv_year    = lv_year
                                                        iv_gr_item = lv_gr_item ).
              ELSE.
                gr_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = 'b~LIFNR'
                    iv_add_filter_field_value = ls_entity_partner-lifnr
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
          ENDCASE.
        WHEN zcl_mm_pur_mpc_ext=>gc_pohead.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_partner.
              ls_entity_partner = partner_get_entity( iv_partnerno = ls_entity_po-lifnr ).
            WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_po, lv_po_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `EBELN`.
                      lv_po = <fs_key>-value.
                    WHEN `EBELP`.
                      lv_po_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_po_item = po_item_get_entity( iv_po      = lv_po
                                                        iv_po_item = lv_po_item ).
              ELSE.
                po_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = `s~EBELN`
                    iv_add_filter_field_value = ls_entity_po-ebeln
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
          ENDCASE.
        WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_plant.
              ls_entity_plant = plant_get_entity( iv_plantcode = ls_entity_po_item-werks ).
            WHEN zcl_mm_pur_mpc_ext=>gc_material.
              ls_entity_material = material_get_entity( iv_materialno = ls_entity_po_item-matnr ).
            WHEN zcl_mm_pur_mpc_ext=>gc_pohead.
              ls_entity_po = po_head_get_entity( iv_po = ls_entity_po_item-ebeln ).
            WHEN zcl_mm_pur_mpc_ext=>gc_poschedule.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_po, lv_po_item, lv_po_item_sch.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `EBELN`.
                      lv_po = <fs_key>-value.
                    WHEN `EBELP`.
                      lv_po_item = <fs_key>-value.
                    WHEN `ETENR`.
                      lv_po_item_sch = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_po_item_sch = po_item_sch_get_entity( iv_po      = lv_po
                                                                iv_po_item = lv_po_item
                                                                iv_po_item_schln = lv_po_item_sch ).
              ELSE.
                po_item_sch_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = `h~EBELN,h~EBELP`
                    iv_add_filter_field_value = |{ ls_entity_po_item-ebeln },{ ls_entity_po_item-ebelp }|
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
            WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_gr, lv_year, lv_gr_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `MBLNR`.
                      lv_gr = <fs_key>-value.
                    WHEN `MJAHR`.
                      lv_year = <fs_key>-value.
                    WHEN `ZEILE`.
                      lv_gr_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_gr_item = gr_item_get_entity( iv_gr      = lv_gr
                                                        iv_year    = lv_year
                                                        iv_gr_item = lv_gr_item ).
              ELSE.
                gr_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = `h~EBELN,h~EBELP`
                    iv_add_filter_field_value = |{ ls_entity_po_item-ebeln },{ ls_entity_po_item-ebelp }|
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
          ENDCASE.
        WHEN zcl_mm_pur_mpc_ext=>gc_poschedule.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
              ls_entity_po_item = po_item_get_entity( iv_po = ls_entity_po_item_sch-ebeln
                                                      iv_po_item = CONV ebelp( ls_entity_po_item_sch-ebelp ) ).
              lv_collection_found = abap_true.
              EXIT.
          ENDCASE.
        WHEN zcl_mm_pur_mpc_ext=>gc_grhead.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
              IF <fs_nav_path>-key_tab[] IS NOT INITIAL.
                CLEAR:
                  lv_gr, lv_year, lv_gr_item.
                LOOP AT <fs_nav_path>-key_tab
                  ASSIGNING <fs_key>.
                  CASE <fs_key>-name.
                    WHEN `MBLNR`.
                      lv_gr = <fs_key>-value.
                    WHEN `MJAHR`.
                      lv_year = <fs_key>-value.
                    WHEN `ZEILE`.
                      lv_gr_item = <fs_key>-value.
                  ENDCASE.
                ENDLOOP.
                ls_entity_gr_item = gr_item_get_entity( iv_gr      = lv_gr
                                                        iv_year    = lv_year
                                                        iv_gr_item = lv_gr_item ).
              ELSE.
                gr_item_get_entityset(
                  EXPORTING
                    io_tech_request_context   = io_tech_request_ctx_entityset
                    iv_add_filter_field_name  = `m~MBLNR,m~MJAHR`
                    iv_add_filter_field_value = |{ ls_entity_gr-mblnr },{ ls_entity_gr-mjahr }|
                  IMPORTING
                    et_entityset            = er_result
                    es_response_context     = es_response_context ).
                lv_collection_found = abap_true.
                EXIT.
              ENDIF.
          ENDCASE.
        WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
          CASE <fs_nav_path>-target_entity_type.
            WHEN zcl_mm_pur_mpc_ext=>gc_pohead.
              ls_entity_gr = gr_get_entity( iv_gr = ls_entity_gr_item-mblnr
                                            iv_year = CONV mjahr( ls_entity_gr_item-mjahr ) ).
              lv_collection_found = abap_true.
              EXIT.
          ENDCASE.
      ENDCASE.
      lv_source_entity_type = <fs_nav_path>-target_entity_type.
    ENDLOOP.

    IF lv_collection_found = abap_false.
      CASE <fs_nav_path>-target_entity_type.
        WHEN zcl_mm_pur_mpc_ext=>gc_plant.
          er_result = ls_entity_plant.
        WHEN zcl_mm_pur_mpc_ext=>gc_material.
          er_result = ls_entity_material.
        WHEN zcl_mm_pur_mpc_ext=>gc_partner.
          er_result = ls_entity_partner.
        WHEN zcl_mm_pur_mpc_ext=>gc_pohead.
          er_result = ls_entity_po.
        WHEN zcl_mm_pur_mpc_ext=>gc_poitem.
          er_result = ls_entity_po_item.
        WHEN zcl_mm_pur_mpc_ext=>gc_poschedule.
          er_result = ls_entity_po_item_sch.
        WHEN zcl_mm_pur_mpc_ext=>gc_grhead.
          er_result = ls_entity_gr.
        WHEN zcl_mm_pur_mpc_ext=>gc_gritem.
          er_result = ls_entity_gr_item.
      ENDCASE.
    ENDIF.
  ENDMETHOD.


  METHOD throw_generic_error.
    DATA
      lv_dummy TYPE string.

    RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
      EXPORTING
        textid = VALUE scx_t100key( msgid = `ZMM`
                                    msgno = `901` ).
    MESSAGE e901(zmm) INTO lv_dummy.
  ENDMETHOD.
ENDCLASS.
