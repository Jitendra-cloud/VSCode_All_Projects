@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'zpb_r_vendor_block_type'
@Metadata.ignorePropagatedAnnotations: true
define view entity zpb_r_vendor_block_type
  as select from ZPB_R_MT_ACC_DATA as a
    inner join   zcy_t_2a_blk_typ  as b on b.vendor = a.lifnr
                                        or b.vendor = a.gst_part
{
  key a.Bukrs,
  key a.Belnr,
  key a.Gjahr,
      a.lifnr,
      a.gst_part,
      b.vendor,
      b.vendor_block_type,
      b.grc_check_applicable

}

union all

select from  ZPB_R_MT_ACC_DATA as a
  inner join zcy_t_2a_blk_typ  as b on b.vendor = a.lifnr
                                    or b.vendor = a.gst_part
  inner join lfa1              as c on b.vendor = c.ktokk
{
  key a.Bukrs,
  key a.Belnr,
  key a.Gjahr,
      a.lifnr,
      a.gst_part,
      b.vendor,
      b.vendor_block_type,
      b.grc_check_applicable

}
